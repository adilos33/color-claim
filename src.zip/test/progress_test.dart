import 'dart:convert';

import 'package:color_claim/game/progress.dart';
import 'package:flutter_test/flutter_test.dart';

void main() {
  group('GameProgress', () {
    test('defaults unlock only level 1 and start unmuted', () {
      final progress = GameProgress.defaults();

      expect(progress.highestUnlockedLevel, 1);
      expect(progress.isLevelUnlocked(1), isTrue);
      expect(progress.isLevelUnlocked(2), isFalse);
      expect(progress.bestPercents, isEmpty);
      expect(progress.bestForLevel(1), 0);
      expect(progress.muted, isFalse);
    });

    test('completing levels unlocks the next level in order', () {
      final progress = GameProgress.defaults();

      progress.completeLevel(1, 12, totalLevels: 6);
      expect(progress.highestUnlockedLevel, 2);
      expect(progress.isLevelUnlocked(2), isTrue);
      expect(progress.isLevelUnlocked(3), isFalse);

      progress.completeLevel(2, 18, totalLevels: 6);
      expect(progress.highestUnlockedLevel, 3);

      // Replaying an earlier level never locks later levels again.
      progress.completeLevel(1, 11, totalLevels: 6);
      expect(progress.highestUnlockedLevel, 3);

      progress.completeLevel(3, 24, totalLevels: 6);
      progress.completeLevel(4, 29, totalLevels: 6);
      progress.completeLevel(5, 34, totalLevels: 6);
      progress.completeLevel(6, 40, totalLevels: 6);
      expect(progress.highestUnlockedLevel, 6);
    });

    test('best percent updates only when the new percent is higher', () {
      final progress = GameProgress.defaults();

      expect(progress.recordBest(1, 12.5), isTrue);
      expect(progress.bestForLevel(1), 12.5);

      expect(progress.recordBest(1, 10), isFalse);
      expect(progress.bestForLevel(1), 12.5);

      expect(progress.recordBest(1, 12.5), isFalse);
      expect(progress.recordBest(1, 15.25), isTrue);
      expect(progress.bestForLevel(1), 15.25);
    });

    test('mute and progress round-trip through JSON', () {
      final progress = GameProgress.defaults()
        ..completeLevel(1, 13.5, totalLevels: 6)
        ..recordBest(2, 9.75)
        ..setMuted(true);

      final encoded = jsonEncode(progress.toJson());
      final decoded = jsonDecode(encoded) as Map<String, dynamic>;
      final restored = GameProgress.fromJson(decoded);

      expect(restored.highestUnlockedLevel, 2);
      expect(restored.bestForLevel(1), 13.5);
      expect(restored.bestForLevel(2), 9.75);
      expect(restored.muted, isTrue);
      expect(restored.toJson(), progress.toJson());
    });
  });
}
