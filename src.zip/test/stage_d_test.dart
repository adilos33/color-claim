import 'package:color_claim/game/powerups.dart';
import 'package:color_claim/game/territory_engine.dart';
import 'package:flutter_test/flutter_test.dart';

/// Teleports the player to (x, y) and pins it there (speed 0), so the
/// bot steering under test is the only thing that moves.
void pinPlayer(TerritoryEngine engine, int x, int y) {
  final p = engine.player;
  p.x = x;
  p.y = y;
  p.prevX = x;
  p.prevY = y;
  p.dx = 0;
  p.dy = -1;
  p.speed = 0;
  p.moveAcc = 0;
}

/// Freezes every bot except [keep] in place for the rest of the test.
void parkOtherBots(TerritoryEngine engine, Actor keep) {
  for (final bot in engine.actors.skip(1)) {
    if (identical(bot, keep)) continue;
    bot.alive = false;
    bot.respawnSteps = 100000;
  }
}

void main() {
  group('Stage D smarter bots', () {
    test('the Hunter only fields in the final levels', () {
      for (final level in kLevels) {
        final engine = TerritoryEngine(level, seed: 11);
        final hunters = engine.actors.where((a) => a.isHunter).toList();
        if (level.id >= kHunterMinLevel) {
          expect(hunters, hasLength(1), reason: level.name);
          final hunter = hunters.single;
          expect(hunter.name, kHunterName, reason: level.name);
          expect(kBotNames, isNot(contains(hunter.name)));
          // Speed edge over the level baseline, even at the unlucky
          // low end of the per-bot speed roll (0.9 * 1.12 > 1.0).
          expect(hunter.speed, greaterThan(level.botSpeed),
              reason: level.name);
        } else {
          expect(hunters, isEmpty, reason: level.name);
        }
      }
    });

    test('trail risk limits grow with level', () {
      final early = TerritoryEngine(kLevels[0], seed: 3);
      final late = TerritoryEngine(kLevels[5], seed: 3);
      final earlyLimits = [
        for (final b in early.actors.skip(1)) b.trailRiskLimit
      ];
      final lateLimits = [
        for (final b in late.actors.skip(1)) b.trailRiskLimit
      ];
      // Early bots bank their trail sooner (gentler opening levels);
      // every late-game budget beats every early one.
      expect(
        earlyLimits.reduce((a, b) => a > b ? a : b),
        lessThan(lateLimits.reduce((a, b) => a < b ? a : b)),
      );
    });

    test('a bot at its risk limit heads home instead of wandering', () {
      final engine = TerritoryEngine(kLevels[0], seed: 7);
      final bot = engine.actors[1];
      parkOtherBots(engine, bot);
      pinPlayer(engine, 3, 52);

      // Drop the bot on neutral ground with a trail past its budget.
      bot.x = 30;
      bot.y = 30;
      bot.prevX = 30;
      bot.prevY = 30;
      bot.dx = 1;
      bot.dy = 0;
      bot.moveAcc = 0.99; // exactly one move on the next step
      for (var y = 49; y <= 50; y++) {
        for (var x = 5; x <= 49; x++) {
          final cell = engine.idx(x, y);
          bot.trail.add(cell);
          bot.trailSet.add(cell);
        }
      }
      expect(bot.trail.length, greaterThanOrEqualTo(bot.trailRiskLimit));
      bot.phase = 1; // wandering — must be overridden
      bot.hasTarget = false;

      engine.step();

      expect(bot.phase, 2);
    });

    test('a short trail does not force the bot home', () {
      final engine = TerritoryEngine(kLevels[0], seed: 7);
      final bot = engine.actors[1];
      parkOtherBots(engine, bot);
      pinPlayer(engine, 3, 52);

      bot.x = 30;
      bot.y = 30;
      bot.prevX = 30;
      bot.prevY = 30;
      bot.dx = 1;
      bot.dy = 0;
      bot.moveAcc = 0.99;
      for (var x = 5; x <= 12; x++) {
        final cell = engine.idx(x, 50);
        bot.trail.add(cell);
        bot.trailSet.add(cell);
      }
      expect(bot.trail.length, lessThan(bot.trailRiskLimit));
      bot.phase = 1;
      bot.hasTarget = false;

      engine.step();

      expect(bot.phase, isNot(2));
    });

    test('bots detour to grab a nearby power-up', () {
      final engine = TerritoryEngine(kLevels[0], seed: 7);
      final bot = engine.actors[1]; // spawns at (43, 12)
      parkOtherBots(engine, bot);
      pinPlayer(engine, 3, 52);

      // Six cells left of the bot's spawn: neutral ground, in range.
      engine.pickups.add(
        const PowerUpPickup(kind: PowerUpKind.speed, x: 37, y: 12),
      );
      bot.hasTarget = false;
      bot.moveAcc = 0.99;

      engine.step();

      expect(bot.targetX, 37);
      expect(bot.targetY, 12);
    });

    test('the Hunter locks onto the player exposed trail', () {
      final engine = TerritoryEngine(kLevels[5], seed: 42);
      final hunter = engine.actors[1];
      expect(hunter.isHunter, isTrue);
      parkOtherBots(engine, hunter);
      // Hunter stays on its spawn (43, 12); player pinned far away
      // with a fake exposed trail five cells from the hunter.
      pinPlayer(engine, 12, 43);
      for (final x in [36, 37, 38]) {
        final cell = engine.idx(x, 12);
        engine.player.trail.add(cell);
        engine.player.trailSet.add(cell);
      }
      expect(engine.player.isOutside, isTrue);
      hunter.hasTarget = false;
      hunter.phase = 0;
      hunter.moveAcc = 0.99;

      engine.step();

      expect(hunter.hunting, isTrue);
      expect(hunter.targetX, 38);
      expect(hunter.targetY, 12);
    });

    test('no hunting below level 4 for ordinary bots', () {
      final engine = TerritoryEngine(kLevels[2], seed: 42); // level 3
      final bot = engine.actors[1]; // spawns at (43, 12)
      parkOtherBots(engine, bot);
      pinPlayer(engine, 12, 43);
      for (final x in [36, 37, 38]) {
        final cell = engine.idx(x, 12);
        engine.player.trail.add(cell);
        engine.player.trailSet.add(cell);
      }
      bot.hasTarget = false;
      bot.phase = 0;
      bot.moveAcc = 0.99;

      engine.step();

      expect(bot.hunting, isFalse);
      expect(bot.isHunter, isFalse);
    });
  });

  group('Stage D soak', () {
    test('long matches on every arena and life count never crash', () {
      const dirs = [(0, -1), (1, 0), (0, 1), (-1, 0)];
      for (final level in kLevels) {
        for (final lives in [3, 1]) {
          final engine = TerritoryEngine(
            level,
            seed: 100 + level.id * 7 + lives,
            initialLives: lives,
          );
          var guard = 0;
          while (!engine.gameOver && guard < 1200) {
            if (guard % 25 == 0) {
              final d = dirs[(guard ~/ 25) % 4];
              engine.setPlayerDirection(d.$1, d.$2);
            }
            engine.step();
            guard++;
            if (guard % 100 == 0) {
              for (final a in engine.actors) {
                expect(
                  a.x,
                  inInclusiveRange(0, TerritoryEngine.cols - 1),
                  reason: '${level.name}/$lives',
                );
                expect(
                  a.y,
                  inInclusiveRange(0, TerritoryEngine.rows - 1),
                  reason: '${level.name}/$lives',
                );
              }
              for (final o in engine.owners) {
                // Every owned cell belongs to a bot/player still in
                // the match (head-on elimination frees territory, so
                // a removed bot's id must never linger here).
                expect(
                  o == TerritoryEngine.blockedOwner ||
                      o == -1 ||
                      engine.actors.any((a) => a.id == o),
                  isTrue,
                  reason: '${level.name}/$lives owner=$o',
                );
              }
            }
          }
          expect(engine.steps, greaterThan(0), reason: level.name);
          // The match moved somewhere: either the player fell, or at
          // least one bot grew past its spawn circle (~1.7%).
          final botGrew = engine.actors
              .skip(1)
              .any((b) => engine.percentFor(b.id) > 2.0);
          expect(
            engine.gameOver || botGrew,
            isTrue,
            reason: '${level.name}/$lives steps=${engine.steps}',
          );
        }
      }
    });
  });
}
