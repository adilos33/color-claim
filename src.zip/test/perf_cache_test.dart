import 'package:color_claim/game/territory_engine.dart';
import 'package:flutter_test/flutter_test.dart';

/// The board painters cache the territory layer in a recorded picture
/// keyed by [TerritoryEngine.boardRevision]. These tests guard that
/// key: it must move exactly when cell ownership changes, or the
/// cached layer would go stale (or be rebuilt needlessly).
void main() {
  group('boardRevision (painter cache key)', () {
    test('spawning actors claims circles and bumps the revision', () {
      final engine = TerritoryEngine(kLevels[0], seed: 7);
      expect(engine.boardRevision, greaterThan(0));
    });

    test('captureTrail bumps the revision when it claims cells', () {
      final engine = TerritoryEngine(kLevels[0], seed: 7);
      final player = engine.player;

      // Wipe the board, then give the player a small home block.
      for (var i = 0; i < engine.owners.length; i++) {
        engine.owners[i] = -1;
      }
      for (var y = 20; y <= 23; y++) {
        for (var x = 20; x <= 23; x++) {
          engine.owners[engine.idx(x, y)] = 0;
        }
      }
      final trailCells = <(int, int)>[
        (24, 19),
        (25, 19),
        (26, 19),
        (27, 19),
        (28, 19),
        (28, 20),
        (28, 21),
        (28, 22),
        (28, 23),
        (27, 23),
        (26, 23),
        (25, 23),
        (24, 23),
      ];
      for (final c in trailCells) {
        final i = engine.idx(c.$1, c.$2);
        player.trail.add(i);
        player.trailSet.add(i);
      }

      final before = engine.boardRevision;
      final gained = engine.captureTrail(player);
      expect(gained, greaterThan(0));
      expect(engine.boardRevision, greaterThan(before));
    });

    test('captureTrail with an empty trail does not bump the revision', () {
      final engine = TerritoryEngine(kLevels[0], seed: 7);
      final before = engine.boardRevision;
      expect(engine.captureTrail(engine.player), 0);
      expect(engine.boardRevision, before);
    });
  });
}
