import 'dart:convert';

import 'package:color_claim/game/challenges.dart';
import 'package:color_claim/game/game_mode.dart';
import 'package:color_claim/game/progress.dart';
import 'package:color_claim/game/ranks.dart';
import 'package:flutter_test/flutter_test.dart';

/// A concrete day whose daily challenge has id [id]. Dates are plain
/// local calendar days (midnight), like the game itself uses.
DateTime dayWithChallenge(String id, {int year = 2026}) {
  for (var i = 0; i < 60; i++) {
    final day = DateTime(year, 1, 1 + i);
    if (challengeForDate(day).id == id) return day;
  }
  throw StateError('no day with challenge $id');
}

DateTime plusDays(DateTime day, int n) =>
    DateTime(day.year, day.month, day.day + n);

/// A finished match that completes whatever challenge [day] offers.
MatchStats completingStats(DateTime day) {
  switch (challengeForDate(day).kind) {
    case DailyChallengeKind.capturePercentOnce:
      return MatchStats(
        mode: GameMode.classic,
        percent: challengeForDate(day).goal + 5.0,
      );
    case DailyChallengeKind.knockoutsToday:
      return MatchStats(
        mode: GameMode.classic,
        percent: 10,
        knockouts: challengeForDate(day).goal,
      );
    case DailyChallengeKind.quickVictory:
      return const MatchStats(
        mode: GameMode.quickMatch,
        percent: 30,
        victory: true,
      );
    case DailyChallengeKind.classicVictory:
      return const MatchStats(
        mode: GameMode.classic,
        percent: 30,
        victory: true,
      );
    case DailyChallengeKind.survivalSecondsOnce:
      return MatchStats(
        mode: GameMode.survival,
        percent: 20,
        survivalSeconds: challengeForDate(day).goal + 10,
      );
  }
}

void main() {
  group('Daily challenge rotation', () {
    test('the same date always picks the same challenge', () {
      final day = DateTime(2026, 3, 14);
      expect(challengeForDate(day).id, challengeForDate(day).id);
      // Time of day never leaks into the pick.
      expect(
        challengeForDate(DateTime(2026, 3, 14, 23, 59)).id,
        challengeForDate(day).id,
      );
    });

    test('consecutive days step through the whole roster, then wrap', () {
      final start = DateTime(2026, 1, 1);
      final seen = <String>{};
      for (var i = 0; i < kDailyChallenges.length; i++) {
        final challenge = challengeForDate(plusDays(start, i));
        expect(seen.add(challenge.id), isTrue, reason: 'day $i repeats');
      }
      expect(seen.length, kDailyChallenges.length);
      expect(
        challengeForDate(plusDays(start, kDailyChallenges.length)).id,
        challengeForDate(start).id,
      );
    });

    test('dateKeyFor pads month and day', () {
      expect(dateKeyFor(DateTime(2026, 3, 5)), '2026-03-05');
      expect(dateKeyFor(DateTime(2026, 12, 25)), '2026-12-25');
    });
  });

  group('Daily progress', () {
    test('knockouts accumulate across the day and complete once', () {
      final day = dayWithChallenge('knockouts_3');
      final progress = GameProgress.defaults();

      var bonus = progress.applyMatchToDaily(
        const MatchStats(mode: GameMode.classic, percent: 10, knockouts: 2),
        day,
      );
      expect(bonus, 0);
      expect(progress.dailyProgress, 2);
      expect(progress.dailyCompleted, isFalse);

      bonus = progress.applyMatchToDaily(
        const MatchStats(mode: GameMode.classic, percent: 12, knockouts: 1),
        day,
      );
      expect(bonus, kDailyChallengeBonusPoints);
      expect(progress.dailyCompleted, isTrue);
      expect(progress.dailyProgress, 3);

      // Already claimed: later matches never pay the bonus twice.
      bonus = progress.applyMatchToDaily(
        const MatchStats(mode: GameMode.classic, percent: 20, knockouts: 5),
        day,
      );
      expect(bonus, 0);
    });

    test('capture challenges track the best single match, floored', () {
      final day = dayWithChallenge('capture_25');
      final progress = GameProgress.defaults();

      expect(
        progress.applyMatchToDaily(
          const MatchStats(mode: GameMode.classic, percent: 18.9),
          day,
        ),
        0,
      );
      expect(progress.dailyProgress, 18);
      expect(
        progress.applyMatchToDaily(
          const MatchStats(mode: GameMode.classic, percent: 27.6),
          day,
        ),
        kDailyChallengeBonusPoints,
      );
      expect(progress.dailyProgress, 25);
    });

    test('a Quick Match challenge needs a Quick Match win', () {
      final day = dayWithChallenge('quick_win');
      final progress = GameProgress.defaults();

      // A Classic win does not count.
      expect(
        progress.applyMatchToDaily(
          const MatchStats(
            mode: GameMode.classic,
            percent: 40,
            victory: true,
          ),
          day,
        ),
        0,
      );
      // Neither does a Quick Match loss.
      expect(
        progress.applyMatchToDaily(
          const MatchStats(mode: GameMode.quickMatch, percent: 40),
          day,
        ),
        0,
      );
      expect(
        progress.applyMatchToDaily(
          const MatchStats(
            mode: GameMode.quickMatch,
            percent: 30,
            victory: true,
          ),
          day,
        ),
        kDailyChallengeBonusPoints,
      );
    });

    test('survival seconds only count Survival runs, best run wins', () {
      final day = dayWithChallenge('survive_90');
      final progress = GameProgress.defaults();

      // Survival seconds from another mode are ignored.
      progress.applyMatchToDaily(
        const MatchStats(
          mode: GameMode.classic,
          percent: 15,
          survivalSeconds: 200,
        ),
        day,
      );
      expect(progress.dailyProgress, 0);

      progress.applyMatchToDaily(
        const MatchStats(
          mode: GameMode.survival,
          percent: 22,
          survivalSeconds: 45,
        ),
        day,
      );
      expect(progress.dailyProgress, 45);
      expect(
        progress.applyMatchToDaily(
          const MatchStats(
            mode: GameMode.survival,
            percent: 30,
            survivalSeconds: 95,
          ),
          day,
        ),
        kDailyChallengeBonusPoints,
      );
    });

    test('a Classic clear challenge needs a Classic win', () {
      final day = dayWithChallenge('classic_win');
      final progress = GameProgress.defaults();

      expect(
        progress.applyMatchToDaily(
          const MatchStats(
            mode: GameMode.quickMatch,
            percent: 30,
            victory: true,
          ),
          day,
        ),
        0,
      );
      expect(
        progress.applyMatchToDaily(
          const MatchStats(
            mode: GameMode.classic,
            percent: 35,
            victory: true,
          ),
          day,
        ),
        kDailyChallengeBonusPoints,
      );
    });
  });

  group('Day rollover and streaks', () {
    test('a new day starts with fresh progress and can pay again', () {
      final day1 = DateTime(2026, 4, 10);
      final day2 = plusDays(day1, 1);
      final progress = GameProgress.defaults();

      expect(
        progress.applyMatchToDaily(completingStats(day1), day1),
        kDailyChallengeBonusPoints,
      );
      expect(progress.dailyCompleted, isTrue);

      // The new day can pay its own bonus.
      expect(
        progress.applyMatchToDaily(completingStats(day2), day2),
        kDailyChallengeBonusPoints,
      );
      expect(progress.dailyDate, dateKeyFor(day2));
      expect(progress.dailyCompleted, isTrue);

      final fresh = GameProgress.defaults();
      fresh.applyMatchToDaily(completingStats(day1), day1);
      expect(
        fresh.applyMatchToDaily(
          const MatchStats(mode: GameMode.classic, percent: 0),
          day2,
        ),
        0,
      );
      expect(fresh.dailyCompleted, isFalse);
      expect(fresh.dailyProgress, 0);
    });

    test('completing on consecutive days grows the streak', () {
      final day1 = DateTime(2026, 5, 1);
      final progress = GameProgress.defaults();

      progress.applyMatchToDaily(completingStats(day1), day1);
      expect(progress.streakDays, 1);

      final day2 = plusDays(day1, 1);
      progress.applyMatchToDaily(completingStats(day2), day2);
      expect(progress.streakDays, 2);

      final day3 = plusDays(day1, 2);
      progress.applyMatchToDaily(completingStats(day3), day3);
      expect(progress.streakDays, 3);
    });

    test('the streak survives into the next day, then breaks', () {
      final day1 = DateTime(2026, 6, 20);
      final progress = GameProgress.defaults();
      progress.applyMatchToDaily(completingStats(day1), day1);
      expect(progress.streakDays, 1);

      // Next day, before playing: the date rolls, streak still alive.
      expect(progress.syncToDay(plusDays(day1, 1)), isTrue);
      expect(progress.streakDays, 1);

      // Two days later it has broken.
      expect(progress.syncToDay(plusDays(day1, 2)), isTrue);
      expect(progress.streakDays, 0);
    });

    test('completing after a missed day restarts the streak at 1', () {
      final day1 = DateTime(2026, 7, 4);
      final progress = GameProgress.defaults();
      progress.applyMatchToDaily(completingStats(day1), day1);
      expect(progress.streakDays, 1);

      final day3 = plusDays(day1, 2);
      progress.applyMatchToDaily(completingStats(day3), day3);
      expect(progress.streakDays, 1);
    });

    test('syncToDay is a no-op within the same day', () {
      final day = DateTime(2026, 8, 9);
      final progress = GameProgress.defaults();
      expect(progress.syncToDay(day), isTrue); // first roll onto the day
      expect(progress.syncToDay(day), isFalse);
      expect(progress.syncToDay(DateTime(2026, 8, 9, 23, 30)), isFalse);
    });
  });

  group('Ranks', () {
    test('thresholds map lifetime points to the right rank', () {
      expect(rankForLifetime(0).name, 'Bronze');
      expect(rankForLifetime(499).name, 'Bronze');
      expect(rankForLifetime(500).name, 'Silver');
      expect(rankForLifetime(1499).name, 'Silver');
      expect(rankForLifetime(1500).name, 'Gold');
      expect(rankForLifetime(3499).name, 'Gold');
      expect(rankForLifetime(3500).name, 'Platinum');
      expect(rankForLifetime(6999).name, 'Platinum');
      expect(rankForLifetime(7000).name, 'Diamond');
      expect(rankForLifetime(999999).name, 'Diamond');
    });

    test('the ladder climbs Bronze to Diamond in order', () {
      expect(
        kRanks.map((r) => r.name),
        ['Bronze', 'Silver', 'Gold', 'Platinum', 'Diamond'],
      );
    });

    test('progress toward the next rank', () {
      expect(rankProgressToNext(0), 0.0);
      expect(rankProgressToNext(250), 0.5); // halfway Bronze -> Silver
      expect(rankProgressToNext(500), 0.0); // just reached Silver
      expect(rankProgressToNext(1000), 0.5); // halfway Silver -> Gold
      expect(rankProgressToNext(7000), 1.0); // Diamond is full
      expect(rankProgressToNext(999999), 1.0);
    });

    test('points still needed to climb', () {
      expect(pointsToNextRank(0), 500);
      expect(nextRankForLifetime(0)!.name, 'Silver');
      expect(pointsToNextRank(499), 1);
      expect(pointsToNextRank(1500), 2000);
      expect(nextRankForLifetime(7000), isNull);
      expect(pointsToNextRank(7000), 0);
    });
  });

  group('Progress: lifetime points and daily state', () {
    test('earning raises wallet and lifetime; spending only the wallet', () {
      final progress = GameProgress.defaults();
      progress.addPoints(400);
      expect(progress.points, 400);
      expect(progress.lifetimePoints, 400);

      expect(progress.unlockSkin('ocean_drop'), isTrue); // costs 120
      expect(progress.points, 280);
      expect(progress.lifetimePoints, 400);

      progress.addPoints(-50);
      progress.addPoints(0);
      expect(progress.points, 280);
      expect(progress.lifetimePoints, 400);
    });

    test('a fresh progress cannot hold lifetime below its balance', () {
      final progress = GameProgress(points: 100, lifetimePoints: 40);
      expect(progress.lifetimePoints, 100);
    });

    test('JSON round-trip keeps lifetime, daily and streak fields', () {
      final day = DateTime(2026, 9, 15);
      final progress = GameProgress.defaults();
      progress.addPoints(700);
      progress.applyMatchToDaily(completingStats(day), day);
      progress.applyMatchToDaily(
        completingStats(plusDays(day, 1)),
        plusDays(day, 1),
      );

      final restored = GameProgress.fromJson(
        jsonDecode(jsonEncode(progress.toJson())) as Map<String, dynamic>,
      );

      expect(restored.points, progress.points);
      expect(restored.lifetimePoints, progress.lifetimePoints);
      expect(restored.streakDays, 2);
      expect(restored.dailyCompleted, progress.dailyCompleted);
      expect(restored.dailyProgress, progress.dailyProgress);
      expect(restored.dailyDate, dateKeyFor(plusDays(day, 1)));
      expect(
        restored.lastDailyCompletedDate,
        dateKeyFor(plusDays(day, 1)),
      );
    });

    test('an old (Stage B) save migrates safely', () {
      final oldSave = <String, dynamic>{
        'version': 1,
        'highestUnlockedLevel': 3,
        'bestPercents': {'1': 12.5},
        'bestSurvivalSeconds': {'1': 75},
        'muted': true,
        'points': 320,
        'unlockedSkinIds': ['coral_drop', 'ocean_drop'],
        'selectedSkinId': 'ocean_drop',
      };

      final progress = GameProgress.fromJson(oldSave);

      // Lifetime falls back to the wallet balance; daily/streak fresh.
      expect(progress.lifetimePoints, 320);
      expect(progress.streakDays, 0);
      expect(progress.dailyCompleted, isFalse);
      expect(progress.dailyProgress, 0);
      expect(progress.dailyDate, isNull);
      expect(progress.lastDailyCompletedDate, isNull);

      // And everything keeps working from there.
      progress.addPoints(180);
      expect(progress.points, 500);
      expect(progress.lifetimePoints, 500);
      expect(rankForLifetime(progress.lifetimePoints).name, 'Silver');
    });

    test('malformed daily fields fall back to safe defaults', () {
      final progress = GameProgress.fromJson(<String, dynamic>{
        'points': 10,
        'lifetimePoints': 'lots',
        'dailyDate': 42,
        'dailyProgress': 'far',
        'dailyCompleted': 'yes',
        'streakDays': -3,
      });

      expect(progress.lifetimePoints, 10);
      expect(progress.dailyDate, isNull);
      expect(progress.dailyProgress, 0);
      expect(progress.dailyCompleted, isFalse);
      expect(progress.streakDays, 0);
    });
  });
}
