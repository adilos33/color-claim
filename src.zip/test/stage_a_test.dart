import 'dart:convert';

import 'package:color_claim/game/arena.dart';
import 'package:color_claim/game/game_mode.dart';
import 'package:color_claim/game/progress.dart';
import 'package:color_claim/game/territory_engine.dart';
import 'package:flutter_test/flutter_test.dart';

/// Clears every playable owner while leaving blocked cells blocked.
void wipePlayable(TerritoryEngine engine) {
  for (var i = 0; i < engine.owners.length; i++) {
    if (engine.owners[i] != TerritoryEngine.blockedOwner) {
      engine.owners[i] = -1;
    }
  }
}

void claimFirstCells(TerritoryEngine engine, int actorId, int count) {
  var placed = 0;
  for (var i = 0; i < engine.owners.length && placed < count; i++) {
    if (engine.owners[i] == -1) {
      engine.owners[i] = actorId;
      placed++;
    }
  }
}

void main() {
  group('ArenaMask', () {
    test('open arena has no blocked cells', () {
      final mask = ArenaMask.generate(ArenaShape.open);
      expect(mask.playableCells, TerritoryEngine.totalCells);
      expect(mask.blocked.where((b) => b), isEmpty);
    });

    test('circle arena blocks the corners only', () {
      final mask = ArenaMask.generate(ArenaShape.circle);
      expect(mask.isBlocked(0, 0), isTrue);
      expect(mask.isBlocked(55, 55), isTrue);
      expect(mask.isBlocked(27, 27), isFalse);
      expect(mask.isBlocked(27, 2), isFalse);
      expect(mask.playableCells, lessThan(TerritoryEngine.totalCells));
      expect(mask.playableCells, greaterThan(1500));
    });

    test('ring arena blocks the core, not the edges', () {
      final mask = ArenaMask.generate(ArenaShape.ring);
      expect(mask.isBlocked(28, 28), isTrue);
      expect(mask.isBlocked(27, 27), isTrue);
      expect(mask.isBlocked(0, 0), isFalse);
      expect(mask.isBlocked(28, 10), isFalse);
    });

    test('cross arena keeps only the two channels playable', () {
      final mask = ArenaMask.generate(ArenaShape.cross);
      expect(mask.isBlocked(0, 0), isTrue);
      expect(mask.isBlocked(10, 10), isTrue);
      expect(mask.isBlocked(27, 27), isFalse);
      expect(mask.isBlocked(27, 0), isFalse); // vertical bar
      expect(mask.isBlocked(0, 27), isFalse); // horizontal bar
      expect(mask.isBlocked(55, 27), isFalse);
    });

    test('islands arena blocks four rocks away from the spawns', () {
      final mask = ArenaMask.generate(ArenaShape.islands);
      expect(mask.isBlocked(20, 20), isTrue);
      expect(mask.isBlocked(36, 36), isTrue);
      expect(mask.isBlocked(28, 28), isFalse);
      // Spawn points stay playable except where a shape legitimately
      // covers them (ring core, cross corners); the engine resolves
      // those onto playable cells, which is tested below.
      const spawns = [
        (12, 43),
        (43, 12),
        (12, 12),
        (43, 43),
        (28, 28),
        (28, 10),
      ];
      const covered = {
        ArenaShape.ring: [(28, 28)],
        ArenaShape.cross: [(12, 43), (43, 12), (12, 12), (43, 43)],
      };
      for (final shape in ArenaShape.values) {
        final m = ArenaMask.generate(shape);
        for (final s in spawns) {
          final expectBlocked = (covered[shape] ?? const []).contains(s);
          expect(m.isBlocked(s.$1, s.$2), expectBlocked, reason: '$shape $s');
        }
      }
    });

    test('levels use a variety of arena shapes', () {
      final shapes = kLevels.map((l) => l.shape).toSet();
      expect(shapes.length, greaterThanOrEqualTo(4));
      expect(kLevels[0].shape, ArenaShape.open);
    });
  });

  group('TerritoryEngine arenas', () {
    test('spawns resolve onto playable cells on every level', () {
      for (final level in kLevels) {
        final engine = TerritoryEngine(level, seed: 7);
        expect(
          engine.playableCells,
          level.shape == ArenaShape.open
              ? TerritoryEngine.totalCells
              : lessThan(TerritoryEngine.totalCells),
        );
        for (final actor in engine.actors) {
          expect(
            engine.mask.isBlocked(actor.x, actor.y),
            isFalse,
            reason: '${level.name} actor ${actor.name} in a wall',
          );
          expect(engine.percentFor(actor.id), greaterThan(0));
        }
        // Blocked cells are marked and never owned.
        for (var i = 0; i < engine.owners.length; i++) {
          if (engine.mask.isBlockedCell(i)) {
            expect(engine.owners[i], TerritoryEngine.blockedOwner);
          }
        }
        final sum = engine.actors.fold<double>(
          0,
          (s, a) => s + engine.percentFor(a.id),
        );
        expect(sum, lessThanOrEqualTo(100.0));
      }
    });

    test('percent denominator excludes blocked cells', () {
      final engine = TerritoryEngine(kLevels[2], seed: 7); // circle arena
      final count = engine.owners.where((o) => o == 0).length;
      expect(engine.playableCells, lessThan(TerritoryEngine.totalCells));
      expect(
        engine.playerPercent,
        closeTo(count * 100.0 / engine.playableCells, 0.0001),
      );
      // The same cell count reads as a bigger % than on the full grid.
      expect(
        engine.playerPercent,
        greaterThan(count * 100.0 / TerritoryEngine.totalCells),
      );
    });

    test('capture claims around a blocked core without claiming it', () {
      final engine = TerritoryEngine(kLevels[5], seed: 5); // ring arena
      final player = engine.player;
      wipePlayable(engine);

      // Small home block the loop hangs off.
      for (var y = 24; y <= 27; y++) {
        for (var x = 16; x <= 19; x++) {
          engine.owners[engine.idx(x, y)] = 0;
        }
      }

      // Rectangular trail loop around the blocked core (14..41, 12..43),
      // wide enough that the trail itself never touches the core.
      final trail = <(int, int)>[];
      for (var x = 14; x <= 41; x++) {
        trail.add((x, 12));
        trail.add((x, 43));
      }
      for (var y = 13; y <= 42; y++) {
        trail.add((14, y));
        trail.add((41, y));
      }
      for (final c in trail) {
        final i = engine.idx(c.$1, c.$2);
        player.trail.add(i);
        player.trailSet.add(i);
      }

      final gained = engine.captureTrail(player);
      expect(gained, greaterThan(0));
      // Playable interior cells are claimed...
      expect(engine.owners[engine.idx(22, 20)], 0);
      expect(engine.owners[engine.idx(34, 36)], 0);
      // ...but blocked core cells are never claimed.
      expect(engine.owners[engine.idx(27, 27)], TerritoryEngine.blockedOwner);
      expect(engine.owners[engine.idx(28, 28)], TerritoryEngine.blockedOwner);
      // Exterior playable cells stay neutral.
      expect(engine.owners[engine.idx(5, 5)], -1);
      expect(engine.owners[engine.idx(50, 50)], -1);
      // No blocked cell anywhere ended up owned by anyone.
      for (var i = 0; i < engine.owners.length; i++) {
        if (engine.mask.isBlockedCell(i)) {
          expect(engine.owners[i], TerritoryEngine.blockedOwner);
        }
      }
    });

    test('bots play on obstacle arenas without entering blocked cells', () {
      for (final level in [kLevels[1], kLevels[3], kLevels[5]]) {
        final engine = TerritoryEngine(level, seed: 11);
        for (var step = 0; step < 300; step++) {
          engine.step();
          for (final a in engine.actors) {
            expect(a.x, inInclusiveRange(0, TerritoryEngine.cols - 1));
            expect(a.y, inInclusiveRange(0, TerritoryEngine.rows - 1));
            expect(
              engine.mask.isBlocked(a.x, a.y),
              isFalse,
              reason: '${level.name} step $step: ${a.name} inside a wall',
            );
            for (final cell in a.trailSet) {
              expect(engine.mask.isBlockedCell(cell), isFalse);
            }
          }
        }
        final sum = engine.actors.fold<double>(
          0,
          (s, a) => s + engine.percentFor(a.id),
        );
        expect(sum, lessThanOrEqualTo(100.0));
      }
    });
  });

  group('Modes', () {
    test('initial lives follow the mode configuration', () {
      final classic = TerritoryEngine(kLevels[0], seed: 7);
      expect(classic.maxLives, 3);
      expect(classic.lives, 3);

      final survival = TerritoryEngine(kLevels[0], seed: 7, initialLives: 1);
      expect(survival.maxLives, 1);
      expect(survival.lives, 1);
    });

    test('survival ends on the first death', () {
      final engine = TerritoryEngine(kLevels[0], seed: 7, initialLives: 1);
      wipePlayable(engine);
      final player = engine.player;
      player.x = 10;
      player.y = 10;
      player.prevX = 10;
      player.prevY = 10;
      player.dx = 1;
      player.dy = 0;
      // The player's own exposed trail sits on the next cell: fatal.
      final cell = engine.idx(11, 10);
      player.trail.add(cell);
      player.trailSet.add(cell);

      engine.step();

      expect(engine.lives, 0);
      expect(engine.gameOver, isTrue);
      expect(engine.player.alive, isFalse);
    });

    test('quick standing and goal-while-leading evaluation', () {
      final engine = TerritoryEngine(kLevels[0], seed: 7);
      wipePlayable(engine);

      claimFirstCells(engine, 0, 400); // 12.75% of the open board
      var standing = quickStanding(engine);
      expect(standing.isLeading, isTrue);
      expect(standing.rank, 1);
      expect(quickGoalWhileLeading(engine), isTrue); // goal is 10%

      claimFirstCells(engine, 1, 600); // bot jumps ahead
      standing = quickStanding(engine);
      expect(standing.isLeading, isFalse);
      expect(standing.rank, 2);
      expect(standing.leaderName, kBotNames[0]);
      expect(quickGoalWhileLeading(engine), isFalse);
    });
  });

  group('GameProgress survival records', () {
    test('recordSurvival keeps only the longest time', () {
      final progress = GameProgress.defaults();

      expect(progress.bestSurvivalForLevel(1), 0);
      expect(progress.recordSurvival(1, 75), isTrue);
      expect(progress.bestSurvivalForLevel(1), 75);
      expect(progress.recordSurvival(1, 60), isFalse);
      expect(progress.recordSurvival(1, 75), isFalse);
      expect(progress.recordSurvival(1, 121), isTrue);
      expect(progress.bestSurvivalForLevel(1), 121);
    });

    test('survival times round-trip through JSON', () {
      final progress = GameProgress.defaults()
        ..recordSurvival(2, 95)
        ..recordBest(2, 21.5);

      final restored = GameProgress.fromJson(
        jsonDecode(jsonEncode(progress.toJson())) as Map<String, dynamic>,
      );

      expect(restored.bestSurvivalForLevel(2), 95);
      expect(restored.bestForLevel(2), 21.5);
      expect(restored.toJson(), progress.toJson());
    });

    test('old saves without survival entries still load', () {
      final restored = GameProgress.fromJson({
        'version': 1,
        'highestUnlockedLevel': 3,
        'bestPercents': {'1': 12.0},
        'muted': true,
      });

      expect(restored.highestUnlockedLevel, 3);
      expect(restored.bestForLevel(1), 12.0);
      expect(restored.bestSurvivalForLevel(1), 0);
      expect(restored.muted, isTrue);
    });
  });
}
