import 'package:color_claim/game/territory_engine.dart';
import 'package:flutter_test/flutter_test.dart';

void main() {
  group('TerritoryEngine', () {
    test('initial player percent matches its starting circle', () {
      final engine = TerritoryEngine(kLevels[0], seed: 7);
      // Starting circle radius 4 -> 49 cells (counted by the distance rule).
      final expected = engine.owners.where((o) => o == 0).length;
      expect(
        engine.playerPercent,
        closeTo(expected * 100 / TerritoryEngine.totalCells, 0.0001),
      );
      expect(engine.playerPercent, greaterThan(1.0));
      expect(engine.playerPercent, lessThan(3.0));
    });

    test('captureTrail claims the trail and the enclosed area', () {
      final engine = TerritoryEngine(kLevels[0], seed: 7);
      final player = engine.player;

      // Wipe the board, then give the player a small home block.
      for (var i = 0; i < engine.owners.length; i++) {
        engine.owners[i] = -1;
      }
      for (var y = 20; y <= 23; y++) {
        for (var x = 20; x <= 23; x++) {
          engine.owners[engine.idx(x, y)] = 0;
        }
      }

      // Draw a rectangular trail loop attached to the home block that
      // encloses a 3x3 neutral pocket at (25..27, 20..22)-ish.
      final trailCells = <(int, int)>[
        (24, 19),
        (25, 19),
        (26, 19),
        (27, 19),
        (28, 19),
        (28, 20),
        (28, 21),
        (28, 22),
        (28, 23),
        (27, 23),
        (26, 23),
        (25, 23),
        (24, 23),
      ];
      for (final c in trailCells) {
        final i = engine.idx(c.$1, c.$2);
        player.trail.add(i);
        player.trailSet.add(i);
      }
      final before = engine.playerPercent;
      final gained = engine.captureTrail(player);

      expect(gained, greaterThan(0));
      expect(engine.playerPercent, greaterThan(before));
      // The enclosed neutral cells must now belong to the player.
      expect(engine.owners[engine.idx(26, 21)], 0);
      expect(engine.owners[engine.idx(25, 20)], 0);
      // Trail cells claimed too, and the trail is cleared.
      expect(engine.owners[engine.idx(28, 21)], 0);
      expect(player.trail, isEmpty);
      // A far-away neutral cell stays neutral.
      expect(engine.owners[engine.idx(45, 45)], -1);
      // Percent agrees with an independent recount.
      final recount = engine.owners.where((o) => o == 0).length;
      expect(
        engine.playerPercent,
        closeTo(recount * 100 / TerritoryEngine.totalCells, 0.0001),
      );
    });

    test('stepping through a loop and coming home grows territory', () {
      final engine = TerritoryEngine(kLevels[0], seed: 7);
      final before = engine.playerPercent;

      // Walk a square loop: right, down, left, up back into home.
      void walk(int dx, int dy, int steps) {
        engine.setPlayerDirection(dx, dy);
        for (var i = 0; i < steps; i++) {
          engine.step();
        }
      }

      // Player starts at the center of its home circle heading up.
      // Move up out of home first.
      walk(0, -1, 7); // exits home, trail starts
      walk(1, 0, 6);
      walk(0, 1, 12);
      walk(-1, 0, 6);
      walk(0, -1, 10); // re-enters home -> capture
      expect(engine.playerPercent, greaterThan(before));
      expect(engine.gameOver, isFalse);
    });

    test('leaderboard is sorted by percent descending', () {
      final engine = TerritoryEngine(kLevels[0], seed: 7);
      final board = engine.leaderboard;
      for (var i = 1; i < board.length; i++) {
        expect(
          engine.percentFor(board[i - 1].id),
          greaterThanOrEqualTo(engine.percentFor(board[i].id)),
        );
      }
    });

    test('engine runs many steps without errors or going out of bounds', () {
      final engine = TerritoryEngine(kLevels[5], seed: 3);
      for (var i = 0; i < 600; i++) {
        // Wiggle the player around.
        if (i % 25 == 0) engine.setPlayerDirection(1, 0);
        if (i % 25 == 12) engine.setPlayerDirection(0, 1);
        engine.step();
        for (final a in engine.actors) {
          expect(a.x, inInclusiveRange(0, TerritoryEngine.cols - 1));
          expect(a.y, inInclusiveRange(0, TerritoryEngine.rows - 1));
        }
      }
      final sum = engine.actors.fold<double>(
        0,
        (s, a) => s + engine.percentFor(a.id),
      );
      expect(sum, lessThanOrEqualTo(100.0));
    });
  });
}
