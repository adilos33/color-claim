import 'dart:convert';

import 'package:color_claim/game/points.dart';
import 'package:color_claim/game/powerups.dart';
import 'package:color_claim/game/progress.dart';
import 'package:color_claim/game/skins.dart';
import 'package:color_claim/game/territory_engine.dart';
import 'package:flutter_test/flutter_test.dart';

/// Sets every playable cell neutral (blocked cells keep their sentinel).
void wipePlayable(TerritoryEngine engine) {
  for (var i = 0; i < engine.owners.length; i++) {
    if (engine.owners[i] != TerritoryEngine.blockedOwner) {
      engine.owners[i] = -1;
    }
  }
}

/// Freezes bots in place for the rest of the test: dead, with a respawn
/// timer far beyond the number of steps the test runs.
void parkBots(TerritoryEngine engine) {
  for (final bot in engine.actors.skip(1)) {
    bot.alive = false;
    bot.respawnSteps = 100000;
  }
}

/// Teleports the player to (x, y), standing still there, facing (dx, dy).
void placePlayer(TerritoryEngine engine, int x, int y, int dx, int dy) {
  final p = engine.player;
  p.x = x;
  p.y = y;
  p.prevX = x;
  p.prevY = y;
  p.dx = dx;
  p.dy = dy;
  p.moveAcc = 0;
}

void main() {
  group('Pickup spawning', () {
    test('spawnPickup only lands on unowned playable cells', () {
      for (final level in kLevels) {
        final engine = TerritoryEngine(level, seed: 3);
        for (var n = 0; n < 40; n++) {
          engine.pickups.clear();
          expect(engine.spawnPickup(), isTrue, reason: level.name);
          final p = engine.pickups.single;
          final cell = engine.idx(p.x, p.y);
          expect(engine.mask.isBlockedCell(cell), isFalse, reason: level.name);
          expect(engine.owners[cell], -1, reason: level.name);
          expect(
            engine.actors.any((a) => a.x == p.x && a.y == p.y),
            isFalse,
            reason: level.name,
          );
          for (final a in engine.actors) {
            expect(a.trailSet.contains(cell), isFalse, reason: level.name);
          }
        }
      }
    });

    test('spawnPickup respects the on-field cap', () {
      final engine = TerritoryEngine(kLevels[0], seed: 3);
      var placed = 0;
      while (engine.spawnPickup()) {
        placed++;
      }
      expect(placed, kMaxPickupsOnField);
      expect(engine.pickups.length, kMaxPickupsOnField);
      expect(engine.spawnPickup(), isFalse);
      // All live pickups sit on distinct cells.
      final cells = engine.pickups.map((p) => engine.idx(p.x, p.y)).toSet();
      expect(cells.length, engine.pickups.length);
    });

    test('spawnPickup finds the only neutral cells on a claimed board', () {
      final engine = TerritoryEngine(kLevels[0], seed: 3);
      // Player owns everything playable except three cells.
      for (var i = 0; i < engine.owners.length; i++) {
        if (engine.owners[i] != TerritoryEngine.blockedOwner) {
          engine.owners[i] = 0;
        }
      }
      for (final c in [(5, 5), (6, 5), (50, 50)]) {
        engine.owners[engine.idx(c.$1, c.$2)] = -1;
      }
      const allowed = {(5, 5), (6, 5), (50, 50)};
      final seen = <(int, int)>{};
      for (var n = 0; n < 2; n++) {
        expect(engine.spawnPickup(), isTrue);
        final p = engine.pickups.last;
        expect(allowed.contains((p.x, p.y)), isTrue);
        seen.add((p.x, p.y));
      }
      expect(seen.length, 2); // two distinct cells used
    });

    test('a capture sweeps pickups it swallows, keeps the rest', () {
      final engine = TerritoryEngine(kLevels[0], seed: 7);
      final player = engine.player;
      wipePlayable(engine);
      for (var y = 20; y <= 23; y++) {
        for (var x = 20; x <= 23; x++) {
          engine.owners[engine.idx(x, y)] = 0;
        }
      }
      // Same rectangular loop as the engine capture test: encloses a
      // pocket around (25..27, 20..22).
      final trailCells = <(int, int)>[
        (24, 19), (25, 19), (26, 19), (27, 19), (28, 19),
        (28, 20), (28, 21), (28, 22), (28, 23),
        (27, 23), (26, 23), (25, 23), (24, 23),
      ];
      for (final c in trailCells) {
        final i = engine.idx(c.$1, c.$2);
        player.trail.add(i);
        player.trailSet.add(i);
      }
      engine.pickups.add(
        const PowerUpPickup(kind: PowerUpKind.speed, x: 26, y: 21),
      );
      engine.pickups.add(
        const PowerUpPickup(kind: PowerUpKind.shield, x: 45, y: 45),
      );

      final gained = engine.captureTrail(player);

      expect(gained, greaterThan(0));
      expect(engine.pickups.length, 1);
      expect(engine.pickups.single.x, 45);
      expect(engine.pickups.single.y, 45);
    });

    test('stepping onto a pickup collects its effect', () {
      final engine = TerritoryEngine(kLevels[0], seed: 7);
      final player = engine.player;
      parkBots(engine);
      // Player spawns at (12, 43) heading up; place a shield ahead.
      engine.pickups.add(
        PowerUpPickup(kind: PowerUpKind.shield, x: player.x, y: player.y - 1),
      );
      engine.step();
      expect(engine.pickups, isEmpty);
      expect(player.hasShield, isTrue);
      expect(player.shieldSteps, kShieldSteps - 1);
      expect(engine.pickupEvents, 1);
      expect(engine.lastPickupByPlayer, isTrue);
      expect(engine.lastPickupKind, PowerUpKind.shield);
    });

    test('bots collect pickups too (freeze turns on the player)', () {
      final engine = TerritoryEngine(kLevels[0], seed: 7);
      final bot = engine.actors[1];
      // Quiet corner for the player; it just idles there.
      placePlayer(engine, 3, 52, 0, -1);
      // Walk the bot straight up through a freeze pickup: an explicit
      // target above it makes its steering deterministic.
      bot.x = 30;
      bot.y = 29;
      bot.prevX = 30;
      bot.prevY = 29;
      bot.dx = 0;
      bot.dy = -1;
      bot.trail.clear();
      bot.trailSet.clear();
      bot.hasTarget = true;
      bot.phase = 1;
      bot.targetX = 30;
      bot.targetY = 20;
      bot.moveAcc = 0.99; // one move on the next step, no more
      engine.pickups.add(
        const PowerUpPickup(kind: PowerUpKind.freeze, x: 30, y: 28),
      );

      engine.step();

      expect(engine.pickups, isEmpty);
      expect(engine.playerFrozenSteps, kFreezeSteps - 1);
      expect(engine.botsFrozenSteps, 0);
      expect(engine.lastPickupByPlayer, isFalse);
      expect(engine.lastPickupKind, PowerUpKind.freeze);
    });
  });

  group('Effects', () {
    test('speed boost covers more ground than walking', () {
      int run({required bool boosted}) {
        final engine = TerritoryEngine(kLevels[0], seed: 7);
        parkBots(engine);
        placePlayer(engine, 28, 44, 0, -1);
        if (boosted) engine.player.speedBoostSteps = 1000;
        final startY = engine.player.y;
        for (var i = 0; i < 10; i++) {
          engine.step();
        }
        return startY - engine.player.y;
      }

      final walked = run(boosted: false);
      final boosted = run(boosted: true);
      expect(walked, 10);
      expect(boosted, greaterThanOrEqualTo(walked + 3));
    });

    test('freeze roughly halves bot movement', () {
      int botMoves({required bool frozen}) {
        final engine = TerritoryEngine(kLevels[0], seed: 7);
        final bot = engine.actors[1];
        if (frozen) engine.botsFrozenSteps = 100000;
        var moves = 0;
        var px = bot.x;
        var py = bot.y;
        for (var i = 0; i < 20; i++) {
          engine.step();
          if (bot.x != px || bot.y != py) moves++;
          px = bot.x;
          py = bot.y;
        }
        return moves;
      }

      final normal = botMoves(frozen: false);
      final frozen = botMoves(frozen: true);
      expect(normal, greaterThanOrEqualTo(8));
      expect(frozen, greaterThanOrEqualTo(2));
      expect(frozen, lessThanOrEqualTo(normal * 0.7));
    });

    test('timers count down and expire', () {
      final engine = TerritoryEngine(kLevels[0], seed: 7);
      final player = engine.player;
      player.speedBoostSteps = 3;
      player.hasShield = true;
      player.shieldSteps = 2;
      engine.botsFrozenSteps = 2;

      engine.step();
      expect(player.speedBoostSteps, 2);
      expect(player.hasShield, isTrue);
      expect(engine.botsFrozenSteps, 1);

      engine.step();
      expect(player.speedBoostSteps, 1);
      expect(player.hasShield, isFalse); // shield timer ran out unused
      expect(player.shieldSteps, 0);
      expect(engine.botsFrozenSteps, 0);

      engine.step();
      expect(player.speedBoostSteps, 0);
    });

    test('shield blocks one cut, then the next cut kills', () {
      final engine = TerritoryEngine(kLevels[0], seed: 7);
      final player = engine.player;
      wipePlayable(engine);
      placePlayer(engine, 10, 10, 1, 0);
      player.hasShield = true;
      player.shieldSteps = 500;

      // Own exposed trail on the next cell: normally fatal.
      var cell = engine.idx(11, 10);
      player.trail.add(cell);
      player.trailSet.add(cell);
      engine.step();

      expect(engine.lives, 3);
      expect(player.alive, isTrue);
      expect(engine.gameOver, isFalse);
      expect(player.hasShield, isFalse); // shield consumed
      expect(player.invulnSteps, kInvulnSteps - 1);
      expect(player.trail, isEmpty); // the cut still erased the trail
      expect(engine.shieldBreakEvents, 1);

      // Invulnerability spent and no shield: the same cut now kills.
      player.invulnSteps = 0;
      cell = engine.idx(player.x + 1, player.y);
      player.trail.add(cell);
      player.trailSet.add(cell);
      engine.step();

      expect(engine.lives, 2);
      expect(player.alive, isTrue); // respawned with lives left
      expect(engine.gameOver, isFalse);
    });

    test('invulnerability also blocks a cut without a shield', () {
      final engine = TerritoryEngine(kLevels[0], seed: 7);
      final player = engine.player;
      wipePlayable(engine);
      placePlayer(engine, 10, 10, 1, 0);
      player.invulnSteps = 30;

      final cell = engine.idx(11, 10);
      player.trail.add(cell);
      player.trailSet.add(cell);
      engine.step();

      expect(engine.lives, 3);
      expect(player.alive, isTrue);
      // The blocked cut refreshes the invulnerability window.
      expect(player.invulnSteps, kInvulnSteps - 1);
    });

    test('player color override applies at spawn', () {
      final custom = TerritoryEngine(
        kLevels[0],
        seed: 7,
        playerColorArgb: 0xFF123456,
      );
      expect(custom.player.colorArgb, 0xFF123456);
      final standard = TerritoryEngine(kLevels[0], seed: 7);
      expect(standard.player.colorArgb, kPlayerColor);
    });
  });

  group('Points', () {
    test('matchPoints formula', () {
      var p = matchPoints(percent: 10, knockouts: 0, victory: false);
      expect(p.percentPoints, 20);
      expect(p.knockoutPoints, 0);
      expect(p.winBonus, 0);
      expect(p.total, 20);

      p = matchPoints(percent: 12.5, knockouts: 2, victory: true);
      expect(p.percentPoints, 25);
      expect(p.knockoutPoints, 2 * kPointsPerKnockout);
      expect(p.winBonus, kWinBonusPoints);
      expect(p.total, 25 + 50 + kWinBonusPoints);

      p = matchPoints(percent: 0, knockouts: 0, victory: false);
      expect(p.total, 0);
    });

    test('wallet accumulates and ignores non-positive awards', () {
      final progress = GameProgress.defaults();
      expect(progress.points, 0);
      progress.addPoints(70);
      progress.addPoints(30);
      expect(progress.points, 100);
      progress.addPoints(0);
      progress.addPoints(-25);
      expect(progress.points, 100);
    });
  });

  group('Skins', () {
    test('catalog has eight original skins with a free default', () {
      expect(kSkins.length, 8);
      expect(kSkins.first.id, kDefaultSkinId);
      expect(kSkins.first.price, 0);
      final ids = kSkins.map((s) => s.id).toSet();
      expect(ids.length, kSkins.length);
      for (final skin in kSkins) {
        expect(skin.price, greaterThanOrEqualTo(0));
        expect(skinById(skin.id), skin);
      }
      expect(skinById('does_not_exist'), kCoralDropSkin);
    });

    test('defaults own and wear the free skin', () {
      final progress = GameProgress.defaults();
      expect(progress.isSkinUnlocked(kDefaultSkinId), isTrue);
      expect(progress.selectedSkinId, kDefaultSkinId);
      expect(progress.isSkinUnlocked('ocean_drop'), isFalse);
    });

    test('unlock needs points, charges once, and select requires owning', () {
      final progress = GameProgress.defaults();
      final ocean = skinById('ocean_drop');

      expect(progress.unlockSkin('ocean_drop'), isFalse); // no points yet
      expect(progress.selectSkin('ocean_drop'), isFalse); // not owned

      progress.addPoints(500);
      expect(progress.unlockSkin('ocean_drop'), isTrue);
      expect(progress.points, 500 - ocean.price);
      expect(progress.isSkinUnlocked('ocean_drop'), isTrue);

      expect(progress.unlockSkin('ocean_drop'), isFalse); // no double charge
      expect(progress.points, 500 - ocean.price);

      expect(progress.selectSkin('ocean_drop'), isTrue);
      expect(progress.selectedSkinId, 'ocean_drop');
      expect(progress.selectSkin('ocean_drop'), isFalse); // already worn
      expect(progress.unlockSkin('does_not_exist'), isFalse);
    });

    test('points and skins round-trip through JSON', () {
      final progress = GameProgress.defaults()
        ..addPoints(1500)
        ..unlockSkin('ocean_drop')
        ..unlockSkin('flame_buddy')
        ..selectSkin('flame_buddy');

      final restored = GameProgress.fromJson(
        jsonDecode(jsonEncode(progress.toJson())) as Map<String, dynamic>,
      );

      expect(restored.points, progress.points);
      expect(restored.isSkinUnlocked('ocean_drop'), isTrue);
      expect(restored.isSkinUnlocked('flame_buddy'), isTrue);
      expect(restored.selectedSkinId, 'flame_buddy');
      expect(restored.toJson(), progress.toJson());
    });

    test('old saves without points/skins still load', () {
      final restored = GameProgress.fromJson({
        'version': 1,
        'highestUnlockedLevel': 3,
        'bestPercents': {'1': 12.0},
        'muted': true,
      });

      expect(restored.highestUnlockedLevel, 3);
      expect(restored.points, 0);
      expect(restored.isSkinUnlocked(kDefaultSkinId), isTrue);
      expect(restored.selectedSkinId, kDefaultSkinId);
    });

    test('a save pointing at a locked/unknown skin falls back safely', () {
      final restored = GameProgress.fromJson({
        'version': 1,
        'points': 40,
        'unlockedSkinIds': ['ocean_drop', 'made_up_skin'],
        'selectedSkinId': 'crystal_gem', // known but not owned
      });

      expect(restored.points, 40);
      expect(restored.isSkinUnlocked('ocean_drop'), isTrue);
      expect(restored.isSkinUnlocked('crystal_gem'), isFalse);
      expect(restored.selectedSkinId, kDefaultSkinId);
    });
  });
}
