import 'dart:convert';

import 'package:color_claim/game/arena.dart';
import 'package:color_claim/game/daily_arena.dart';
import 'package:color_claim/game/nemesis.dart';
import 'package:color_claim/game/progress.dart';
import 'package:color_claim/game/territory_engine.dart';
import 'package:color_claim/theme.dart';
import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'package:color_claim/services/progress_store.dart';

void main() {
  group('Daily Arena seed determinism', () {
    test('same date gives same seed, shape and bot count', () {
      final date = DateTime(2026, 10, 27);
      expect(dailyArenaSeed(date), 20261027);
      expect(dailyArenaSeed(DateTime(2026, 10, 27, 23, 59)), 20261027);
      expect(dailyArenaShape(date), dailyArenaShape(DateTime(2026, 10, 27)));
      expect(
        dailyArenaShape(date),
        ArenaShape.values[20261027 % ArenaShape.values.length],
      );
      expect(dailyArenaLevel(date).botCount, kDailyArenaBotCount);
      expect(kDailyArenaBotCount, 5);
      expect(dailyArenaLevel(date).shape, dailyArenaShape(date));
    });

    test('different dates seed different boards', () {
      expect(
        dailyArenaSeed(DateTime(2026, 10, 27)),
        isNot(dailyArenaSeed(DateTime(2026, 10, 28))),
      );
    });
  });

  group('Daily Arena one recorded attempt per day', () {
    test('first run banks; replays bump attempts but never overwrite', () {
      final progress = GameProgress.defaults();
      final day = DateTime(2026, 10, 27);

      expect(
        progress.recordDailyArena(
          date: day,
          score: 30,
          rank: 2,
          won: true,
        ),
        isTrue,
      );
      final banked = progress.arenaRecordFor(day)!;
      expect(banked.score, 30);
      expect(banked.rank, 2);
      expect(banked.won, isTrue);
      expect(banked.attempts, 1);

      // A much better replay must NOT overwrite the banked result.
      expect(
        progress.recordDailyArena(
          date: day,
          score: 88,
          rank: 1,
          won: true,
        ),
        isFalse,
      );
      final afterReplay = progress.arenaRecordFor(day)!;
      expect(afterReplay.score, 30);
      expect(afterReplay.rank, 2);
      expect(afterReplay.attempts, 2);

      // A worse replay also leaves it standing.
      expect(
        progress.recordDailyArena(
          date: day,
          score: 5,
          rank: 6,
          won: false,
        ),
        isFalse,
      );
      expect(progress.arenaRecordFor(day)!.score, 30);
      expect(progress.arenaRecordFor(day)!.attempts, 3);

      // Another day banks independently.
      expect(
        progress.recordDailyArena(
          date: DateTime(2026, 10, 28),
          score: 12,
          rank: 4,
          won: false,
        ),
        isTrue,
      );
      expect(progress.arenaRecordFor(DateTime(2026, 10, 28))!.score, 12);
    });
  });

  group('Nemesis persistence and difficulty scaling', () {
    test('the Nemesis identity never rotates', () {
      expect(kNemesisName, 'Ember');
      expect(nemesisName, 'Ember');
      expect(nemesisColorArgb, 0xFFFF6A2A);
      final date = DateTime(2026, 10, 27);
      final engine = TerritoryEngine(
        dailyArenaLevel(date),
        seed: dailyArenaSeed(date),
        forceNemesis: true,
      );
      final nemesis = engine.actors.firstWhere((a) => !a.isPlayer);
      expect(nemesis.name, 'Ember');
      expect(nemesis.isHunter, isTrue);
    });

    Map<String, DailyArenaRecord> historyWith({
      required List<(int day, bool won)> days,
    }) {
      final history = <String, DailyArenaRecord>{};
      for (final (day, won) in days) {
        final key = '2026-10-${day.toString().padLeft(2, '0')}';
        history[key] = DailyArenaRecord(
          date: key,
          score: won ? 30 : 10,
          rank: won ? 1 : 4,
          attempts: 1,
          won: won,
        );
      }
      return history;
    }

    test('3+ wins in a row makes the Nemesis aggressive', () {
      final history = historyWith(
        days: [(24, true), (25, true), (26, true)],
      );
      expect(winStreakBefore(history, DateTime(2026, 10, 27)), 3);
      expect(
        nemesisDifficultyFor(history, DateTime(2026, 10, 27)),
        NemesisDifficulty.aggressive,
      );
    });

    test('3+ losses in a row makes the Nemesis back off', () {
      final history = historyWith(
        days: [(24, false), (25, false), (26, false)],
      );
      expect(lossStreakBefore(history, DateTime(2026, 10, 27)), 3);
      expect(
        nemesisDifficultyFor(history, DateTime(2026, 10, 27)),
        NemesisDifficulty.backedOff,
      );
    });

    test('shorter streaks and skipped days stay normal', () {
      expect(
        nemesisDifficultyFor(
          historyWith(days: [(25, true), (26, true)]),
          DateTime(2026, 10, 27),
        ),
        NemesisDifficulty.normal,
      );
      // A skipped day breaks the streak even with older wins.
      expect(
        nemesisDifficultyFor(
          historyWith(days: [(23, true), (24, true), (25, true)]),
          DateTime(2026, 10, 27),
        ),
        NemesisDifficulty.normal,
      );
      expect(
        nemesisDifficultyFor({}, DateTime(2026, 10, 27)),
        NemesisDifficulty.normal,
      );
    });

    test('difficulty multipliers order backed-off < normal < aggressive', () {
      expect(
        NemesisDifficulty.backedOff.speedMultiplier,
        lessThan(NemesisDifficulty.normal.speedMultiplier),
      );
      expect(
        NemesisDifficulty.normal.speedMultiplier,
        lessThan(NemesisDifficulty.aggressive.speedMultiplier),
      );
    });

    test('aggressive Nemesis is actually faster in the engine', () {
      final date = DateTime(2026, 10, 27);
      TerritoryEngine engineFor(NemesisDifficulty d) => TerritoryEngine(
        dailyArenaLevel(date),
        seed: dailyArenaSeed(date),
        forceNemesis: true,
        nemesisSpeedMultiplier: d.speedMultiplier,
      );
      final calm = engineFor(NemesisDifficulty.backedOff)
          .actors
          .firstWhere((a) => a.name == 'Ember');
      final fierce = engineFor(NemesisDifficulty.aggressive)
          .actors
          .firstWhere((a) => a.name == 'Ember');
      expect(fierce.speed, greaterThan(calm.speed));
      expect(fierce.trailRiskLimit, greaterThan(calm.trailRiskLimit));
    });
  });

  group('v1 to v2 store migration', () {
    test('v1 JSON keeps points, levels and skins; history starts empty', () {
      final v1 = GameProgress.defaults()
        ..completeLevel(1, 13.5, totalLevels: 6)
        ..addPoints(500);
      final v1Json = v1.toJson()
        ..remove('dailyArenaHistory')
        ..['version'] = 1;
      final restored = GameProgress.fromJson(v1Json);
      expect(restored.points, 500);
      expect(restored.bestForLevel(1), 13.5);
      expect(restored.highestUnlockedLevel, 2);
      expect(restored.dailyArenaHistory, isEmpty);
      // Re-saving writes v2 and round-trips the arena history.
      final v2Json = restored.toJson();
      expect(v2Json['version'], 2);
      restored.recordDailyArena(
        date: DateTime(2026, 10, 27),
        score: 22,
        rank: 3,
        won: false,
      );
      final again = GameProgress.fromJson(restored.toJson());
      expect(again.dailyArenaHistory.length, 1);
      expect(again.points, 500);
    });

    testWidgets('ProgressStore migrates a v1 SharedPreferences entry to v2',
        (tester) async {
      final v1 = GameProgress.defaults()
        ..completeLevel(1, 13, totalLevels: 6)
        ..completeLevel(2, 20, totalLevels: 6)
        ..addPoints(250);
      final v1Json = v1.toJson()
        ..remove('dailyArenaHistory')
        ..['version'] = 1;
      SharedPreferences.setMockInitialValues({
        ProgressStore.legacyStorageKey: jsonEncode(v1Json),
      });
      final store = await ProgressStore.load();
      expect(store.progress.points, 250);
      expect(store.progress.bestForLevel(2), 20);
      expect(store.progress.highestUnlockedLevel, 3);
      expect(store.progress.dailyArenaHistory, isEmpty);
      final prefs = await SharedPreferences.getInstance();
      expect(prefs.getString(ProgressStore.storageKey), isNotNull);
      expect(prefs.getString(ProgressStore.legacyStorageKey), isNull);
    });
  });

  group('new theme constants', () {
    test('indigo night-sky chrome with ember accents, no teal chrome', () {
      expect(kNightTop, const Color(0xFF141031));
      expect(kNightBottom, const Color(0xFF241B4D));
      expect(kEmber, const Color(0xFFFF6A2A));
      expect(kEmberLight, const Color(0xFFFF9A3D));
      expect(kEmberDeep, const Color(0xFFD94E12));
      expect(kDisplayFontFamily, 'ClaimDisplay');
      // The old teal chrome values must not be the theme anymore.
      expect(kNightTop, isNot(const Color(0xFF062A3A)));
      expect(kNightBottom, isNot(const Color(0xFF0B3D24)));
      expect(kNightTop, isNot(const Color(0xFF101828)));
      expect(kEmber, isNot(const Color(0xFF00BFA6)));
    });
  });
}
