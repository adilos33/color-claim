import 'package:color_claim/game/territory_engine.dart';
import 'package:flutter_test/flutter_test.dart';

/// Tests for the head-on meeting rule (player-involved face-to-face):
/// when the player's head and a bot's head collide, whoever is not
/// standing on their own territory is eliminated. Bots eliminated
/// this way leave the match permanently and their territory turns
/// neutral; the player loses a life through the usual death flow.
void main() {
  TerritoryEngine fresh({int lives = 3}) => TerritoryEngine(
    kLevels[0],
    seed: 7,
    initialLives: lives,
    powerUpsEnabled: false,
  );

  /// Parks an actor so engine steps never move it (speed 0).
  void park(Actor a) => a.speed = 0;

  /// Places [a]'s head on (x, y) carrying a one-cell trail there, so
  /// it counts as standing outside its own territory.
  void stageOutside(TerritoryEngine e, Actor a, int x, int y) {
    a.trail.clear();
    a.trailSet.clear();
    final c = e.idx(x, y);
    a.trail.add(c);
    a.trailSet.add(c);
    a.x = x;
    a.y = y;
    a.prevX = x;
    a.prevY = y;
  }

  group('head-on meeting', () {
    test('bot outside running into the player at home is eliminated '
        'permanently and its territory turns neutral', () {
      final e = fresh();
      final player = e.player;
      final bot = e.actors[1];
      park(player);
      park(e.actors[2]);
      park(e.actors[3]);

      // Player sits at home on its spawn cell; the bot is out on a
      // trail one cell above and runs straight down into the player.
      stageOutside(e, bot, 12, 42);
      bot.dx = 0;
      bot.dy = 1;
      bot.hasTarget = true;
      bot.targetX = 12;
      bot.targetY = 43;
      bot.moveAcc = 1.0;

      e.step();

      expect(e.actors.length, 3);
      expect(e.actors.any((a) => a.id == 1), isFalse);
      expect(e.leaderboard.map((a) => a.id), isNot(contains(1)));
      // Freed territory is neutral and claimable again.
      expect(e.owners[e.idx(43, 12)], -1);
      expect(e.percentFor(1), 0);
      // Knockout credit flows through the usual channels.
      expect(e.playerBotKills, 1);
      expect(e.lastPlayerKillName, bot.name);
      expect(e.score, 100);
      expect(e.lives, 3);
      expect(player.alive, isTrue);
    });

    test('eliminated bots never respawn', () {
      final e = fresh();
      final bot = e.actors[1];
      park(e.player);
      park(e.actors[2]);
      park(e.actors[3]);

      stageOutside(e, bot, 12, 42);
      bot.dx = 0;
      bot.dy = 1;
      bot.hasTarget = true;
      bot.targetX = 12;
      bot.targetY = 43;
      bot.moveAcc = 1.0;

      e.step();
      expect(e.actors.length, 3);
      for (var i = 0; i < 40; i++) {
        e.step();
      }
      expect(e.actors.length, 3);
      expect(e.actors.any((a) => a.id == 1), isFalse);
      expect(e.owners.where((o) => o == 1), isEmpty);
    });

    test('player outside running into a bot at home loses a life; '
        'the bot survives', () {
      final e = fresh();
      final player = e.player;
      final bot = e.actors[1]; // Home at (43, 12), never moves step 1.
      park(e.actors[2]);
      park(e.actors[3]);

      stageOutside(e, player, 43, 13);
      player.dx = 0;
      player.dy = -1;

      e.step();

      expect(e.lives, 2);
      expect(e.gameOver, isFalse);
      expect(player.alive, isTrue); // Respawned on its own territory.
      expect(e.owners[e.idx(player.x, player.y)], 0);
      expect(bot.alive, isTrue);
      expect(e.actors.length, 4);
      expect(e.playerBotKills, 0);
    });

    test('both outside: the bot is eliminated and the player loses '
        'a life', () {
      final e = fresh();
      final player = e.player;
      final bot = e.actors[1];
      park(e.actors[2]);
      park(e.actors[3]);

      stageOutside(e, player, 28, 28);
      player.dx = 1;
      player.dy = 0;
      stageOutside(e, bot, 29, 28);

      e.step();

      expect(e.actors.length, 3);
      expect(e.actors.any((a) => a.id == 1), isFalse);
      expect(e.owners[e.idx(43, 12)], -1); // Bot home freed.
      expect(e.playerBotKills, 1);
      expect(e.lives, 2);
      expect(player.alive, isTrue);
    });

    test('a ready shield consumes the head-on hit instead of a life',
        () {
      final e = fresh();
      final player = e.player;
      final bot = e.actors[1]; // Home at (43, 12).
      park(e.actors[2]);
      park(e.actors[3]);

      stageOutside(e, player, 43, 13);
      player.dx = 0;
      player.dy = -1;
      player.hasShield = true;
      player.shieldSteps = 100;

      e.step();

      expect(e.lives, 3);
      expect(player.hasShield, isFalse); // Shield spent.
      expect(e.shieldBreakEvents, 1);
      expect(player.alive, isTrue);
      expect(player.x, 43);
      expect(player.y, 12); // Still standing on the meeting cell.
      expect(bot.alive, isTrue);
      expect(e.actors.length, 4);
    });

    test('trespassing bot on player land is eliminated when the '
        'player steps home onto it', () {
      final e = fresh();
      final player = e.player;
      final bot = e.actors[1];
      park(e.actors[2]);
      park(e.actors[3]);

      // Player walks home inside its own territory; the bot is out
      // standing on a player-owned cell in the player's path.
      player.x = 12;
      player.y = 45;
      player.prevX = 12;
      player.prevY = 45;
      player.dx = 0;
      player.dy = -1;
      stageOutside(e, bot, 12, 44);

      e.step();

      expect(e.actors.length, 3);
      expect(e.playerBotKills, 1);
      expect(e.lives, 3);
      expect(player.x, 12);
      expect(player.y, 44);
      expect(e.owners.where((o) => o == 1), isEmpty);
    });

    test('both home: heads sharing a cell pass without elimination',
        () {
      final e = fresh();
      final player = e.player;
      final bot = e.actors[1];
      park(player);
      park(bot);
      park(e.actors[2]);
      park(e.actors[3]);

      // Co-located heads with nobody exposed (e.g. a respawn stack):
      // the step runs, movement is unbroken, nobody is eliminated.
      bot.x = player.x;
      bot.y = player.y;
      bot.prevX = bot.x;
      bot.prevY = bot.y;

      e.step();

      expect(e.lives, 3);
      expect(e.actors.length, 4);
      expect(bot.alive, isTrue);
      expect(e.playerBotKills, 0);
      expect(e.score, 0);
    });

    test('bot-vs-bot meetings are not head-on eliminations', () {
      final e = fresh();
      final botA = e.actors[1];
      final botB = e.actors[2];
      park(e.player);
      park(e.actors[3]);

      // Bot B sits at home on a cell it owns; bot A, out on a trail,
      // steps onto B's head cell. No player involved: they pass and
      // the usual rules apply (no permanent elimination).
      e.owners[e.idx(29, 28)] = botB.id;
      botB.x = 29;
      botB.y = 28;
      botB.prevX = 29;
      botB.prevY = 28;
      stageOutside(e, botA, 29, 27);
      botA.dx = 0;
      botA.dy = 1;
      botA.hasTarget = true;
      botA.targetX = 29;
      botA.targetY = 28;
      botA.moveAcc = 1.0;

      e.step();

      expect(e.actors.length, 4);
      expect(botA.alive, isTrue);
      expect(botB.alive, isTrue);
      expect(e.lives, 3);
      expect(e.playerBotKills, 0);
    });

    test('survival mode: a head-on death ends the run', () {
      final e = fresh(lives: 1);
      final player = e.player;
      park(e.actors[2]);
      park(e.actors[3]);

      stageOutside(e, player, 43, 13);
      player.dx = 0;
      player.dy = -1;

      e.step();

      expect(e.lives, 0);
      expect(e.gameOver, isTrue);
      expect(player.alive, isFalse);
      expect(e.actors.length, 4); // The home bot is untouched.
    });
  });
}
