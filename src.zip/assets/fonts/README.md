# Bundled display font

- **File:** `ArchivoBlack-Regular.ttf`
- **Typeface:** Archivo Black, by the Archivo Black Project Authors
  (Omnibus-Type).
- **License:** SIL Open Font License 1.1 (OFL) — free to bundle,
  including in a commercial app, with no royalty. The full OFL text
  ships inside the font file's own metadata and is published with the
  typeface at https://github.com/google/fonts/tree/main/ofl/archivoblack
  (source of this file: `ofl/archivoblack/ArchivoBlack-Regular.ttf`
  in the google/fonts repository).
- **Use in Color Claim:** registered in `pubspec.yaml` as the
  `ClaimDisplay` family and used for headings and HUD numbers
  (`lib/theme.dart`). Body text keeps the system font.
- **Offline:** the font is bundled with the app; nothing is
  downloaded at runtime, and no user data is involved.
