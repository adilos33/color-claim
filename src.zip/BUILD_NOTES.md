# Color Claim — Build Notes

Prototype built 2026-10-05. Original territory-capture game inspired only by
the generic principle (leave your zone, draw a trail, return to claim the
enclosed area). No Paper.io / Voodoo name, icon, character, art, text or
sounds are used anywhere; the name, teal paint-drop character, colors, UI and
level themes are all original.

## Project

- Path: `~/workspace/color-claim-game`
- App name: `color_claim`, org `com.soumbati`
- Dependencies now include `shared_preferences: ^2.5.3` and
  `audioplayers: ^6.5.1`, matching Tiny Scholars' pubspec families.
  `flutter pub get` resolved them to shared_preferences 2.5.5 and
  audioplayers 6.8.1 from the local/pub cache.
- Progress is persisted locally: highest unlocked level, best % per
  level, and the mute setting.

## How to run the web build locally

```bash
cd ~/workspace/color-claim-game/build/web
python3 -m http.server 8080
# open http://localhost:8080
```

Or run on a device/emulator:

```bash
cd ~/workspace/color-claim-game
~/workspace/tools/flutter/bin/flutter run
```

## What is implemented

- Pure-Dart engine (`lib/game/territory_engine.dart`): 56x56 grid, per-cell
  owners, player + bots, trails, capture by border flood-fill (trail +
  enclosed cells are claimed), percent calculation, leaderboard.
- Collision rules implemented:
  - Any actor stepping on the player's trail while the player is outside
    kills the player (3 lives, respawn inside own territory; 0 lives = game
    over).
  - The player crossing a bot's trail kills that bot (+100 score) and the
    bot respawns after a short delay.
  - Crossing your own trail is also fatal (classic rule).
- Bots: simple state-machine AI (head out → wander → return home), fake
  names (Nova, Pixel, Ziggy, Milo, Ruby, Orbit), live % ranking.
- Controls: press and drag — the blob steers toward your finger
  (direction measured from the blob's on-screen position to the touch
  point, deadzone around the blob, one clearly dominant axis required).
  This replaced both the original per-event-delta steering and an
  anchored-flick version after the user reported on iPhone/Safari that
  swiping did nothing and the blob "turned by itself" (2026-10-05).
  180° reversal blocked while on a trail. Pause, restart, mute toggle
  (generated WAV sounds + haptics), home.
- Screens: Home (Play / Levels / How to Play), Level select, Game (goal
  progress bar with goal marker, lives, score, mini leaderboard), Win/Lose
  overlays with Next/Retry.
- 6 levels with distinct themes and rising difficulty:
  1. Meadow 10% · 3 bots · speed 0.72
  2. Candy 15% · 3 bots · speed 0.78
  3. Desert 20% · 4 bots · speed 0.84
  4. Ocean 25% · 4 bots · speed 0.90
  5. Sunset 30% · 5 bots · speed 0.96
  6. Galaxy 35% · 5 bots · speed 1.02
- Responsive layout: portrait stacks board over the ranking panel; wide /
  landscape puts the ranking beside the board. Works on phone and tablet.
- Rendering via CustomPainter: one neutral fill, then only owned cells,
  brightened trails, interpolated actor heads (player = teal paint-drop blob
  with a simple face; bots alternate circle / rounded-square heads).

## Verification (observed 2026-10-05)

- `flutter analyze` — **No issues found!**
- `flutter test` — **5/5 tests passed** (initial %, flood-fill capture,
  walk-a-loop capture, leaderboard ordering, 600-step stability on level 6).
- `flutter build web --release` — **succeeded**; output left in
  `build/web/` (~40 MB including CanvasKit). At that prototype stage it
  was not deployed anywhere; deployment history is in the update below.

## Known limitations / TODO

- Bot AI is deliberately simple (waypoint steering); difficulty tuning and
  head-on collisions can be refined after user play-testing.
- Sounds and saved progress were added in the full-version upgrade below.
- Not submitted to any app store.

## Full-version upgrade — sounds + saved progress (2026-10-05)

Scope approved by the user after the follow-the-finger steering was
approved. The steering implementation was deliberately left unchanged:
`_steerTo` in `lib/screens/game_screen.dart` still measures from the
player blob's on-screen position to the touch point through `_boardKey`.

### Sounds

- Added Tiny Scholars' package families to `pubspec.yaml`:
  `audioplayers: ^6.5.1` and `shared_preferences: ^2.5.3`.
  `flutter pub get` resolved audioplayers 6.8.1 and
  shared_preferences 2.5.5.
- `tools/make_sounds.py` (Python standard library only) reproducibly
  generates these original 44.1 kHz, 16-bit mono WAV files:
  - `assets/sounds/pop.wav` (14,156 bytes) — short rising pop for UI
    taps and bot knock-outs.
  - `assets/sounds/capture.wav` (26,504 bytes) — two rising notes
    (E5 → A5) when the player closes a loop and claims area.
  - `assets/sounds/die.wav` (30,032 bytes) — descending life-lost tone.
  - `assets/sounds/win.wav` (47,672 bytes) — four-note cheerful
    arpeggio for level complete.
  - `assets/sounds/lose.wav` (45,908 bytes) — soft low game-over tone.
- `lib/services/sound_service.dart` plays them through per-sound
  `AudioPool`s. Button taps and bot kills use pop; captures use capture;
  non-final life loss uses die; win and game-over overlays use win and
  lose. The speaker toggle stops active sounds, gates every later sound,
  and saves the mute choice immediately.

### Saved progress

- Pure Dart model: `lib/game/progress.dart` (`GameProgress`) with
  `toJson`/`fromJson`, no Flutter/plugin imports. It stores the highest
  unlocked level, best % per level, and mute. Completing the current
  highest level unlocks only the next one; replaying an earlier level
  never moves the boundary backwards; best % changes only when higher.
- Thin storage wrapper: `lib/services/progress_store.dart`, using
  SharedPreferences key `color_claim_progress_v1`.
- First-run defaults: level 1 unlocked, best 0 for every level, sound on.
- Level select shows each saved best %, greys locked levels, shows a
  lock icon, and disables their taps. Winning saves best % and unlocks
  the next level; returning from a game refreshes the cards.
- A lost game also records the attempt's % as best when it is higher,
  but does not unlock anything.
- App version bumped to `1.1.0+2` in `pubspec.yaml`.
- Engine additions are event counters only (`playerCaptureCount`,
  `playerBotKills`); movement, capture, bot AI, and steering behavior
  were not otherwise changed.

### Verification (observed 2026-10-05)

- `flutter pub get` — succeeded; resolved audioplayers 6.8.1 and
  shared_preferences 2.5.5 under the constraints above.
- `flutter analyze` — **No issues found!** (5.8s).
- `flutter test` — **9/9 passed**: the original 5 TerritoryEngine tests
  plus 4 GameProgress tests (defaults, sequential unlock/replay safety,
  best-% only when higher, JSON round-trip including mute).
- `flutter build web --release` — **succeeded** (81.1s compile);
  `build/web/version.json` reports version 1.1.0, build 2.
- Surge deployment — **Success!** for both `color-claim.surge.sh` and
  `colorclaim.surge.sh` (44 files, 39.7 MB each).
- Live bundle check: `https://color-claim.surge.sh/main.dart.js`
  returned HTTP 200 with 2,156,863 bytes, and
  `https://colorclaim.surge.sh/main.dart.js` returned HTTP 200 with
  2,156,863 bytes — identical to the local `build/web/main.dart.js`.
- No app-store submission was made.
