# Color Claim — Build Notes

Prototype built 2026-10-05. Original territory-capture game inspired only by
the generic principle (leave your zone, draw a trail, return to claim the
enclosed area). No Paper.io / Voodoo name, icon, character, art, text or
sounds are used anywhere; the name, teal paint-drop character, colors, UI and
level themes are all original.

## Project

- Path: `~/workspace/color-claim-game`
- App name: `color_claim`, org `com.soumbati`
- Dependencies now include `shared_preferences: ^2.5.3` and
  `audioplayers: ^6.5.1`, matching Tiny Scholars' pubspec families.
  `flutter pub get` resolved them to shared_preferences 2.5.5 and
  audioplayers 6.8.1 from the local/pub cache.
- Progress is persisted locally: highest unlocked level, best % per
  level, and the mute setting.

## How to run the web build locally

```bash
cd ~/workspace/color-claim-game/build/web
python3 -m http.server 8080
# open http://localhost:8080
```

Or run on a device/emulator:

```bash
cd ~/workspace/color-claim-game
~/workspace/tools/flutter/bin/flutter run
```

## What is implemented

- Pure-Dart engine (`lib/game/territory_engine.dart`): 56x56 grid, per-cell
  owners, player + bots, trails, capture by border flood-fill (trail +
  enclosed cells are claimed), percent calculation, leaderboard.
- Collision rules implemented:
  - Any actor stepping on the player's trail while the player is outside
    kills the player (3 lives, respawn inside own territory; 0 lives = game
    over).
  - The player crossing a bot's trail kills that bot (+100 score) and the
    bot respawns after a short delay.
  - Crossing your own trail is also fatal (classic rule).
- Bots: simple state-machine AI (head out → wander → return home), fake
  names (Nova, Pixel, Ziggy, Milo, Ruby, Orbit), live % ranking.
- Controls: press and drag — the blob steers toward your finger
  (direction measured from the blob's on-screen position to the touch
  point, deadzone around the blob, one clearly dominant axis required).
  This replaced both the original per-event-delta steering and an
  anchored-flick version after the user reported on iPhone/Safari that
  swiping did nothing and the blob "turned by itself" (2026-10-05).
  180° reversal blocked while on a trail. Pause, restart, mute toggle
  (generated WAV sounds + haptics), home.
- Screens: Home (Play / Levels / How to Play), Level select, Game (goal
  progress bar with goal marker, lives, score, mini leaderboard), Win/Lose
  overlays with Next/Retry.
- 6 levels with distinct themes and rising difficulty:
  1. Meadow 10% · 3 bots · speed 0.72
  2. Candy 15% · 3 bots · speed 0.78
  3. Desert 20% · 4 bots · speed 0.84
  4. Ocean 25% · 4 bots · speed 0.90
  5. Sunset 30% · 5 bots · speed 0.96
  6. Galaxy 35% · 5 bots · speed 1.02
- Responsive layout: portrait stacks board over the ranking panel; wide /
  landscape puts the ranking beside the board. Works on phone and tablet.
- Rendering via CustomPainter: one neutral fill, then only owned cells,
  brightened trails, interpolated actor heads (player = teal paint-drop blob
  with a simple face; bots alternate circle / rounded-square heads).

## Verification (observed 2026-10-05)

- `flutter analyze` — **No issues found!**
- `flutter test` — **5/5 tests passed** (initial %, flood-fill capture,
  walk-a-loop capture, leaderboard ordering, 600-step stability on level 6).
- `flutter build web --release` — **succeeded**; output left in
  `build/web/` (~40 MB including CanvasKit). At that prototype stage it
  was not deployed anywhere; deployment history is in the update below.

## Known limitations / TODO

- Bot AI is deliberately simple (waypoint steering); difficulty tuning and
  head-on collisions can be refined after user play-testing.
- Sounds and saved progress were added in the full-version upgrade below.
- Not submitted to any app store.

## Full-version upgrade — sounds + saved progress (2026-10-05)

Scope approved by the user after the follow-the-finger steering was
approved. The steering implementation was deliberately left unchanged:
`_steerTo` in `lib/screens/game_screen.dart` still measures from the
player blob's on-screen position to the touch point through `_boardKey`.

### Sounds

- Added Tiny Scholars' package families to `pubspec.yaml`:
  `audioplayers: ^6.5.1` and `shared_preferences: ^2.5.3`.
  `flutter pub get` resolved audioplayers 6.8.1 and
  shared_preferences 2.5.5.
- `tools/make_sounds.py` (Python standard library only) reproducibly
  generates these original 44.1 kHz, 16-bit mono WAV files:
  - `assets/sounds/pop.wav` (14,156 bytes) — short rising pop for UI
    taps and bot knock-outs.
  - `assets/sounds/capture.wav` (26,504 bytes) — two rising notes
    (E5 → A5) when the player closes a loop and claims area.
  - `assets/sounds/die.wav` (30,032 bytes) — descending life-lost tone.
  - `assets/sounds/win.wav` (47,672 bytes) — four-note cheerful
    arpeggio for level complete.
  - `assets/sounds/lose.wav` (45,908 bytes) — soft low game-over tone.
- `lib/services/sound_service.dart` plays them through per-sound
  `AudioPool`s. Button taps and bot kills use pop; captures use capture;
  non-final life loss uses die; win and game-over overlays use win and
  lose. The speaker toggle stops active sounds, gates every later sound,
  and saves the mute choice immediately.

### Saved progress

- Pure Dart model: `lib/game/progress.dart` (`GameProgress`) with
  `toJson`/`fromJson`, no Flutter/plugin imports. It stores the highest
  unlocked level, best % per level, and mute. Completing the current
  highest level unlocks only the next one; replaying an earlier level
  never moves the boundary backwards; best % changes only when higher.
- Thin storage wrapper: `lib/services/progress_store.dart`, using
  SharedPreferences key `color_claim_progress_v1`.
- First-run defaults: level 1 unlocked, best 0 for every level, sound on.
- Level select shows each saved best %, greys locked levels, shows a
  lock icon, and disables their taps. Winning saves best % and unlocks
  the next level; returning from a game refreshes the cards.
- A lost game also records the attempt's % as best when it is higher,
  but does not unlock anything.
- App version bumped to `1.1.0+2` in `pubspec.yaml`.
- Engine additions are event counters only (`playerCaptureCount`,
  `playerBotKills`); movement, capture, bot AI, and steering behavior
  were not otherwise changed.

### Verification (observed 2026-10-05)

- `flutter pub get` — succeeded; resolved audioplayers 6.8.1 and
  shared_preferences 2.5.5 under the constraints above.
- `flutter analyze` — **No issues found!** (5.8s).
- `flutter test` — **9/9 passed**: the original 5 TerritoryEngine tests
  plus 4 GameProgress tests (defaults, sequential unlock/replay safety,
  best-% only when higher, JSON round-trip including mute).
- `flutter build web --release` — **succeeded** (81.1s compile);
  `build/web/version.json` reports version 1.1.0, build 2.
- Surge deployment — **Success!** for both `color-claim.surge.sh` and
  `colorclaim.surge.sh` (44 files, 39.7 MB each).
- Live bundle check: `https://color-claim.surge.sh/main.dart.js`
  returned HTTP 200 with 2,156,863 bytes, and
  `https://colorclaim.surge.sh/main.dart.js` returned HTTP 200 with
  2,156,863 bytes — identical to the local `build/web/main.dart.js`.
- No app-store submission was made.

## iOS / TestFlight preparation (2026-10-05)

Local preparation only — no Codemagic build was triggered, nothing was
uploaded to GitHub, and nothing was submitted to Apple. Prepared per the
"Codemagic iOS build pipeline — checklist" in ~/AGENTS.md, using
~/workspace/tiny-scholars-ios-app/codemagic.yaml as the template, for
bundle id `com.soumbati.colorclaim`.

- **ios/Podfile** — already present; verified byte-identical to the SDK
  template `~/workspace/tools/flutter/packages/flutter_tools/templates/cocoapods/Podfile-ios`
  (`diff` clean), so nothing to copy.
- **Bundle identifier** — `ios/Runner.xcodeproj/project.pbxproj` used the
  flutter-create default `com.soumbati.colorClaim`; replaced everywhere:
  Runner target is now `com.soumbati.colorclaim` in Debug/Profile/Release
  and RunnerTests is `com.soumbati.colorclaim.RunnerTests`. Verified no
  `colorClaim` string remains under `ios/` or in `codemagic.yaml`.
- **ios/Runner/Info.plist** — verified with python plistlib (read back and
  asserted programmatically): `ITSAppUsesNonExemptEncryption = false`
  present at the ROOT level (not inside the UIScene dict) and
  `CFBundleDisplayName = Color Claim`. Both were already correct, so the
  plist needed no edit.
- **codemagic.yaml** (project root) — adapted from Tiny Scholars:
  workflow `ios-testflight`, variable group `appstore`,
  `BUNDLE_ID: "com.soumbati.colorclaim"` (was the wrong-case
  `com.soumbati.colorClaim`), signing fetch passes
  `--certificate-key "@env:CERTIFICATE_PRIVATE_KEY"`, certs imported with
  `keychain initialize` + `keychain add-certificates` (never
  `app-store-connect certificates --save`), packages via
  `flutter pub get` (never the legacy syntax), and the publishing block
  keeps `submit_to_testflight: false`. One deliberate deviation from the
  Tiny Scholars file: `--build-name=1.1.0` (that file pins 1.0.0) so the
  IPA version matches pubspec `1.1.0+2`; `--build-number=$BUILD_NUMBER`
  kept as in the template.
- **Version** — pubspec stays `1.1.0+2`; this becomes the TestFlight
  build version.

### Verification (observed 2026-10-05)

- `flutter analyze` — **No issues found!** (6.0s).
- `flutter test` — **9/9 passed** (5 TerritoryEngine + 4 GameProgress
  tests), unchanged after the iOS changes.
- **src.zip** — created at `~/workspace/color-claim-game/src.zip`
  (1,744,928 bytes; 981 files, 6,043,831 bytes uncompressed) with
  .gitignore-style exclusions (no `build/`, `.dart_tool/`, `ios/Pods/`,
  self, or IDE junk — 0 entries under `build/` or `.dart_tool/`).
  Listing verified: `codemagic.yaml`, `pubspec.yaml`, `ios/Podfile`,
  `ios/Runner/Info.plist`, `ios/Runner.xcodeproj/project.pbxproj`,
  `lib/main.dart`, and `assets/sounds/*.wav` all present, with
  `codemagic.yaml` at the zip ROOT, ready for the established
  GitHub-web-upload → Codemagic flow.

## Pre-flight before Build #2 (2026-10-05)

User ordered every known Tiny Scholars lesson fixed BEFORE rebuilding, after
Build #1 (Codemagic 6ac42b447394575b200b7251) failed at
"Fetch and create signing files": CERTIFICATE_PRIVATE_KEY undefined.
Local audit against the 8-item checklist in ~/AGENTS.md:

1. Certificate private key var — codemagic.yaml references variable group
   `appstore` and passes `--certificate-key "@env:CERTIFICATE_PRIVATE_KEY"`
   in the fetch-signing-files step. The GROUP ITSELF lives in Codemagic =
   item 8 below, external.
2. ios/Podfile — `diff ios/Podfile` vs the Flutter SDK template
   (tools/flutter/.../templates/cocoapods/Podfile-ios): IDENTICAL. PASS.
3. `flutter pub get` — yaml "Get Flutter packages" runs `flutter pub get`;
   no legacy `flutter packages pub get` anywhere. PASS.
4. Cert import — yaml runs `keychain initialize` then
   `keychain add-certificates`; no `app-store-connect certificates --save`
   anywhere in the yaml. PASS.
5. ITSAppUsesNonExemptEncryption — python plistlib readback of
   ios/Runner/Info.plist: key present at plist ROOT, value bool False.
   PASS (no "Missing Compliance" prompt expected).
6. submit_to_testflight: false — present in the publishing block of
   codemagic.yaml (attach to internal groups manually). PASS.
7. Upload flow — codemagic.yaml sits at the project root and at the ROOT
   of src.zip (verified in the zip listing). PASS.
8. `appstore` variable group inside THIS Codemagic app — EXTERNAL, IN
   PROGRESS in the browser (copy/import from the tiny-scholars app).
   Known gap that failed Build #1; NOT locally verifiable and NOT
   claimed fixed here. Build #2 must not start until the browser side
   confirms the group with CERTIFICATE_PRIVATE_KEY exists on color-claim.

Consistency checks:
- BUNDLE_ID "com.soumbati.colorclaim" in codemagic.yaml; pbxproj
  PRODUCT_BUNDLE_IDENTIFIER = com.soumbati.colorclaim (Runner x3) and
  com.soumbati.colorclaim.RunnerTests (tests x3); zero stale
  `colorClaim` strings.
- Info.plist root CFBundleDisplayName = "Color Claim" (App Store name is
  "Color Claim Puzzle", Apple ID 6819455545, SKU colorclaim).

### Custom app icon (replaced the default Flutter icon)
Original design generated with Python PIL (tools/make_icon.py, PIL
10.2.0): full-bleed teal->green gradient, glossy coral paint-drop blob
character with eyes/smile/cheeks and gloss highlight, pink/blue/yellow
territory blobs + white dots around it. No text, no wifi badge
(ads-first), nothing copied.
- iOS: all 19 files in AppIcon.appiconset regenerated at the exact
  Contents.json filenames/sizes (20..1024 px); the 1024 marketing icon
  verified 1024x1024, mode RGB, no alpha. Script-verified: ALL OK.
- Android: ic_launcher.png regenerated mdpi 48 / hdpi 72 / xhdpi 96 /
  xxhdpi 144 / xxxhdpi 192 from the same master.
- Master saved at icon-master-1024.png (1024x1024 RGB).

### Verification after the fix pass
- `flutter analyze` — No issues found!
- `flutter test` — 9/9 passed (5 TerritoryEngine + 4 GameProgress).
- src.zip rebuilt: 1,016,361 bytes, 176 entries (excludes build/,
  .dart_tool/, ios/Pods/, .flutter-plugins-dependencies and src.zip
  itself; the previous 981-file archive also carried generated
  ephemeral symlink trees that `flutter pub get` regenerates).
  Verified in listing: codemagic.yaml at root, new iOS icon files,
  Android ic_launcher files, ios/Podfile, Info.plist, project.pbxproj,
  sound assets, lib/main.dart all present; 0 build/.dart_tool/Pods
  entries; no self-inclusion.

## Stage A — gameplay modes + arena shapes (2026-10-05)

First stage of the approved development roadmap (A modes/maps → B
powers/skins → C daily/coins/ranks → D smarter bots/haptics/music),
ordered after the user approved v1.2.0's look on his iPhone. The
follow-the-finger steering (`_steerTo`/`_boardKey`) is byte-for-byte the
same logic as approved; only dart-format normalization touched the file.

### Game modes (`lib/game/game_mode.dart`, pure Dart)
- **Classic** — unchanged: reach the level goal % with 3 lives.
- **Quick Match** — 3-minute race (`kQuickMatchSeconds = 180`). Win by
  finishing #1 on %; hitting the goal while leading ends it early as a
  win. HUD shows countdown + live standing; the result overlay states
  the final rank/percent and who won. Getting knocked out ends the run
  with your standing at death (dying while #1 still wins). A Quick Match
  victory unlocks the next level like a Classic win.
- **Survival** — one life, no goal. Engine runs with `initialLives: 1`
  (`maxLives` is now exposed for the hearts HUD). Result overlay shows
  survived time, peak %, score, and knockouts; replay is one tap.
- Mode choice lives on the level-select screen (pills + tagline);
  GameScreen takes a `mode` parameter and Next Level keeps the mode.
  English in-app text only, same as before.

### Arena shapes (`lib/game/arena.dart`, pure Dart)
- `ArenaMask` marks blocked cells per shape; blocked cells use the new
  `TerritoryEngine.blockedOwner` (-2) sentinel, are excluded from the
  percent denominator (`mask.playableCells`), can never be owned,
  spawned on, trailed over, or crossed by the capture flood fill
  (obstacles act as walls, so trail + obstacle can enclose a pocket).
- Fixed spawn points and bot targets resolve through
  `nearestPlayable`, and bot steering never steps into blocked cells —
  bots were soak-tested on the obstacle arenas.
- Assignment: L1 Meadow = Open Field, L2 Candy = Rock Islands,
  L3 Desert = Round Arena, L4 Ocean = Cross Channels,
  L5 Sunset = Rock Islands, L6 Galaxy = Blocked Core. Level cards show
  an "🏟 <shape>" chip; the painter renders blocked cells as dark rock
  on a deep void bed (minimap too). Percent labels now divide by
  playable cells, so goals stay fair on smaller arenas.

### Saved progress additions
- `GameProgress.bestSurvivalSeconds` (per level) with `recordSurvival`;
  JSON round-trips and old saves without the key load unchanged.
  Survival never unlocks levels. Level cards show "⏱ Best m:ss" in
  Survival mode.

### Verification (observed 2026-10-05)

- `flutter analyze` — **No issues found!**
- `flutter test` — **25/25 passed**: the previous 9 plus 16 new Stage A
  tests (mask geometry per shape, spawn resolution, playable-cell
  denominator, capture around the blocked core, 300-step bot soak on
  islands/cross/ring, initial-lives config, survival first-death,
  quick-match standing/early-win evaluation, survival progress
  records + JSON backward compatibility).
- `flutter build web --release` — succeeded locally as a compile smoke
  test (version stays 1.2.0+4). **Not deployed** to Surge and no
  TestFlight build was made; both wait for the later roadmap stages.
