#!/usr/bin/env python3
"""Original Color Claim app icon generator (PIL).

Design: full-bleed teal->green gradient, glossy coral paint-drop blob
character (eyes + smile), small colored territory blobs around it.
No text, no wifi badge, nothing copied from any other app.

Outputs:
- icon-master-1024.png (project root, opaque RGB)
- full iOS set in ios/Runner/Assets.xcassets/AppIcon.appiconset
  (exact filenames/sizes from its Contents.json)
- Android ic_launcher.png in mipmap mdpi..xxxhdpi
"""
import json
import math
from pathlib import Path

from PIL import Image, ImageDraw, ImageFilter

ROOT = Path(__file__).resolve().parent.parent
S = 4096  # supersample render size


def gradient(size, top, bottom):
    img = Image.new("RGB", (size, size))
    px = img.load()
    for y in range(size):
        t = y / (size - 1)
        # diagonal feel: mix in x as well
        row = tuple(int(top[i] + (bottom[i] - top[i]) * t) for i in range(3))
        for x in range(size):
            tt = min(1.0, max(0.0, t + (x / size - 0.5) * 0.18))
            px[x, y] = tuple(int(top[i] + (bottom[i] - top[i]) * tt) for i in range(3))
    return img


def blob_shape(draw, cx, cy, r, fill):
    """Irregular territory blob: main ellipse + two satellite circles."""
    draw.ellipse([cx - r, cy - r * 0.92, cx + r, cy + r * 0.92], fill=fill)
    draw.ellipse([cx + r * 0.45, cy - r * 0.55, cx + r * 1.25, cy + r * 0.25], fill=fill)
    draw.ellipse([cx - r * 1.2, cy + r * 0.1, cx - r * 0.4, cy + r * 0.8], fill=fill)


def render():
    # --- background: fresh teal -> green gradient, full bleed, opaque ---
    bg = gradient(S, (0, 199, 168), (56, 217, 119)).convert("RGBA")

    # soft light glow top-center
    glow = Image.new("RGBA", (S, S), (0, 0, 0, 0))
    gd = ImageDraw.Draw(glow)
    gd.ellipse([-S * 0.25, -S * 0.45, S * 0.75, S * 0.45], fill=(255, 255, 255, 60))
    glow = glow.filter(ImageFilter.GaussianBlur(220))
    bg.alpha_composite(glow)

    d = ImageDraw.Draw(bg, "RGBA")

    # --- territory blobs behind the character ---
    blob_shape(d, 3320, 760, 250, (255, 93, 143, 235))    # candy pink
    blob_shape(d, 700, 3320, 290, (77, 150, 255, 235))    # ocean blue
    blob_shape(d, 3420, 3300, 205, (255, 197, 61, 240))  # sunny yellow
    for (x, y, r, c) in [
        (880, 760, 62, (255, 255, 255, 210)),
        (3560, 1760, 46, (255, 255, 255, 190)),
        (620, 1900, 40, (255, 255, 255, 170)),
        (2050, 620, 36, (255, 255, 255, 160)),
        (1500, 3560, 44, (255, 255, 255, 150)),
    ]:
        d.ellipse([x - r, y - r, x + r, y + r], fill=c)

    # --- paint-drop character ---
    cx, cy, R = 2048, 2180, 1130
    tip_y = 830

    # drop shadow
    shadow = Image.new("RGBA", (S, S), (0, 0, 0, 0))
    sd = ImageDraw.Draw(shadow)
    sd.ellipse([cx - R * 0.78, cy + R * 0.78, cx + R * 0.78, cy + R * 1.12],
               fill=(0, 90, 70, 110))
    bg.alpha_composite(shadow.filter(ImageFilter.GaussianBlur(70)))
    d = ImageDraw.Draw(bg, "RGBA")

    # drop mask: big circle + triangle tip with rounded end
    mask = Image.new("L", (S, S), 0)
    md = ImageDraw.Draw(mask)
    md.ellipse([cx - R, cy - R, cx + R, cy + R], fill=255)
    md.polygon([(cx - R * 0.40, cy - R * 0.34),
                (cx + R * 0.40, cy - R * 0.34),
                (cx, tip_y)], fill=255)
    md.ellipse([cx - 78, tip_y - 30, cx + 78, tip_y + 126], fill=255)
    md.ellipse([cx - R, cy - R, cx + R, cy + R], fill=255)

    # drop body: vertical coral gradient clipped by mask
    body_grad = gradient(S, (255, 158, 87), (255, 77, 94)).convert("RGBA")
    bg.paste(body_grad, (0, 0), mask)

    # subtle darker rim only on the round body edge
    rim = Image.new("RGBA", (S, S), (0, 0, 0, 0))
    rd = ImageDraw.Draw(rim)
    rd.ellipse([cx - R, cy - R, cx + R, cy + R], outline=(214, 59, 66, 90), width=16)
    rim.putalpha(Image.composite(rim.getchannel("A"), Image.new("L", (S, S), 0), mask))
    bg.alpha_composite(rim)
    d = ImageDraw.Draw(bg, "RGBA")

    # gloss highlight (clipped to drop)
    gloss = Image.new("RGBA", (S, S), (0, 0, 0, 0))
    gl = ImageDraw.Draw(gloss)
    gl.ellipse([cx - R * 0.62, cy - R * 0.78, cx - R * 0.05, cy - R * 0.18],
               fill=(255, 255, 255, 130))
    gloss = gloss.filter(ImageFilter.GaussianBlur(46))
    gloss.putalpha(Image.composite(gloss.getchannel("A"), Image.new("L", (S, S), 0), mask))
    bg.alpha_composite(gloss)
    d = ImageDraw.Draw(bg, "RGBA")
    d.ellipse([cx - R * 0.50, cy - R * 0.60, cx - R * 0.34, cy - R * 0.44],
              fill=(255, 255, 255, 200))

    # --- face ---
    ink = (38, 50, 66, 255)
    eye_y = cy + int(R * 0.02)
    for ex in (cx - int(R * 0.37), cx + int(R * 0.37)):
        d.ellipse([ex - 175, eye_y - 205, ex + 175, eye_y + 205], fill=(255, 255, 255, 255))
        d.ellipse([ex - 82, eye_y - 72, ex + 82, eye_y + 92], fill=ink)
        d.ellipse([ex - 46, eye_y - 62, ex + 4, eye_y - 12], fill=(255, 255, 255, 255))
    # smile
    d.arc([cx - 300, cy + 130, cx + 300, cy + 560], start=18, end=162, fill=ink, width=52)
    # cheeks
    for ex in (cx - int(R * 0.52), cx + int(R * 0.52)):
        d.ellipse([ex - 150, cy + 250, ex + 150, cy + 380], fill=(255, 110, 130, 110))

    return bg.convert("RGB")


def main():
    master_big = render()
    master = master_big.resize((1024, 1024), Image.LANCZOS)
    master_path = ROOT / "icon-master-1024.png"
    master.save(master_path, "PNG")
    print(f"master: {master_path} {master.size} {master.mode}")

    # iOS set from Contents.json
    iconset = ROOT / "ios/Runner/Assets.xcassets/AppIcon.appiconset"
    spec = json.loads((iconset / "Contents.json").read_text())
    for entry in spec["images"]:
        w, h = (float(v) for v in entry["size"].split("x"))
        scale = float(entry["scale"].replace("x", ""))
        px = int(round(w * scale))
        out = master_big.resize((px, px), Image.LANCZOS)
        out.save(iconset / entry["filename"], "PNG")
        print(f"ios: {entry['filename']} {px}px {out.mode}")

    # Android launchers
    for name, px in [("mdpi", 48), ("hdpi", 72), ("xhdpi", 96),
                     ("xxhdpi", 144), ("xxxhdpi", 192)]:
        out = master_big.resize((px, px), Image.LANCZOS)
        path = ROOT / f"android/app/src/main/res/mipmap-{name}/ic_launcher.png"
        out.save(path, "PNG")
        print(f"android: {path.relative_to(ROOT)} {px}px {out.mode}")


if __name__ == "__main__":
    main()
