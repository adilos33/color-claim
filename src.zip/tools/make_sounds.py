#!/usr/bin/env python3
"""Generate Color Claim's original synthesized sound effects.

The sounds are intentionally small, bright, and non-repetitive.  They are
created only with Python's standard library so the exact assets in
``assets/sounds`` can be reproduced at any time with:

    python3 tools/make_sounds.py
"""

from __future__ import annotations

import math
import struct
import wave
from pathlib import Path

SAMPLE_RATE = 44_100
OUTPUT_DIR = Path(__file__).resolve().parents[1] / "assets" / "sounds"


def envelope(position: float, duration: float) -> float:
    """Fast attack and smooth release, avoiding clicks at note edges."""
    attack = min(1.0, position / 0.008)
    release = min(1.0, max(0.0, (duration - position) / 0.035))
    return attack * release


def add_tone(
    samples: list[float],
    start_seconds: float,
    duration: float,
    start_frequency: float,
    end_frequency: float,
    amplitude: float,
) -> None:
    start = int(start_seconds * SAMPLE_RATE)
    count = int(duration * SAMPLE_RATE)
    phase = 0.0

    for offset in range(count):
        index = start + offset
        if index >= len(samples):
            samples.extend([0.0] * (index - len(samples) + 1))

        progress = offset / max(1, count - 1)
        # Exponential sweeps sound more natural than linear frequency ramps.
        frequency = start_frequency * ((end_frequency / start_frequency) ** progress)
        phase += 2.0 * math.pi * frequency / SAMPLE_RATE
        env = envelope(offset / SAMPLE_RATE, duration)
        # A quiet second harmonic gives the simple sine a warmer game feel.
        tone = math.sin(phase) + 0.18 * math.sin(2.0 * phase)
        samples[index] += amplitude * env * tone


def render(notes: list[tuple[float, float, float, float, float]], seconds: float) -> list[float]:
    samples = [0.0] * int(seconds * SAMPLE_RATE)
    for start, duration, start_freq, end_freq, amplitude in notes:
        add_tone(samples, start, duration, start_freq, end_freq, amplitude)

    peak = max((abs(value) for value in samples), default=0.0)
    if peak > 0.86:
        scale = 0.86 / peak
        samples = [value * scale for value in samples]
    return samples


def write_wav(path: Path, samples: list[float]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    frames = b"".join(
        struct.pack("<h", int(max(-1.0, min(1.0, value)) * 32767))
        for value in samples
    )
    with wave.open(str(path), "wb") as output:
        output.setnchannels(1)
        output.setsampwidth(2)
        output.setframerate(SAMPLE_RATE)
        output.writeframes(frames)


def main() -> None:
    sounds: dict[str, tuple[list[tuple[float, float, float, float, float]], float]] = {
        # A short upward pop: friendly enough for buttons and bot knock-outs.
        "pop.wav": ([(0.0, 0.14, 620.0, 1180.0, 0.52)], 0.16),
        # The user's preferred two-rising-notes success blip.
        "capture.wav": (
            [
                (0.0, 0.11, 659.25, 659.25, 0.42),
                (0.085, 0.19, 880.0, 880.0, 0.48),
            ],
            0.30,
        ),
        # A clear but not harsh fall when a life is lost.
        "die.wav": ([(0.0, 0.30, 392.0, 147.0, 0.50)], 0.34),
        # Cheerful C-major arpeggio for completing a level.
        "win.wav": (
            [
                (0.0, 0.10, 523.25, 523.25, 0.40),
                (0.085, 0.10, 659.25, 659.25, 0.43),
                (0.170, 0.10, 783.99, 783.99, 0.46),
                (0.255, 0.24, 1046.50, 1046.50, 0.50),
            ],
            0.54,
        ),
        # Soft low fall for game over; deliberately less punchy than die.wav.
        "lose.wav": ([(0.0, 0.48, 220.0, 138.0, 0.36)], 0.52),
    }

    for filename, (notes, seconds) in sounds.items():
        write_wav(OUTPUT_DIR / filename, render(notes, seconds))
        print(f"wrote {OUTPUT_DIR / filename}")


if __name__ == "__main__":
    main()
