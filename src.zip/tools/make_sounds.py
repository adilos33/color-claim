#!/usr/bin/env python3
"""Generate Color Claim's original synthesized sound effects.

The sounds are intentionally small, bright, and non-repetitive.  They are
created only with Python's standard library so the exact assets in
``assets/sounds`` can be reproduced at any time with:

    python3 tools/make_sounds.py
"""

from __future__ import annotations

import math
import struct
import wave
from pathlib import Path

SAMPLE_RATE = 44_100
MUSIC_SAMPLE_RATE = 22_050
OUTPUT_DIR = Path(__file__).resolve().parents[1] / "assets" / "sounds"


def envelope(position: float, duration: float) -> float:
    """Fast attack and smooth release, avoiding clicks at note edges."""
    attack = min(1.0, position / 0.008)
    release = min(1.0, max(0.0, (duration - position) / 0.035))
    return attack * release


def add_tone(
    samples: list[float],
    start_seconds: float,
    duration: float,
    start_frequency: float,
    end_frequency: float,
    amplitude: float,
) -> None:
    start = int(start_seconds * SAMPLE_RATE)
    count = int(duration * SAMPLE_RATE)
    phase = 0.0

    for offset in range(count):
        index = start + offset
        if index >= len(samples):
            samples.extend([0.0] * (index - len(samples) + 1))

        progress = offset / max(1, count - 1)
        # Exponential sweeps sound more natural than linear frequency ramps.
        frequency = start_frequency * ((end_frequency / start_frequency) ** progress)
        phase += 2.0 * math.pi * frequency / SAMPLE_RATE
        env = envelope(offset / SAMPLE_RATE, duration)
        # A quiet second harmonic gives the simple sine a warmer game feel.
        tone = math.sin(phase) + 0.18 * math.sin(2.0 * phase)
        samples[index] += amplitude * env * tone


def render(notes: list[tuple[float, float, float, float, float]], seconds: float) -> list[float]:
    samples = [0.0] * int(seconds * SAMPLE_RATE)
    for start, duration, start_freq, end_freq, amplitude in notes:
        add_tone(samples, start, duration, start_freq, end_freq, amplitude)

    peak = max((abs(value) for value in samples), default=0.0)
    if peak > 0.86:
        scale = 0.86 / peak
        samples = [value * scale for value in samples]
    return samples


def write_wav(path: Path, samples: list[float], sample_rate: int = SAMPLE_RATE) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    frames = b"".join(
        struct.pack("<h", int(max(-1.0, min(1.0, value)) * 32767))
        for value in samples
    )
    with wave.open(str(path), "wb") as output:
        output.setnchannels(1)
        output.setsampwidth(2)
        output.setframerate(sample_rate)
        output.writeframes(frames)


def midi_freq(midi: int) -> float:
    return 440.0 * (2.0 ** ((midi - 69) / 12.0))


def music_note(
    samples: list[float],
    rate: int,
    start: float,
    duration: float,
    midi: int,
    amplitude: float,
    kind: str,
) -> None:
    """One synthesized note: 'pluck' (fast decay), 'pad' (soft swell),
    or 'bass' (round and short) — all plain harmonics, nothing sampled."""
    freq = midi_freq(midi)
    first = int(start * rate)
    count = int(duration * rate)
    for offset in range(count):
        index = first + offset
        if index >= len(samples):
            return
        t = offset / rate
        phase = 2.0 * math.pi * freq * t
        if kind == "pluck":
            tone = math.sin(phase) + 0.35 * math.sin(2.0 * phase) \
                + 0.12 * math.sin(3.0 * phase)
            env = math.exp(-4.5 * t / duration) * min(1.0, t / 0.006)
        elif kind == "pad":
            tone = math.sin(phase) + 0.2 * math.sin(2.0 * phase)
            env = min(1.0, t / 0.4) * min(1.0, max(0.0, (duration - t) / 0.4))
        else:  # bass
            tone = math.sin(phase) + 0.15 * math.sin(2.0 * phase)
            env = min(1.0, t / 0.01) * math.exp(-2.2 * t / duration)
        samples[index] += amplitude * env * tone


def render_music() -> list[float]:
    """An original 16-second cheerful loop (120 BPM, C major).

    Eight bars of I–V–vi–IV-style harmony with a simple pentatonic
    pluck melody over soft pads and a round bass. Written from scratch
    for this game; loops cleanly because the last bar resolves back to
    the opening chord and every envelope ends inside the file.
    """
    rate = MUSIC_SAMPLE_RATE
    beat = 0.5  # 120 BPM
    bar = beat * 4
    bars = 8
    total = bar * bars
    samples = [0.0] * int(total * rate)

    # (bass midi, pad triad) per bar.
    chords = [
        (36, (48, 52, 55)),  # C
        (43, (47, 50, 55)),  # G
        (45, (48, 52, 57)),  # Am
        (41, (48, 53, 57)),  # F
        (36, (48, 52, 55)),  # C
        (43, (47, 50, 55)),  # G
        (41, (48, 53, 57)),  # F
        (43, (47, 50, 55)),  # G
    ]
    for b, (bass, triad) in enumerate(chords):
        start = b * bar
        for note in triad:
            music_note(samples, rate, start, bar, note, 0.055, "pad")
        # Bass on beats 1 and 3; the fifth joins on the second hit.
        music_note(samples, rate, start, beat * 1.6, bass, 0.20, "bass")
        music_note(
            samples, rate, start + beat * 2, beat * 1.6, bass + 7, 0.15, "bass"
        )

    # Pluck melody on an eighth-note grid (8 slots per bar). Each entry
    # is (slot, midi, length in slots); None means keep resting.
    eighth = beat / 2
    melody: list[tuple[int, int, int, int]] = [
        # bar, slot, midi, slots
        (0, 0, 76, 1), (0, 1, 79, 1), (0, 2, 81, 1), (0, 3, 79, 1),
        (0, 4, 76, 1), (0, 5, 74, 1), (0, 6, 76, 2),
        (1, 0, 74, 1), (1, 1, 76, 1), (1, 2, 79, 1), (1, 3, 76, 1),
        (1, 4, 74, 1), (1, 5, 71, 1), (1, 6, 74, 2),
        (2, 0, 81, 1), (2, 1, 84, 1), (2, 2, 81, 1), (2, 3, 76, 1),
        (2, 4, 81, 1), (2, 5, 79, 1), (2, 6, 76, 2),
        (3, 0, 81, 1), (3, 1, 77, 1), (3, 2, 81, 1), (3, 3, 79, 1),
        (3, 4, 76, 1), (3, 5, 74, 1), (3, 6, 76, 2),
        (4, 0, 76, 1), (4, 1, 79, 1), (4, 2, 81, 1), (4, 3, 84, 1),
        (4, 4, 81, 1), (4, 5, 79, 1), (4, 6, 76, 2),
        (5, 0, 79, 1), (5, 1, 81, 1), (5, 2, 79, 1), (5, 3, 76, 1),
        (5, 4, 74, 1), (5, 5, 71, 1), (5, 6, 74, 2),
        (6, 0, 77, 1), (6, 1, 81, 1), (6, 2, 84, 1), (6, 3, 81, 1),
        (6, 4, 77, 1), (6, 5, 81, 1), (6, 6, 79, 2),
        (7, 0, 74, 1), (7, 1, 76, 1), (7, 2, 79, 4),
    ]
    for b, slot, midi, slots in melody:
        start = b * bar + slot * eighth
        music_note(samples, rate, start, eighth * slots, midi, 0.16, "pluck")

    # Gentle master fades so the loop point never clicks.
    fade = int(0.02 * rate)
    for i in range(fade):
        gain = i / fade
        samples[i] *= gain
        samples[-1 - i] *= gain

    peak = max((abs(v) for v in samples), default=0.0)
    if peak > 0.5:
        scale = 0.5 / peak
        samples = [v * scale for v in samples]
    return samples


def main() -> None:
    sounds: dict[str, tuple[list[tuple[float, float, float, float, float]], float]] = {
        # A short upward pop: friendly enough for buttons and bot knock-outs.
        "pop.wav": ([(0.0, 0.14, 620.0, 1180.0, 0.52)], 0.16),
        # The user's preferred two-rising-notes success blip.
        "capture.wav": (
            [
                (0.0, 0.11, 659.25, 659.25, 0.42),
                (0.085, 0.19, 880.0, 880.0, 0.48),
            ],
            0.30,
        ),
        # A clear but not harsh fall when a life is lost.
        "die.wav": ([(0.0, 0.30, 392.0, 147.0, 0.50)], 0.34),
        # Cheerful C-major arpeggio for completing a level.
        "win.wav": (
            [
                (0.0, 0.10, 523.25, 523.25, 0.40),
                (0.085, 0.10, 659.25, 659.25, 0.43),
                (0.170, 0.10, 783.99, 783.99, 0.46),
                (0.255, 0.24, 1046.50, 1046.50, 0.50),
            ],
            0.54,
        ),
        # Soft low fall for game over; deliberately less punchy than die.wav.
        "lose.wav": ([(0.0, 0.48, 220.0, 138.0, 0.36)], 0.52),
    }

    for filename, (notes, seconds) in sounds.items():
        write_wav(OUTPUT_DIR / filename, render(notes, seconds))
        print(f"wrote {OUTPUT_DIR / filename}")

    write_wav(OUTPUT_DIR / "music.wav", render_music(), MUSIC_SAMPLE_RATE)
    print(f"wrote {OUTPUT_DIR / 'music.wav'}")


if __name__ == "__main__":
    main()
