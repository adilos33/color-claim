#!/usr/bin/env python3
"""Create App Store signing assets locally for Color Claim.

Uses the user's own App Store Connect API key (AuthKey_6574A69GDJ.p8) and
the existing iOS distribution private key. Never prints secret material;
only prints identifiers, HTTP statuses, and resulting file paths/sizes.

Outputs (under ~/workspace/user/secrets/ios-signing-assets/):
  - distribution.cer      (DER cert matching our private key)
  - certificate.pem       (same cert in PEM)
  - identity.p12          (cert + private key, empty password)
  - ColorClaim_AppStore.mobileprovision

Usage: python3 make_signing_assets.py <ISSUER_ID>
"""
import base64
import json
import subprocess
import sys
import time
import urllib.request
from pathlib import Path

HOME = Path.home()
SECRETS = HOME / "workspace/user/secrets"
KEY_ID = "6574A69GDJ"
API_KEY_FILE = SECRETS / "asc-api-key/AuthKey_6574A69GDJ.p8"
PRIVATE_KEY_FILE = SECRETS / "ios-cert-key/ios_distribution_private_key"
OUT_DIR = SECRETS / "ios-signing-assets"
BUNDLE_ID = "com.soumbati.colorclaim"
PROFILE_NAME = "Color Claim App Store"
API_BASE = "https://api.appstoreconnect.apple.com"


def b64url(data: bytes) -> str:
    return base64.urlsafe_b64encode(data).rstrip(b"=").decode()


def make_jwt(issuer_id: str) -> str:
    header = {"alg": "ES256", "kid": KEY_ID, "typ": "JWT"}
    now = int(time.time())
    payload = {"iss": issuer_id, "iat": now, "exp": now + 1200,
               "aud": "appstoreconnect-v1"}
    signing_input = (b64url(json.dumps(header).encode()) + "." +
                     b64url(json.dumps(payload).encode()))
    proc = subprocess.run(
        ["openssl", "dgst", "-sha256", "-sign", str(API_KEY_FILE)],
        input=signing_input.encode(), capture_output=True, check=True)
    der = proc.stdout
    # Convert DER ECDSA signature to raw R||S (64 bytes for P-256).
    assert der[0] == 0x30
    idx = 2
    if der[1] & 0x80:
        idx = 2 + (der[1] & 0x7F)
    assert der[idx] == 0x02
    r_len = der[idx + 1]
    r = der[idx + 2: idx + 2 + r_len]
    idx = idx + 2 + r_len
    assert der[idx] == 0x02
    s_len = der[idx + 1]
    s = der[idx + 2: idx + 2 + s_len]
    raw = r.rjust(32, b"\x00")[-32:] + s.rjust(32, b"\x00")[-32:]
    return signing_input + "." + b64url(raw)


def api(token: str, method: str, path: str, body: dict | None = None):
    # Use curl: it honors the sandbox egress proxy; urllib direct hangs.
    url = API_BASE + path
    args = ["curl", "-sS", "-g", "--max-time", "60", "-X", method,
            "-H", f"Authorization: Bearer {token}",
            "-w", "\n%{http_code}", url]
    if body is not None:
        args += ["-H", "Content-Type: application/json",
                 "-d", json.dumps(body)]
    proc = subprocess.run(args, capture_output=True, timeout=90)
    out = proc.stdout.decode()
    if proc.returncode != 0:
        print(f"curl failed rc={proc.returncode} for {method} {path}")
        print(proc.stderr.decode()[:500])
        raise SystemExit(1)
    text, _, code = out.rpartition("\n")
    status = int(code)
    if status >= 400:
        print(f"HTTP {status} for {method} {path}")
        print(text[:1500])
        raise SystemExit(1)
    return status, json.loads(text or "{}")


def pubkey_of_private_key() -> str:
    proc = subprocess.run(
        ["openssl", "pkey", "-in", str(PRIVATE_KEY_FILE), "-pubout"],
        capture_output=True, check=True)
    return proc.stdout.decode()


def pubkey_of_cert_der(der_path: Path) -> str:
    proc = subprocess.run(
        ["openssl", "x509", "-inform", "DER", "-in", str(der_path),
         "-pubkey", "-noout"],
        capture_output=True, check=True)
    return proc.stdout.decode()


def main() -> None:
    if len(sys.argv) != 2:
        print("usage: make_signing_assets.py <ISSUER_ID>")
        raise SystemExit(2)
    issuer_id = sys.argv[1].strip()
    OUT_DIR.mkdir(parents=True, exist_ok=True)

    token = make_jwt(issuer_id)

    # 1. Find the distribution certificate matching our private key.
    status, resp = api(
        token, "GET",
        "/v1/certificates?filter[certificateType]=DISTRIBUTION&limit=50")
    print("certificates list HTTP", status, "count", len(resp.get("data", [])))
    our_pub = pubkey_of_private_key()
    matched = None
    tmp_cer = OUT_DIR / "candidate.cer"
    for cert in resp.get("data", []):
        content = cert["attributes"].get("certificateContent")
        if not content:
            continue
        tmp_cer.write_bytes(base64.b64decode(content))
        if pubkey_of_cert_der(tmp_cer) == our_pub:
            matched = cert
            tmp_cer.rename(OUT_DIR / "distribution.cer")
            break
    if not matched:
        print("No distribution certificate matches our private key")
        raise SystemExit(1)
    print("matched certificate id:", matched["id"],
          "name:", matched["attributes"].get("name"),
          "expires:", matched["attributes"].get("expirationDate"))

    # 2. Resolve bundle ID resource id.
    status, resp = api(
        token, "GET",
        f"/v1/bundleIds?filter[identifier]={BUNDLE_ID}&limit=10")
    print("bundleIds HTTP", status, "count", len(resp.get("data", [])))
    if not resp.get("data"):
        print("Bundle ID resource not found")
        raise SystemExit(1)
    bundle_resource_id = resp["data"][0]["id"]

    # 3. Create (or reuse) the App Store provisioning profile.
    status, resp = api(
        token, "GET",
        f"/v1/profiles?filter[name]={PROFILE_NAME.replace(' ', '%20')}&limit=10")
    print("profiles lookup HTTP", status, "count", len(resp.get("data", [])))
    profile = (resp.get("data") or [None])[0]
    if profile is None:
        body = {
            "data": {
                "type": "profiles",
                "attributes": {"name": PROFILE_NAME,
                               "profileType": "IOS_APP_STORE"},
                "relationships": {
                    "bundleId": {"data": {"type": "bundleIds",
                                          "id": bundle_resource_id}},
                    "certificates": {"data": [{"type": "certificates",
                                               "id": matched["id"]}]},
                },
            }
        }
        status, resp = api(token, "POST", "/v1/profiles", body)
        print("profile create HTTP", status)
        profile = resp["data"]
    content = profile["attributes"].get("profileContent")
    if not content:
        status, resp = api(token, "GET", f"/v1/profiles/{profile['id']}")
        content = resp["data"]["attributes"]["profileContent"]
    profile_path = OUT_DIR / "ColorClaim_AppStore.mobileprovision"
    profile_path.write_bytes(base64.b64decode(content))
    print("profile:", profile["id"], profile["attributes"].get("name"),
          "state:", profile["attributes"].get("profileState"),
          "bytes:", profile_path.stat().st_size)

    # 4. Build identity.p12 (cert + key, empty password).
    cert_pem = OUT_DIR / "certificate.pem"
    subprocess.run(
        ["openssl", "x509", "-inform", "DER", "-in",
         str(OUT_DIR / "distribution.cer"), "-out", str(cert_pem)],
        check=True, capture_output=True)
    p12 = OUT_DIR / "identity.p12"
    subprocess.run(
        ["openssl", "pkcs12", "-export", "-inkey", str(PRIVATE_KEY_FILE),
         "-in", str(cert_pem), "-out", str(p12), "-passout", "pass:",
         "-name", "AADEL Distribution"],
        check=True, capture_output=True)
    print("identity.p12 bytes:", p12.stat().st_size)
    print("DONE")


if __name__ == "__main__":
    main()
