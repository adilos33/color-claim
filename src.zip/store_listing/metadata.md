# Color Claim Puzzle — App Store Listing Pack (v1.3.0)

Prepared 2026-10-06. Nothing has been submitted — upload happens in App Store Connect separately.

## Screenshots (in this folder)

All captured from the real game (local web build of the exact 1.3.0 code shipped to TestFlight), validated with PIL.

| File | Size | Content |
| --- | --- | --- |
| `iphone_1.png` | 1290×2796 | Home / menu with the glossy owl mascot, rank + daily challenge cards |
| `iphone_2.png` | 1290×2796 | Gameplay: owl mid-trail, rival bots + territories, live ranking |
| `iphone_3.png` | 1290×2796 | Level select: Classic / Quick Match / Survival modes, 6 worlds |
| `iphone_4.png` | 1290×2796 | Skins shop — unlockable glossy owl skins |
| `iphone_5.png` | 1290×2796 | Gameplay action: long trail, knockout scored (+100 pts) |
| `ipad_1.png` | 2048×2732 | Home / menu with the glossy owl mascot |
| `ipad_2.png` | 2048×2732 | Gameplay: "You cut Pixel!" knockout banner, owl mid-trail, bots |
| `ipad_3.png` | 2048×2732 | Level select: 3 modes, 6 worlds |
| `ipad_4.png` | 2048×2732 | Skins shop — all 8 owl skins |
| `ipad_5.png` | 2048×2732 | Results screen ("Game Over", ⭐ points earned) |

Suggested upload order: 1 → 5 as listed (home, gameplay, levels, skins, action/results).

## App name (30 chars max)

Color Claim Puzzle

## Subtitle (30 chars max)

Claim the Arena, Owl Style!

## Promotional text (170 chars max)

Glossy 3D owls, head-on duels and smarter rival bots! Draw a loop, claim your color, chase the Diamond rank — fully offline. No ads, no internet needed.

## Description

Draw a loop. Claim the color. Beat the bots!

Color Claim Puzzle is a fast, joyful territory-capture game you play against clever AI bots — no internet, no waiting, no ads. Steer your glossy owl out of its zone, draw a glowing trail through open ground, then dive back home to claim everything inside your loop. Every run is a risk: the longer your trail, the bigger the prize… and the easier you are to cut!

OUTSMART LIVELY RIVALS
Face Nova, Pixel, Ziggy and friends — each bot plays its own game, fleeing danger, grabbing power-ups and hunting loose trails. Cut a rival's trail (or win a head-on duel outside your zone) to knock them out for good and free their land.

SIX WORLDS, THREE WAYS TO PLAY
• Classic — reach the goal % to clear each world, from Meadow (10%) to Galaxy (35%)
• Quick Match — 180 seconds, highest coverage wins
• Survival — one life, one shot, pure nerve
Arena shapes change every run: open fields, rock islands, cross channels and blocked cores.

POWER-UPS THAT TURN THE TIDE
Snatch ⚡ Speed bursts, 🛡️ Shields that save you from a fatal cut, and ❄️ Freeze that stops every rival cold.

MAKE THE OWL YOURS
Finish matches to earn ⭐ points and unlock 8 glossy owl skins — Ocean, Sunny, Leaf, Moon, Flame, Star and the ultra-rare Crystal Owl. Your skin recolors your whole zone, so the arena wears your style.

DAILY GOALS & RANKS
A fresh Daily Challenge every day, streaks to protect, and ranks from Bronze all the way to Diamond. Chase the crown on the live in-match leaderboard!

WHY YOU'LL LOVE IT
• 100% offline vs AI bots — play anywhere, anytime
• No ads, no internet needed, no accounts
• Follow-your-finger steering that feels instant and precise
• Bright, juicy arcade visuals with a glossy 3D owl hero
• Original music and sound effects, with a one-tap mute
• Light, fast and battery-friendly; great on iPhone and iPad

Easy to learn in ten seconds, deliciously hard to put down. How much of the arena can YOU claim?

## Keywords (100 chars max)

territory,owl,puzzle,offline,arena,claim,color,draw,loop,bots,arcade,strategy,casual,io,paint

## Categories

- Primary: Games — recommended subcategory: Puzzle (the loop-drawing/claiming core loop)
- Secondary: Action (per current plan). Alternative worth considering at upload time: swap to Primary Games > Action with Puzzle secondary if Apple search data for "territory/io" style games is weighted — Puzzle-first is the safer match for how this game actually plays.

## Age rating

Expected: 4+ (answer the ASC questionnaire as: no realistic violence, no gambling, no unrestricted web, no mature themes; only mild cartoon competition — bots are "knocked out" with no injury depiction).

## Privacy

Data Not Collected. The app has no analytics, no ad SDKs, no accounts and no network calls; progress is stored only on-device. (Matches the submitted binary — keep the ASC answer exactly this.)

## Pricing & availability

- Price: Free (v1 has no ads and no IAP — "No ads, no internet needed" is truthful for this version).
- Availability: all countries/regions EXCEPT the EU-27. Reason: this mirrors the sister app (Tiny Scholars) — the EU Digital Services Act trader declaration is deferred for now; add EU back later once the trader status is declared.

## Support URL

Suggested: https://color-claim.surge.sh

⚠️ Flag: this URL is the live playable web preview of the game (handy for reviewers and curious users), not a dedicated support page — it has no contact form or FAQ. Acceptable for launch, but consider replacing later with a small support page that includes a contact email.

- Privacy Policy URL: not required while "Data Not Collected" holds with no tracking; if ever asked, the same URL can host it.

## What's New in 1.3.0

The glossy owl arrives! All-new 3D-style owl hero with playful expressions, five glossy rival creatures, the head-on duel rule (whoever is outside their zone loses!), smarter bots, a lighter and faster engine, and a fresh coat of vivid color everywhere. Draw a loop and claim the arena!

## App Review information

- Contact name: Aadel Soumbati
- Contact email: adilsoumebati@gmail.com
- Contact phone: ⚠️ ASC may require a phone number — copy it from the sister app's (Tiny Scholars) App Review Information, do not invent one.
- Notes for the reviewer (suggested): "Color Claim Puzzle is a fully offline single-player game against built-in AI bots. No account, no sign-in, no internet connection is needed — every feature is available immediately from the home screen. Tap PLAY, choose Level 1, then drag on the board to steer the owl; leave the colored zone, draw a loop and return home to claim territory."
- Demo account: none needed.

## Listing checklist before hitting Submit

1. Upload screenshots in the order above (iPhone 6.7"/6.9" + iPad 13" slots).
2. Paste name, subtitle, promotional text, description, keywords from this file.
3. Categories: Games (Puzzle) primary, Action secondary.
4. Price: Free; Availability: all except EU-27 (DSA trader declaration deferred).
5. Privacy: Data Not Collected.
6. Age rating questionnaire → expected 4+.
7. Review contact: adilsoumebati@gmail.com / Aadel Soumbati; phone copied from Tiny Scholars' review info if requested.
8. Select build 1.3.0 (5), add the What's New text, then submit.
