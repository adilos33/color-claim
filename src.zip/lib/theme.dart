/// Color Claim's own design system (4.3 rework, 1.4.0).
///
/// Deep indigo night-sky chrome with ember-orange accents — a deliberate
/// break from the old dark-teal chrome that the sibling apps share.
/// In-game skin gradients
/// are game content, not chrome, and are intentionally untouched.
/// All headings and HUD numbers use the bundled display font
/// ([kDisplayFontFamily]); body text keeps the system font for
/// readability at small sizes.
library;

import 'package:flutter/material.dart';

/// Bundled display typeface (Archivo Black, OFL — see
/// assets/fonts/README.md). Used for headings and HUD numbers.
const String kDisplayFontFamily = 'ClaimDisplay';

/// Night-sky chrome: deep indigo top of the background gradient.
const Color kNightTop = Color(0xFF141031);

/// Night-sky chrome: indigo bottom of the background gradient.
const Color kNightBottom = Color(0xFF241B4D);

/// Ember-orange primary accent for buttons, highlights and the Nemesis.
const Color kEmber = Color(0xFFFF6A2A);

/// Lighter ember for gradient tops and glows.
const Color kEmberLight = Color(0xFFFF9A3D);

/// Deep ember for gradient bottoms and pressed states.
const Color kEmberDeep = Color(0xFFD94E12);

/// Star gold, kept from the original palette for points/ranks.
const Color kStarGold = Color(0xFFFFD93D);

/// Full-screen night-sky background gradient for menu/HUD chrome.
const LinearGradient kNightGradient = LinearGradient(
  begin: Alignment.topCenter,
  end: Alignment.bottomCenter,
  colors: [kNightTop, kNightBottom],
);

/// Ember gradient for primary actions and featured panels.
const LinearGradient kEmberGradient = LinearGradient(
  begin: Alignment.topLeft,
  end: Alignment.bottomRight,
  colors: [kEmberLight, kEmber, kEmberDeep],
);

/// Display-font heading style (titles, section headers, card titles).
TextStyle displayHeading({
  double size = 22,
  Color color = Colors.white,
  double letterSpacing = 0.5,
}) => TextStyle(
  fontFamily: kDisplayFontFamily,
  fontSize: size,
  fontWeight: FontWeight.w900,
  color: color,
  letterSpacing: letterSpacing,
);

/// Display-font number style (HUD percents, scores, points, ranks).
TextStyle displayNumber({
  double size = 18,
  Color color = Colors.white,
}) => TextStyle(
  fontFamily: kDisplayFontFamily,
  fontSize: size,
  fontWeight: FontWeight.w900,
  color: color,
);
