/// Daily challenges and day streaks for Color Claim (Stage C).
///
/// Pure Dart, no Flutter imports. One challenge is offered per local
/// calendar day, chosen deterministically from the date alone, so the
/// same day always shows the same challenge on every device with no
/// network access. Finishing it banks a flat ⭐ bonus and advances the
/// consecutive-day streak.
library;

import 'game_mode.dart';

/// Flat ⭐ bonus banked the moment a daily challenge is completed.
const int kDailyChallengeBonusPoints = 150;

/// What a finished match is measured against for its daily challenge.
enum DailyChallengeKind {
  /// Best single-match claimed percent reaches the goal.
  capturePercentOnce,

  /// Knockouts scored across the whole day reach the goal.
  knockoutsToday,

  /// Win one Quick Match today.
  quickVictory,

  /// Best single Survival run (seconds) reaches the goal.
  survivalSecondsOnce,

  /// Clear one Classic level today.
  classicVictory,
}

/// One daily challenge definition. [goal] is measured in the kind's
/// natural unit: whole percent, knockouts, seconds, or 1 for wins.
class DailyChallenge {
  final String id;
  final DailyChallengeKind kind;
  final int goal;
  final String title;

  const DailyChallenge({
    required this.id,
    required this.kind,
    required this.goal,
    required this.title,
  });
}

/// The rotating roster. Order matters: it is the rotation order.
const List<DailyChallenge> kDailyChallenges = [
  DailyChallenge(
    id: 'capture_25',
    kind: DailyChallengeKind.capturePercentOnce,
    goal: 25,
    title: 'Capture 25% in one match',
  ),
  DailyChallenge(
    id: 'knockouts_3',
    kind: DailyChallengeKind.knockoutsToday,
    goal: 3,
    title: 'Score 3 knockouts today',
  ),
  DailyChallenge(
    id: 'quick_win',
    kind: DailyChallengeKind.quickVictory,
    goal: 1,
    title: 'Win a Quick Match',
  ),
  DailyChallenge(
    id: 'capture_40',
    kind: DailyChallengeKind.capturePercentOnce,
    goal: 40,
    title: 'Capture 40% in one match',
  ),
  DailyChallenge(
    id: 'survive_90',
    kind: DailyChallengeKind.survivalSecondsOnce,
    goal: 90,
    title: 'Survive 90 seconds in Survival',
  ),
  DailyChallenge(
    id: 'classic_win',
    kind: DailyChallengeKind.classicVictory,
    goal: 1,
    title: 'Clear a Classic level',
  ),
];

/// `YYYY-MM-DD` key for the local calendar day of [date]. Only the
/// year/month/day fields are used, so time of day and device timezone
/// shifts never leak into the key.
String dateKeyFor(DateTime date) {
  final y = date.year.toString().padLeft(4, '0');
  final m = date.month.toString().padLeft(2, '0');
  final d = date.day.toString().padLeft(2, '0');
  return '$y-$m-$d';
}

/// The challenge offered on the local calendar day of [date].
///
/// Deterministic rotation: the number of whole days between the date
/// and 2024-01-01, modulo the roster size. Consecutive days therefore
/// advance one step through the roster and wrap around.
DailyChallenge challengeForDate(DateTime date) {
  final days = DateTime.utc(date.year, date.month, date.day)
      .difference(DateTime.utc(2024, 1, 1))
      .inDays;
  final n = kDailyChallenges.length;
  return kDailyChallenges[((days % n) + n) % n];
}

/// Final numbers of one finished match, as measured for daily
/// challenges. [percent] is the final claimed percent (peak percent in
/// Survival); [survivalSeconds] only matters in Survival mode.
class MatchStats {
  final GameMode mode;
  final double percent;
  final int knockouts;
  final bool victory;
  final int survivalSeconds;

  const MatchStats({
    required this.mode,
    required this.percent,
    this.knockouts = 0,
    this.victory = false,
    this.survivalSeconds = 0,
  });
}

/// The day's progress toward [challenge] after also counting [match].
double dailyProgressAfter({
  required DailyChallenge challenge,
  required double currentProgress,
  required MatchStats match,
}) {
  switch (challenge.kind) {
    case DailyChallengeKind.capturePercentOnce:
      final claimed = match.percent.isFinite
          ? match.percent.floorToDouble()
          : 0.0;
      return claimed > currentProgress ? claimed : currentProgress;
    case DailyChallengeKind.knockoutsToday:
      return currentProgress + (match.knockouts < 0 ? 0 : match.knockouts);
    case DailyChallengeKind.quickVictory:
      return match.mode == GameMode.quickMatch && match.victory
          ? (currentProgress < 1 ? 1.0 : currentProgress)
          : currentProgress;
    case DailyChallengeKind.classicVictory:
      return match.mode == GameMode.classic && match.victory
          ? (currentProgress < 1 ? 1.0 : currentProgress)
          : currentProgress;
    case DailyChallengeKind.survivalSecondsOnce:
      if (match.mode != GameMode.survival) return currentProgress;
      final seconds = match.survivalSeconds < 0
          ? 0.0
          : match.survivalSeconds.toDouble();
      return seconds > currentProgress ? seconds : currentProgress;
  }
}
