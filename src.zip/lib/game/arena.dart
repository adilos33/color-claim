/// Arena layouts for Color Claim (Stage A).
///
/// Pure Dart, no Flutter imports, so shapes and masks are unit-testable.
/// A mask marks which cells of the 56x56 grid are blocked (void / rock).
/// Blocked cells can never be owned, trailed through, or spawned on, and
/// they are excluded from every percentage denominator.
library;

/// The distinct arena silhouettes used across the levels.
enum ArenaShape { open, circle, ring, cross, islands }

/// Display metadata for one arena shape (English in-app text).
class ArenaShapeInfo {
  final String label;
  final String description;

  const ArenaShapeInfo(this.label, this.description);
}

const Map<ArenaShape, ArenaShapeInfo> kArenaShapeInfo = {
  ArenaShape.open: ArenaShapeInfo(
    'Open Field',
    'The full square arena with no obstacles.',
  ),
  ArenaShape.circle: ArenaShapeInfo(
    'Round Arena',
    'A round arena — the corners are out of play.',
  ),
  ArenaShape.ring: ArenaShapeInfo(
    'Blocked Core',
    'A solid core blocks the middle of the arena.',
  ),
  ArenaShape.cross: ArenaShapeInfo(
    'Cross Channels',
    'Crossed channels funnel everyone into the middle.',
  ),
  ArenaShape.islands: ArenaShapeInfo(
    'Rock Islands',
    'Rocky islands break up the open field.',
  ),
};

extension ArenaShapeLabel on ArenaShape {
  String get label => kArenaShapeInfo[this]!.label;
  String get description => kArenaShapeInfo[this]!.description;
}

/// Immutable blocked-cell mask for one arena shape on a square grid.
class ArenaMask {
  /// Grid width/height the mask was built for.
  final int size;

  /// Row-major flags, `true` where a cell is blocked (void / rock).
  final List<bool> blocked;

  /// Number of cells actors can stand on, own, or trail over.
  final int playableCells;

  const ArenaMask._(this.size, this.blocked, this.playableCells);

  factory ArenaMask.generate(ArenaShape shape, {int size = 56}) {
    final flags = List<bool>.filled(size * size, false);
    final c = (size - 1) / 2; // 27.5 on the standard board
    bool blockedAt(int x, int y) {
      final dx = x - c;
      final dy = y - c;
      final dist2 = dx * dx + dy * dy;
      return switch (shape) {
        ArenaShape.open => false,
        // Corners fall outside the disc.
        ArenaShape.circle => dist2 > 26.0 * 26.0,
        // A solid disc in the middle.
        ArenaShape.ring => dist2 < 8.5 * 8.5,
        // Two crossing bars (12 cells wide); corners are void.
        ArenaShape.cross => !((x >= 22 && x <= 33) || (y >= 22 && y <= 33)),
        // Four rocky discs, kept clear of every spawn point.
        ArenaShape.islands =>
          _near(x, y, 20, 20, 4) ||
              _near(x, y, 36, 20, 4) ||
              _near(x, y, 20, 36, 4) ||
              _near(x, y, 36, 36, 4),
      };
    }

    var playable = 0;
    for (var y = 0; y < size; y++) {
      for (var x = 0; x < size; x++) {
        final b = blockedAt(x, y);
        flags[y * size + x] = b;
        if (!b) playable++;
      }
    }
    return ArenaMask._(size, flags, playable);
  }

  static bool _near(int x, int y, int cx, int cy, int r) {
    final dx = x - cx;
    final dy = y - cy;
    return dx * dx + dy * dy <= r * r;
  }

  bool isBlocked(int x, int y) {
    if (x < 0 || y < 0 || x >= size || y >= size) return true;
    return blocked[y * size + x];
  }

  bool isBlockedCell(int cell) {
    if (cell < 0 || cell >= blocked.length) return true;
    return blocked[cell];
  }

  bool isPlayable(int x, int y) => !isBlocked(x, y);
}
