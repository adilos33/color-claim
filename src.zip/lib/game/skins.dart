/// Original unlockable player skins for Color Claim (Stage B).
///
/// Pure Dart, no Flutter imports. Every skin is an original owl
/// character drawn in code at render time (no image assets): the same
/// round owl body wearing a different color scheme and one small
/// signature marking. Prices are in points, which are earned in
/// matches (see points.dart).
library;

/// Body silhouette kept for save/data compatibility. All skins now
/// render as the owl; the silhouette no longer drives the drawing.
enum SkinShape { drop, sun, sprout, flame, star, gem }

/// Eye/mouth combination for a skin character.
enum FaceStyle { smile, happy, grin, wink, sleepy }

/// Small signature marking an owl wears (forehead charm, head tuft or
/// belly motif), drawn in code by the skin painter.
enum OwlMark { none, wave, sun, leaf, crescent, flame, star, gem }

/// Static definition of one skin.
class SkinDef {
  final String id;
  final String name;

  /// Price in points. 0 means owned from the start.
  final int price;

  /// Main body color (ARGB). Also tints the player's territory/head.
  final int colorArgb;

  /// Secondary color (ARGB) for markings, tufts and other details.
  final int accentArgb;

  final SkinShape shape;
  final FaceStyle face;

  /// The owl's signature marking.
  final OwlMark mark;
  final String blurb;

  const SkinDef({
    required this.id,
    required this.name,
    required this.price,
    required this.colorArgb,
    required this.accentArgb,
    required this.shape,
    required this.face,
    required this.mark,
    required this.blurb,
  });
}

/// The free default skin every player owns.
const SkinDef kCoralDropSkin = SkinDef(
  id: 'coral_drop',
  name: 'Coral Owl',
  price: 0,
  colorArgb: 0xFFFF4757,
  accentArgb: 0xFFFF8A5F,
  shape: SkinShape.drop,
  face: FaceStyle.smile,
  mark: OwlMark.none,
  blurb: 'The original coral owl.',
);

/// All skins, cheapest first. The first entry is the default.
const List<SkinDef> kSkins = [
  kCoralDropSkin,
  SkinDef(
    id: 'ocean_drop',
    name: 'Ocean Owl',
    price: 120,
    colorArgb: 0xFF2E9BFF,
    accentArgb: 0xFFAEE7FF,
    shape: SkinShape.drop,
    face: FaceStyle.happy,
    mark: OwlMark.wave,
    blurb: 'A cheerful owl splashed in sea blue.',
  ),
  SkinDef(
    id: 'sunny_ball',
    name: 'Sunny Owl',
    price: 250,
    colorArgb: 0xFFFFC93D,
    accentArgb: 0xFFFF8A00,
    shape: SkinShape.sun,
    face: FaceStyle.grin,
    mark: OwlMark.sun,
    blurb: 'Pure sunshine with a wink of gold.',
  ),
  SkinDef(
    id: 'leaf_sprout',
    name: 'Leaf Owl',
    price: 400,
    colorArgb: 0xFF2ECC71,
    accentArgb: 0xFF8CF5B0,
    shape: SkinShape.sprout,
    face: FaceStyle.smile,
    mark: OwlMark.leaf,
    blurb: 'Fresh from the meadow treetops.',
  ),
  SkinDef(
    id: 'moon_drop',
    name: 'Moon Owl',
    price: 600,
    colorArgb: 0xFF6C63FF,
    accentArgb: 0xFFFFD93D,
    shape: SkinShape.drop,
    face: FaceStyle.sleepy,
    mark: OwlMark.crescent,
    blurb: 'Dreams in indigo under a crescent moon.',
  ),
  SkinDef(
    id: 'flame_buddy',
    name: 'Flame Owl',
    price: 900,
    colorArgb: 0xFFFF6A2A,
    accentArgb: 0xFFFFD93D,
    shape: SkinShape.flame,
    face: FaceStyle.wink,
    mark: OwlMark.flame,
    blurb: 'Small flame, big attitude.',
  ),
  SkinDef(
    id: 'star_pal',
    name: 'Star Owl',
    price: 1400,
    colorArgb: 0xFFFFD93D,
    accentArgb: 0xFFFF9F1A,
    shape: SkinShape.star,
    face: FaceStyle.happy,
    mark: OwlMark.star,
    blurb: 'Born to shine on the leaderboard.',
  ),
  SkinDef(
    id: 'crystal_gem',
    name: 'Crystal Owl',
    price: 2000,
    colorArgb: 0xFF26D6D6,
    accentArgb: 0xFFBFF6FF,
    shape: SkinShape.gem,
    face: FaceStyle.grin,
    mark: OwlMark.gem,
    blurb: 'The rarest sparkle in the arena.',
  ),
];

/// Id of the skin every save starts with.
const String kDefaultSkinId = 'coral_drop';

/// Looks up a skin by id, falling back to the default skin.
SkinDef skinById(String id) => skinByIdOrNull(id) ?? kCoralDropSkin;

/// Looks up a skin by id, or null when the id is unknown.
SkinDef? skinByIdOrNull(String id) {
  for (final skin in kSkins) {
    if (skin.id == id) return skin;
  }
  return null;
}
