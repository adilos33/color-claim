import 'dart:math';

import 'arena.dart';
import 'powerups.dart';

/// Pure-Dart territory-capture engine for Color Claim.
///
/// Rules (original implementation of the classic territory-capture idea):
/// - The board is a grid. Each actor owns colored cells.
/// - Leaving your own territory starts a trail behind you.
/// - Returning to your own territory claims the trail plus every cell that
///   is enclosed by (trail + your territory) via flood fill.
/// - If any actor steps onto your trail while you are outside, you die.
/// - Stepping onto your own trail is also fatal.
/// - Head-on meeting (player-involved): when the player's head and a
///   bot's head collide — stepping onto each other's head cell or
///   swapping cells — whoever is not standing on their own territory
///   is eliminated. A bot eliminated this way leaves the match for
///   good and its territory turns neutral; the player loses a life
///   (a ready shield blocks that loss instead).
/// - The player has 3 lives; bots respawn after a delay.
class LevelConfig {
  final int id;
  final String name;
  final double goalPercent;
  final int botCount;

  /// Bot moves per engine step (player = 1.0). Higher = faster bots.
  final double botSpeed;
  final int neutralArgb;
  final int backgroundArgb;
  final List<int> botColorsArgb;

  /// Arena layout for this level (blocked cells shape the board).
  final ArenaShape shape;

  const LevelConfig({
    required this.id,
    required this.name,
    required this.goalPercent,
    required this.botCount,
    required this.botSpeed,
    required this.neutralArgb,
    required this.backgroundArgb,
    required this.botColorsArgb,
    required this.shape,
  });
}

const int kPlayerColor = 0xFFFF4757; // vivid coral

const List<LevelConfig> kLevels = [
  LevelConfig(
    id: 1,
    name: 'Meadow',
    goalPercent: 10,
    botCount: 3,
    botSpeed: 0.72,
    neutralArgb: 0xFF1E9E52,
    backgroundArgb: 0xFF0B3D24,
    botColorsArgb: [0xFFFFB020, 0xFF3E9BFF, 0xFFB06BFF],
    shape: ArenaShape.open,
  ),
  LevelConfig(
    id: 2,
    name: 'Candy',
    goalPercent: 15,
    botCount: 3,
    botSpeed: 0.78,
    neutralArgb: 0xFFD63384,
    backgroundArgb: 0xFF3D0A35,
    botColorsArgb: [0xFF3E9BFF, 0xFFFFB020, 0xFF2EE6A8],
    shape: ArenaShape.islands,
  ),
  LevelConfig(
    id: 3,
    name: 'Desert',
    goalPercent: 20,
    botCount: 4,
    botSpeed: 0.84,
    neutralArgb: 0xFFF08A24,
    backgroundArgb: 0xFF4A1F04,
    botColorsArgb: [0xFF17B8A6, 0xFF7C5CFF, 0xFF3E9BFF],
    shape: ArenaShape.circle,
  ),
  LevelConfig(
    id: 4,
    name: 'Ocean',
    goalPercent: 25,
    botCount: 4,
    botSpeed: 0.90,
    neutralArgb: 0xFF0E7CC4,
    backgroundArgb: 0xFF041E42,
    botColorsArgb: [0xFFFFB020, 0xFFFF5D8F, 0xFF2EE6A8],
    shape: ArenaShape.cross,
  ),
  LevelConfig(
    id: 5,
    name: 'Sunset',
    goalPercent: 30,
    botCount: 5,
    botSpeed: 0.96,
    neutralArgb: 0xFFFF6A2A,
    backgroundArgb: 0xFF35082E,
    botColorsArgb: [0xFF9B5DE5, 0xFF00C2A8, 0xFF3E9BFF],
    shape: ArenaShape.islands,
  ),
  LevelConfig(
    id: 6,
    name: 'Galaxy',
    goalPercent: 35,
    botCount: 5,
    botSpeed: 1.02,
    neutralArgb: 0xFF4B34C4,
    backgroundArgb: 0xFF0D0621,
    botColorsArgb: [0xFF2EE6A8, 0xFFFF5D8F, 0xFFFFB020],
    shape: ArenaShape.ring,
  ),
];

const List<String> kBotNames = [
  'Nova',
  'Pixel',
  'Ziggy',
  'Milo',
  'Ruby',
  'Orbit',
];

/// Name of the one Hunter bot fielded by the final levels.
const String kHunterName = 'Vex';

/// First level where ordinary bots may hunt the player's exposed trail.
const int kHuntMinLevel = 4;

/// Levels at or above this field one Hunter bot ([kHunterName]).
const int kHunterMinLevel = 5;

/// Manhattan distance at which a bot notices the player's exposed
/// trail; the Hunter spots it from much further away.
const int kHuntRadius = 13;
const int kHunterHuntRadius = 22;

/// Manhattan distance within which a bot detours to grab a power-up.
const int kPickupSeekRadius = 8;

/// A bot carrying more trail than this skips hunts and pickup detours:
/// banking what it has beats one more risk.
const int kMaxTrailForDetour = 28;

class Actor {
  final int id;
  final String name;
  final int colorArgb;
  final bool isPlayer;
  final int spawnX;
  final int spawnY;

  int x;
  int y;
  int prevX;
  int prevY;
  int dx = 0;
  int dy = -1;
  double speed;
  double moveAcc = 0;

  final List<int> trail = [];
  final Set<int> trailSet = {};

  bool alive = true;
  int respawnSteps = 0;
  int kills = 0;

  // Stage B power-up effect state, timed in engine steps (~80 ms each).
  /// Steps left of +40% speed.
  int speedBoostSteps = 0;

  /// A shield is ready to block one trail cut.
  bool hasShield = false;

  /// Steps left before an unused shield fades.
  int shieldSteps = 0;

  /// Steps left of post-shield-break invulnerability (cuts clear the
  /// trail but cannot kill).
  int invulnSteps = 0;

  // Bot AI state.
  int phase = 0; // 0 = head out, 1 = wander, 2 = return home
  int targetX = 0;
  int targetY = 0;
  bool hasTarget = false;

  // Stage D AI state (smarter bots).
  /// Trail length at which this bot plays safe and heads home. Set per
  /// level at spawn: later-level bots hold a trail longer before
  /// banking it, so early levels stay gentle.
  int trailRiskLimit = 90;

  /// True for the one Hunter bot in the final levels: a bit faster,
  /// and it deliberately tracks the player's exposed trail.
  bool isHunter = false;

  /// While true, the bot's steering target is a player trail cell, so
  /// the enemy-trail avoidance in steering must not stop it stepping
  /// onto exactly that cell.
  bool hunting = false;

  Actor({
    required this.id,
    required this.name,
    required this.colorArgb,
    required this.isPlayer,
    required this.spawnX,
    required this.spawnY,
    required this.speed,
  }) : x = spawnX,
       y = spawnY,
       prevX = spawnX,
       prevY = spawnY;

  bool get isOutside => trail.isNotEmpty;
}

class TerritoryEngine {
  static const int cols = 56;
  static const int rows = 56;
  static const int totalCells = cols * rows;

  /// Sentinel owner value for blocked (void / rock) cells. Blocked cells
  /// are never owned by an actor; actor ids are >= 0 and neutral is -1.
  static const int blockedOwner = -2;

  final LevelConfig level;

  /// Blocked-cell layout for this level's arena shape.
  final ArenaMask mask;
  final Random _rng;

  /// owners[i] = actor id, -1 for neutral, or [blockedOwner].
  final List<int> owners = List<int>.filled(totalCells, -1);
  final List<Actor> actors = [];

  /// Lives the run started with (3 in Classic/Quick Match, 1 Survival).
  final int maxLives;
  int lives;
  int score = 0;
  int playerCaptureCount = 0;
  int playerBotKills = 0;
  bool gameOver = false;
  int steps = 0;

  /// Monotonic counter bumped every time cell ownership changes
  /// (captures and claim circles). Rules never read it; the board
  /// painters use it as a cache key so the mostly-static territory
  /// layer is re-recorded only when it actually changed.
  int boardRevision = 0;

  /// Whether periodic power-up pickups and effects run (Stage B). The
  /// game enables this in every mode; tests may turn it off to isolate
  /// pure movement rules.
  final bool powerUpsEnabled;

  /// Color the player actor spawns with (equipped skin color).
  final int playerColorArgb;

  /// Power-ups currently waiting on the field to be collected.
  final List<PowerUpPickup> pickups = [];

  /// Steps left with every bot slowed by a player-grabbed freeze.
  int botsFrozenSteps = 0;

  /// Steps left with the player slowed by a bot-grabbed freeze.
  int playerFrozenSteps = 0;
  int _stepsSincePickup = 0;

  // Stage B juice bookkeeping (positions of the latest pickup / shield
  // break so the UI can burst particles there). Rules never read these.
  int pickupEvents = 0;
  PowerUpKind lastPickupKind = PowerUpKind.speed;
  int lastPickupX = 0;
  int lastPickupY = 0;
  bool lastPickupByPlayer = false;
  int shieldBreakEvents = 0;
  int lastShieldBreakX = 0;
  int lastShieldBreakY = 0;

  // Juice bookkeeping for the UI (particle bursts, popups, banners).
  // These never affect rules; they only record what just happened.
  int lastPlayerCaptureGainedCells = 0;
  int lastPlayerCaptureX = 0;
  int lastPlayerCaptureY = 0;
  String lastPlayerKillName = '';
  int lastPlayerKillX = 0;
  int lastPlayerKillY = 0;
  int lastPlayerDeathX = 0;
  int lastPlayerDeathY = 0;

  // Head-on meeting bookkeeping (player-involved face-to-face rule).
  /// Bots eliminated for good by a head-on meeting. They leave
  /// [actors] only at the end of the step that eliminated them, so
  /// the movement loops never observe a mid-step list change.
  final List<Actor> _pendingEliminationRemoval = [];

  /// Head cell of every actor when movement began this step, keyed by
  /// actor id. Head-on swaps (two heads exchanging cells) are
  /// recognised against these.
  final Map<int, int> _stepStartCells = {};

  /// Head-on pairs already resolved during the current step, keyed by
  /// `lowId * 1024 + highId`. A meeting resolves at most once per
  /// step, so heads left stacked by a shield save cannot cascade.
  final Set<int> _headOnResolvedPairs = {};

  TerritoryEngine(
    this.level, {
    int seed = 42,
    int initialLives = 3,
    this.powerUpsEnabled = true,
    this.playerColorArgb = kPlayerColor,
  }) : _rng = Random(seed),
       mask = ArenaMask.generate(level.shape, size: cols),
       maxLives = initialLives < 1 ? 1 : initialLives,
       lives = initialLives < 1 ? 1 : initialLives {
    for (var i = 0; i < totalCells; i++) {
      if (mask.blocked[i]) owners[i] = blockedOwner;
    }
    _spawnActors();
  }

  Actor get player => actors.first;
  bool get playerWon => playerPercent >= level.goalPercent;

  /// Playable cells on this board (blocked cells excluded).
  int get playableCells => mask.playableCells;

  int idx(int x, int y) => y * cols + x;
  bool inBounds(int x, int y) => x >= 0 && y >= 0 && x < cols && y < rows;

  /// Nearest playable cell to (x, y), searching outward in rings. Spawn
  /// points and bot targets are resolved through this so no actor is ever
  /// placed on (or sent into) a blocked cell.
  (int, int) nearestPlayable(int x, int y) {
    if (inBounds(x, y) && !mask.isBlocked(x, y)) return (x, y);
    for (var r = 1; r < cols; r++) {
      for (var dy = -r; dy <= r; dy++) {
        for (var dx = -r; dx <= r; dx++) {
          if (dx.abs() != r && dy.abs() != r) continue;
          final nx = x + dx;
          final ny = y + dy;
          if (inBounds(nx, ny) && !mask.isBlocked(nx, ny)) return (nx, ny);
        }
      }
    }
    return (x, y);
  }

  void _spawnActors() {
    final rawSpawns = <(int, int)>[
      (12, rows - 13), // player
      (cols - 13, 12),
      (12, 12),
      (cols - 13, rows - 13),
      (cols ~/ 2, rows ~/ 2),
      (cols ~/ 2, 10),
    ];
    final spawns = [for (final s in rawSpawns) nearestPlayable(s.$1, s.$2)];
    final p = Actor(
      id: 0,
      name: 'You',
      colorArgb: playerColorArgb,
      isPlayer: true,
      spawnX: spawns[0].$1,
      spawnY: spawns[0].$2,
      speed: 1.0,
    );
    p.dx = 0;
    p.dy = -1;
    actors.add(p);
    _claimCircle(p, p.spawnX, p.spawnY, 4);

    for (var i = 0; i < level.botCount; i++) {
      final s = spawns[i + 1];
      // The first bot of the final levels is the Hunter: distinct name,
      // unique flag, and a modest speed edge (still very beatable).
      final isHunterBot = i == 0 && level.id >= kHunterMinLevel;
      final bot = Actor(
        id: i + 1,
        name: isHunterBot ? kHunterName : kBotNames[i % kBotNames.length],
        colorArgb: level.botColorsArgb[i % level.botColorsArgb.length],
        isPlayer: false,
        spawnX: s.$1,
        spawnY: s.$2,
        speed: level.botSpeed * (0.9 + _rng.nextDouble() * 0.2),
      );
      bot.dx = i.isEven ? 1 : -1;
      bot.dy = 0;
      // Self-preservation budget, level-scaled without touching the
      // rng stream: bigger ids get a small deterministic variation.
      bot.trailRiskLimit = 46 + level.id * 7 + (bot.id * 5) % 13;
      if (isHunterBot) {
        bot.isHunter = true;
        bot.speed *= 1.12;
      }
      actors.add(bot);
      _claimCircle(bot, bot.spawnX, bot.spawnY, 4);
    }
  }

  void _claimCircle(Actor a, int cx, int cy, int r) {
    for (var y = cy - r; y <= cy + r; y++) {
      for (var x = cx - r; x <= cx + r; x++) {
        if (inBounds(x, y) &&
            !mask.isBlocked(x, y) &&
            (x - cx) * (x - cx) + (y - cy) * (y - cy) <= r * r) {
          owners[idx(x, y)] = a.id;
        }
      }
    }
    boardRevision++;
  }

  double percentFor(int actorId) {
    var count = 0;
    for (final o in owners) {
      if (o == actorId) count++;
    }
    // Denominator counts playable cells only, so percentages stay fair
    // on arenas with void corners, cores, channels, or rocks.
    return count * 100.0 / mask.playableCells;
  }

  double get playerPercent => percentFor(0);

  List<Actor> get leaderboard =>
      [...actors]..sort((a, b) => percentFor(b.id).compareTo(percentFor(a.id)));

  /// Set the player's heading. 180-degree reversals are ignored while the
  /// player is outside on a trail (classic rule, keeps controls forgiving).
  void setPlayerDirection(int ndx, int ndy) {
    final p = player;
    if (!p.alive || gameOver) return;
    if (ndx == -p.dx && ndy == -p.dy && (p.dx != 0 || p.dy != 0)) {
      if (p.isOutside) return;
    }
    if (ndx == p.dx && ndy == p.dy) return;
    p.dx = ndx;
    p.dy = ndy;
  }

  /// Movement rate (cells per engine step) for [a] after power-up
  /// effects: speed boosts multiply by [kSpeedMultiplier]; a freeze the
  /// other side collected multiplies by [kFreezeMultiplier].
  double effectiveSpeed(Actor a) {
    var s = a.speed;
    if (a.speedBoostSteps > 0) s *= kSpeedMultiplier;
    if (a.isPlayer) {
      if (playerFrozenSteps > 0) s *= kFreezeMultiplier;
    } else if (botsFrozenSteps > 0) {
      s *= kFreezeMultiplier;
    }
    return s;
  }

  void step() {
    if (gameOver) return;
    steps++;

    // Respawn dead bots.
    for (final a in actors) {
      if (!a.alive && !a.isPlayer) {
        a.respawnSteps--;
        if (a.respawnSteps <= 0) _respawn(a);
      }
    }

    // Remember where every head stands as movement begins; head-on
    // swap detection compares against these cells.
    _stepStartCells.clear();
    _headOnResolvedPairs.clear();
    for (final a in actors) {
      if (a.alive) _stepStartCells[a.id] = idx(a.x, a.y);
    }

    // The player advances at its effective speed, same accumulation
    // scheme the bots use (a boost can move it twice in one step).
    if (player.alive) {
      player.moveAcc += effectiveSpeed(player);
      while (player.moveAcc >= 1.0) {
        player.moveAcc -= 1.0;
        _moveActor(player);
        if (!player.alive) break;
      }
    }

    for (final a in actors) {
      if (a.isPlayer || !a.alive) continue;
      a.moveAcc += effectiveSpeed(a);
      while (a.moveAcc >= 1.0) {
        a.moveAcc -= 1.0;
        _steerBot(a);
        _moveActor(a);
        if (!a.alive) break;
      }
    }

    // Bots eliminated head-on leave the match for good.
    if (_pendingEliminationRemoval.isNotEmpty) {
      actors.removeWhere(_pendingEliminationRemoval.contains);
      _pendingEliminationRemoval.clear();
    }

    if (powerUpsEnabled) _updatePowerUps();
  }

  // ------------------------------------------------------------------
  // Stage B: power-up pickups and timed effects.
  // ------------------------------------------------------------------

  /// A cell may hold a pickup only when it is playable, unowned, inside
  /// no actor's trail, and free of actor heads and other pickups.
  bool isValidPickupCell(int x, int y) {
    if (!inBounds(x, y)) return false;
    final cell = idx(x, y);
    if (mask.isBlockedCell(cell)) return false;
    if (owners[cell] != -1) return false;
    for (final a in actors) {
      if (a.x == x && a.y == y) return false;
      if (a.trailSet.contains(cell)) return false;
    }
    for (final p in pickups) {
      if (p.x == x && p.y == y) return false;
    }
    return true;
  }

  /// Tries to place one random pickup on a valid cell. Random attempts
  /// come first for varied placement; a full-board scan guarantees a
  /// spot whenever one exists. Returns whether a pickup was placed.
  bool spawnPickup() {
    if (pickups.length >= kMaxPickupsOnField) return false;
    for (var attempt = 0; attempt < 80; attempt++) {
      final x = _rng.nextInt(cols);
      final y = _rng.nextInt(rows);
      if (isValidPickupCell(x, y)) {
        _placePickup(x, y);
        return true;
      }
    }
    for (var i = 0; i < totalCells; i++) {
      final x = i % cols;
      final y = i ~/ cols;
      if (isValidPickupCell(x, y)) {
        _placePickup(x, y);
        return true;
      }
    }
    return false;
  }

  void _placePickup(int x, int y) {
    final kind = PowerUpKind.values[_rng.nextInt(PowerUpKind.values.length)];
    pickups.add(PowerUpPickup(kind: kind, x: x, y: y));
  }

  /// Applies the effect of [p] to its collector. Freeze hits the other
  /// side: a player-grabbed freeze slows every bot, while a bot-grabbed
  /// freeze slows the player.
  void _applyPickup(Actor a, PowerUpPickup p) {
    switch (p.kind) {
      case PowerUpKind.speed:
        a.speedBoostSteps = kSpeedBoostSteps;
      case PowerUpKind.shield:
        a.hasShield = true;
        a.shieldSteps = kShieldSteps;
      case PowerUpKind.freeze:
        if (a.isPlayer) {
          botsFrozenSteps = kFreezeSteps;
        } else {
          playerFrozenSteps = kFreezeSteps;
        }
    }
  }

  void _collectAt(Actor a) {
    for (var i = pickups.length - 1; i >= 0; i--) {
      final p = pickups[i];
      if (p.x != a.x || p.y != a.y) continue;
      pickups.removeAt(i);
      _applyPickup(a, p);
      pickupEvents++;
      lastPickupKind = p.kind;
      lastPickupX = p.x;
      lastPickupY = p.y;
      lastPickupByPlayer = a.isPlayer;
    }
  }

  /// Per-step effect bookkeeping: countdowns, expiries, and the spawn
  /// cadence (a fresh pickup about every [kPickupSpawnSteps] steps,
  /// capped at [kMaxPickupsOnField] on the field).
  void _updatePowerUps() {
    for (final a in actors) {
      if (a.speedBoostSteps > 0) a.speedBoostSteps--;
      if (a.invulnSteps > 0) a.invulnSteps--;
      if (a.shieldSteps > 0) {
        a.shieldSteps--;
        if (a.shieldSteps <= 0) a.hasShield = false;
      }
    }
    if (botsFrozenSteps > 0) botsFrozenSteps--;
    if (playerFrozenSteps > 0) playerFrozenSteps--;

    _stepsSincePickup++;
    if (_stepsSincePickup >= kPickupSpawnSteps &&
        pickups.length < kMaxPickupsOnField) {
      if (spawnPickup()) {
        _stepsSincePickup = 0;
      } else {
        // No valid cell right now; retry soon instead of waiting a
        // whole new cadence.
        _stepsSincePickup = kPickupSpawnSteps - 12;
      }
    }
  }

  void _moveActor(Actor a) {
    final nx = a.x + a.dx;
    final ny = a.y + a.dy;
    if (!inBounds(nx, ny) || mask.isBlocked(nx, ny)) {
      if (!a.isPlayer) {
        // Bounce bots off the wall with a fresh AI decision next step.
        a.hasTarget = false;
        a.dx = -a.dx;
        a.dy = -a.dy;
      }
      return;
    }
    a.prevX = a.x;
    a.prevY = a.y;
    a.x = nx;
    a.y = ny;
    _enterCell(a, nx, ny);
  }

  void _enterCell(Actor a, int x, int y) {
    final cell = idx(x, y);

    // Head-on meeting (player-involved only, see _headOnPartner).
    // Resolved before any trail logic: whoever is caught off their
    // own territory is eliminated, so a face-to-face meeting is
    // never also scored as a trail cut.
    final partner = _headOnPartner(a, x, y, cell);
    if (partner != null) {
      _resolveHeadOn(a, partner);
      // The mover may have been eliminated itself or lost a life and
      // teleported to its respawn; only a mover still standing on
      // the entered cell carries on with the normal cell entry.
      if (!a.alive || a.x != x || a.y != y) return;
    }

    final owner = owners[cell];

    if (owner == a.id) {
      // Pickups can end up on owned cells (e.g. a respawn claim circle
      // covers one); stepping onto the cell still collects it.
      if (powerUpsEnabled) _collectAt(a);
      if (a.trail.isNotEmpty) captureTrail(a);
      return;
    }

    // Trail collision: someone (possibly a itself) has a trail on this cell.
    Actor? victim;
    for (final other in actors) {
      if (other.trailSet.contains(cell)) {
        victim = other;
        break;
      }
    }
    if (victim != null) {
      final v = victim;
      _kill(v, killer: a);
      if (identical(v, a) || !a.alive) return;
    }

    a.trail.add(cell);
    a.trailSet.add(cell);

    // Landing on a pickup collects it (player and bots alike).
    if (powerUpsEnabled) _collectAt(a);
  }

  /// Claims the actor's trail plus all cells enclosed by it. Public so it
  /// can be unit-tested directly.
  int captureTrail(Actor a) {
    if (a.trail.isEmpty) return 0;
    var before = 0;
    for (final o in owners) {
      if (o == a.id) before++;
    }
    for (final cell in a.trail) {
      owners[cell] = a.id;
    }
    a.trail.clear();
    a.trailSet.clear();

    // Flood fill from every border cell that is not the actor's; anything
    // unreached and not already the actor's is enclosed -> claim it.
    // Blocked cells are walls: the fill never crosses them and they are
    // never claimed, so a trail plus an obstacle can enclose a pocket.
    final visited = List<bool>.filled(totalCells, false);
    final stack = <int>[];
    void seed(int cell) {
      if (!visited[cell] && owners[cell] != a.id && !mask.isBlockedCell(cell)) {
        visited[cell] = true;
        stack.add(cell);
      }
    }

    for (var x = 0; x < cols; x++) {
      seed(idx(x, 0));
      seed(idx(x, rows - 1));
    }
    for (var y = 0; y < rows; y++) {
      seed(idx(0, y));
      seed(idx(cols - 1, y));
    }
    while (stack.isNotEmpty) {
      final cell = stack.removeLast();
      final cx = cell % cols;
      final cy = cell ~/ cols;
      const dirs = [(1, 0), (-1, 0), (0, 1), (0, -1)];
      for (final d in dirs) {
        final nx = cx + d.$1;
        final ny = cy + d.$2;
        if (!inBounds(nx, ny)) continue;
        final n = idx(nx, ny);
        if (!visited[n] && owners[n] != a.id && !mask.isBlockedCell(n)) {
          visited[n] = true;
          stack.add(n);
        }
      }
    }
    for (var i = 0; i < totalCells; i++) {
      if (!visited[i] && owners[i] != a.id && !mask.isBlockedCell(i)) {
        owners[i] = a.id;
      }
    }
    boardRevision++;

    // Any enemy trail cells swallowed by the capture are removed.
    for (final other in actors) {
      if (identical(other, a) || other.trail.isEmpty) continue;
      other.trail.removeWhere((c) => owners[c] == a.id);
      other.trailSet.removeWhere((c) => owners[c] == a.id);
    }

    // Pickups swallowed by the claim are swept off the field.
    if (pickups.isNotEmpty) {
      pickups.removeWhere((p) => owners[idx(p.x, p.y)] != -1);
    }

    var after = 0;
    for (final o in owners) {
      if (o == a.id) after++;
    }
    final gained = after - before;
    if (a.isPlayer) {
      score += gained;
      if (gained > 0) {
        playerCaptureCount++;
        lastPlayerCaptureGainedCells = gained;
        lastPlayerCaptureX = a.x;
        lastPlayerCaptureY = a.y;
      }
    }
    a.phase = 0;
    a.hasTarget = false;
    a.hunting = false;
    return gained;
  }

  /// Finds the head-on partner for [mover] entering (x, y), if any.
  ///
  /// A meeting happens when the mover steps onto the cell another
  /// actor's head occupies right now, or when the two heads swap
  /// cells head-on: the mover enters the cell the other head started
  /// this step on while that head now stands on the mover's own
  /// starting cell. Only meetings involving the player count — bots
  /// pass bots under the usual trail rules. Each pair resolves at
  /// most once per step.
  Actor? _headOnPartner(Actor mover, int x, int y, int cell) {
    for (final o in actors) {
      if (identical(o, mover) || !o.alive) continue;
      // The meeting rule involves the player only.
      if (!mover.isPlayer && !o.isPlayer) continue;
      final swap =
          _stepStartCells[o.id] == cell &&
          _stepStartCells[mover.id] == idx(o.x, o.y);
      if ((o.x == x && o.y == y) || swap) {
        final key = mover.id < o.id
            ? mover.id * 1024 + o.id
            : o.id * 1024 + mover.id;
        if (!_headOnResolvedPairs.add(key)) return null;
        return o;
      }
    }
    return null;
  }

  /// Resolves a head-on meeting between the player and [other] (the
  /// [mover] is one of the two). Whoever is not standing on their own
  /// territory at this moment is eliminated: a bot leaves the match
  /// for good via [_eliminateBot]; the player loses a life through
  /// the usual [_kill] flow, so a ready shield consumes the hit
  /// instead. If both heads are home (a border pass), nobody dies.
  ///
  /// "Standing on your own territory" is judged by the cell under
  /// each head: an actor on a foreign cell is always carrying that
  /// cell in its trail, and an actor on its own cell is home even if
  /// it is arriving with a trail to bank.
  void _resolveHeadOn(Actor mover, Actor other) {
    final bot = mover.isPlayer ? other : mover;
    final p = player;
    final playerHome = owners[idx(p.x, p.y)] == p.id;
    final botHome = owners[idx(bot.x, bot.y)] == bot.id;
    if (playerHome && botHome) return; // Border pass: nobody exposed.
    if (!botHome) _eliminateBot(bot, killer: p);
    if (!playerHome) _kill(p, killer: bot);
  }

  /// Permanently eliminates [bot] after a lost head-on meeting: its
  /// trail vanishes, its territory returns to neutral (claimable by
  /// anyone), and it leaves the match for good — no respawn. The
  /// player earns the same knockout credit a trail cut would give
  /// (kills, score, [playerBotKills], and the banner/burst position),
  /// so end-of-match points count it like any other knockout.
  void _eliminateBot(Actor bot, {required Actor killer}) {
    bot.trail.clear();
    bot.trailSet.clear();
    var freed = false;
    for (var i = 0; i < totalCells; i++) {
      if (owners[i] == bot.id) {
        owners[i] = -1;
        freed = true;
      }
    }
    if (freed) boardRevision++;
    if (!identical(killer, bot)) {
      killer.kills++;
      if (killer.isPlayer) {
        score += 100;
        playerBotKills++;
        lastPlayerKillName = bot.name;
        lastPlayerKillX = bot.x;
        lastPlayerKillY = bot.y;
      }
    }
    bot.alive = false;
    bot.respawnSteps = 0; // Never respawns; removed at end of step.
    _pendingEliminationRemoval.add(bot);
  }

  void _kill(Actor victim, {required Actor killer}) {
    victim.trail.clear();
    victim.trailSet.clear();

    // Shield / invulnerability blocks the death itself. The cut still
    // erases the victim's trail (and grants the cutter no kill credit),
    // a ready shield is consumed, and the victim becomes briefly
    // invulnerable so one cut can never chain into a second.
    if (victim.hasShield || victim.invulnSteps > 0) {
      if (victim.hasShield) {
        victim.hasShield = false;
        victim.shieldSteps = 0;
      }
      victim.invulnSteps = kInvulnSteps;
      if (victim.isPlayer) {
        shieldBreakEvents++;
        lastShieldBreakX = victim.x;
        lastShieldBreakY = victim.y;
      }
      return;
    }

    if (!identical(killer, victim)) {
      killer.kills++;
      if (killer.isPlayer) {
        score += 100;
        if (!victim.isPlayer) {
          playerBotKills++;
          lastPlayerKillName = victim.name;
          lastPlayerKillX = victim.x;
          lastPlayerKillY = victim.y;
        }
      }
    }
    if (victim.isPlayer) {
      lastPlayerDeathX = victim.x;
      lastPlayerDeathY = victim.y;
      lives--;
      if (lives <= 0) {
        victim.alive = false;
        gameOver = true;
      } else {
        _respawn(victim);
      }
    } else {
      victim.alive = false;
      victim.respawnSteps = 28;
    }
  }

  void _respawn(Actor a) {
    final mine = <int>[];
    for (var i = 0; i < totalCells; i++) {
      if (owners[i] == a.id) mine.add(i);
    }
    if (mine.isEmpty) {
      _claimCircle(a, a.spawnX, a.spawnY, 4);
      a.x = a.spawnX;
      a.y = a.spawnY;
    } else {
      final cell = mine[_rng.nextInt(mine.length)];
      a.x = cell % cols;
      a.y = cell ~/ cols;
    }
    a.prevX = a.x;
    a.prevY = a.y;
    a.trail.clear();
    a.trailSet.clear();
    a.alive = true;
    a.phase = 0;
    a.hasTarget = false;
    a.hunting = false;
    a.dx = 0;
    a.dy = -1;
    // Fresh spawn: no leftover power-up effects.
    a.speedBoostSteps = 0;
    a.hasShield = false;
    a.shieldSteps = 0;
    a.invulnSteps = 0;
    // The fresh claim circle may cover a waiting pickup.
    if (pickups.isNotEmpty) {
      pickups.removeWhere((p) => owners[idx(p.x, p.y)] != -1);
    }
  }

  (int, int) _homeCentroid(Actor a) {
    var sx = 0, sy = 0, n = 0;
    for (var i = 0; i < totalCells; i++) {
      if (owners[i] == a.id) {
        sx += i % cols;
        sy += i ~/ cols;
        n++;
      }
    }
    if (n == 0) return (a.spawnX, a.spawnY);
    return (sx ~/ n, sy ~/ n);
  }

  /// Stage D opportunistic steering target, checked when a bot picks
  /// somewhere new to go. Hunting beats a power-up grab, which beats
  /// the normal phase wander. Returns null for the normal phases.
  ///
  /// Hunting: the Hunter always tracks the player's exposed trail
  /// within [kHunterHuntRadius]; ordinary bots only from
  /// [kHuntMinLevel] on, only within [kHuntRadius], and only
  /// sometimes (they are not perfect predators). A bot carrying a
  /// long trail skips both detours — coming home safely wins.
  (int, int)? _specialTarget(Actor bot) {
    if (bot.trail.length > kMaxTrailForDetour) return null;

    final p = player;
    final canHunt = bot.isHunter || level.id >= kHuntMinLevel;
    if (canHunt && p.alive && p.isOutside) {
      final radius = bot.isHunter ? kHunterHuntRadius : kHuntRadius;
      (int, int)? nearest;
      var best = radius + 1;
      for (final cell in p.trail) {
        final cx = cell % cols;
        final cy = cell ~/ cols;
        final d = (bot.x - cx).abs() + (bot.y - cy).abs();
        if (d < best) {
          best = d;
          nearest = (cx, cy);
        }
      }
      if (nearest != null && (bot.isHunter || _rng.nextDouble() < 0.6)) {
        bot.hunting = true;
        return nearest;
      }
    }

    // Power-up grab: any bot detours for a close pickup on purpose
    // now instead of only stumbling onto one.
    (int, int)? bestPickup;
    var bestDist = kPickupSeekRadius + 1;
    for (final pickup in pickups) {
      final d = (bot.x - pickup.x).abs() + (bot.y - pickup.y).abs();
      if (d < bestDist) {
        bestDist = d;
        bestPickup = (pickup.x, pickup.y);
      }
    }
    return bestPickup;
  }

  void _steerBot(Actor bot) {
    final atHome = owners[idx(bot.x, bot.y)] == bot.id;
    if (atHome && bot.phase == 2) {
      bot.phase = 0;
      bot.hasTarget = false;
    }
    // Self-preservation: once the trail reaches this bot's risk limit,
    // banking it beats wandering on — head home before it gets cut.
    // The limit grows by level, so early bots come home early and the
    // late-game bots push further (old flat rule was 90 for everyone).
    if (bot.trail.length >= bot.trailRiskLimit && bot.phase != 2) {
      bot.phase = 2;
      bot.hasTarget = false;
      bot.hunting = false;
    }
    if (!bot.hasTarget || (bot.x == bot.targetX && bot.y == bot.targetY)) {
      if (bot.hasTarget) bot.phase = (bot.phase + 1) % 3;
      final home = _homeCentroid(bot);
      bot.hunting = false;
      // Stage D detours (hunting / power-up grab) only when this bot
      // is not already on its way home.
      var picked = false;
      if (bot.phase != 2) {
        final special = _specialTarget(bot);
        if (special != null) {
          bot.targetX = special.$1;
          bot.targetY = special.$2;
          picked = true;
        }
      }
      if (!picked) {
        switch (bot.phase) {
          case 0:
            final angle = _rng.nextDouble() * 2 * pi;
            final dist = 10 + _rng.nextInt(9);
            bot.targetX = (home.$1 + cos(angle) * dist).round().clamp(
              2,
              cols - 3,
            );
            bot.targetY = (home.$2 + sin(angle) * dist).round().clamp(
              2,
              rows - 3,
            );
            break;
          case 1:
            bot.targetX = (bot.x + _rng.nextInt(13) - 6).clamp(2, cols - 3);
            bot.targetY = (bot.y + _rng.nextInt(13) - 6).clamp(2, rows - 3);
            break;
          default:
            bot.targetX = home.$1;
            bot.targetY = home.$2;
        }
      }
      // Obstacles: never aim into a blocked cell.
      final resolved = nearestPlayable(bot.targetX, bot.targetY);
      bot.targetX = resolved.$1;
      bot.targetY = resolved.$2;
      bot.hasTarget = true;
    }

    const dirs = [(1, 0), (-1, 0), (0, 1), (0, -1)];
    var bestScore = double.infinity;
    var best = (bot.dx, bot.dy);
    for (final d in dirs) {
      final isReverse = d.$1 == -bot.dx && d.$2 == -bot.dy;
      if (isReverse && bot.isOutside) continue;
      final nx = bot.x + d.$1;
      final ny = bot.y + d.$2;
      if (!inBounds(nx, ny) || mask.isBlocked(nx, ny)) continue;
      var s = ((nx - bot.targetX).abs() + (ny - bot.targetY).abs()).toDouble();
      final cell = idx(nx, ny);
      if (bot.trailSet.contains(cell)) s += 1000;
      // Mostly avoid enemy trails, occasionally blunder (feels human).
      // A hunting bot skips this for its prey: stepping onto the
      // player's trail is exactly what it came to do. The red danger
      // vignette still warns the player as it closes in.
      for (final other in actors) {
        if (!identical(other, bot) && other.trailSet.contains(cell)) {
          if (bot.hunting && other.isPlayer) continue;
          s += _rng.nextDouble() < 0.9 ? 60 : 0;
        }
      }
      s += _rng.nextDouble() * 0.5;
      if (s < bestScore) {
        bestScore = s;
        best = d;
      }
    }
    bot.dx = best.$1;
    bot.dy = best.$2;
  }
}
