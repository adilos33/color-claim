import 'dart:math';

/// Pure-Dart territory-capture engine for Color Claim.
///
/// Rules (original implementation of the classic territory-capture idea):
/// - The board is a grid. Each actor owns colored cells.
/// - Leaving your own territory starts a trail behind you.
/// - Returning to your own territory claims the trail plus every cell that
///   is enclosed by (trail + your territory) via flood fill.
/// - If any actor steps onto your trail while you are outside, you die.
/// - Stepping onto your own trail is also fatal.
/// - The player has 3 lives; bots respawn after a delay.
class LevelConfig {
  final int id;
  final String name;
  final double goalPercent;
  final int botCount;

  /// Bot moves per engine step (player = 1.0). Higher = faster bots.
  final double botSpeed;
  final int neutralArgb;
  final int backgroundArgb;
  final List<int> botColorsArgb;

  const LevelConfig({
    required this.id,
    required this.name,
    required this.goalPercent,
    required this.botCount,
    required this.botSpeed,
    required this.neutralArgb,
    required this.backgroundArgb,
    required this.botColorsArgb,
  });
}

const int kPlayerColor = 0xFF0FB5A3; // bright teal

const List<LevelConfig> kLevels = [
  LevelConfig(
    id: 1,
    name: 'Meadow',
    goalPercent: 10,
    botCount: 3,
    botSpeed: 0.72,
    neutralArgb: 0xFFDFF3CF,
    backgroundArgb: 0xFFF2FAEA,
    botColorsArgb: [0xFFFF6B6B, 0xFFFFB020, 0xFF8B7CF6],
  ),
  LevelConfig(
    id: 2,
    name: 'Candy',
    goalPercent: 15,
    botCount: 3,
    botSpeed: 0.78,
    neutralArgb: 0xFFFDE4F1,
    backgroundArgb: 0xFFFFF3F9,
    botColorsArgb: [0xFF4D96FF, 0xFFFF9F1C, 0xFF7BC950],
  ),
  LevelConfig(
    id: 3,
    name: 'Desert',
    goalPercent: 20,
    botCount: 4,
    botSpeed: 0.84,
    neutralArgb: 0xFFF7E7C3,
    backgroundArgb: 0xFFFDF6E3,
    botColorsArgb: [0xFFE4572E, 0xFF17A398, 0xFF7C5CBF],
  ),
  LevelConfig(
    id: 4,
    name: 'Ocean',
    goalPercent: 25,
    botCount: 4,
    botSpeed: 0.90,
    neutralArgb: 0xFFD6EEFB,
    backgroundArgb: 0xFFEFF8FE,
    botColorsArgb: [0xFFFF6B6B, 0xFFFFC53D, 0xFF6BCB77],
  ),
  LevelConfig(
    id: 5,
    name: 'Sunset',
    goalPercent: 30,
    botCount: 5,
    botSpeed: 0.96,
    neutralArgb: 0xFFFFE3D3,
    backgroundArgb: 0xFFFFF4EC,
    botColorsArgb: [0xFF9B5DE5, 0xFF00B4A2, 0xFFFF5D8F],
  ),
  LevelConfig(
    id: 6,
    name: 'Galaxy',
    goalPercent: 35,
    botCount: 5,
    botSpeed: 1.02,
    neutralArgb: 0xFFE3E0FA,
    backgroundArgb: 0xFFF1EFFE,
    botColorsArgb: [0xFFFF6B6B, 0xFF00C2A8, 0xFFFFB020],
  ),
];

const List<String> kBotNames = [
  'Nova',
  'Pixel',
  'Ziggy',
  'Milo',
  'Ruby',
  'Orbit',
];

class Actor {
  final int id;
  final String name;
  final int colorArgb;
  final bool isPlayer;
  final int spawnX;
  final int spawnY;

  int x;
  int y;
  int prevX;
  int prevY;
  int dx = 0;
  int dy = -1;
  double speed;
  double moveAcc = 0;

  final List<int> trail = [];
  final Set<int> trailSet = {};

  bool alive = true;
  int respawnSteps = 0;
  int kills = 0;

  // Bot AI state.
  int phase = 0; // 0 = head out, 1 = wander, 2 = return home
  int targetX = 0;
  int targetY = 0;
  bool hasTarget = false;

  Actor({
    required this.id,
    required this.name,
    required this.colorArgb,
    required this.isPlayer,
    required this.spawnX,
    required this.spawnY,
    required this.speed,
  }) : x = spawnX,
       y = spawnY,
       prevX = spawnX,
       prevY = spawnY;

  bool get isOutside => trail.isNotEmpty;
}

class TerritoryEngine {
  static const int cols = 56;
  static const int rows = 56;
  static const int totalCells = cols * rows;

  final LevelConfig level;
  final Random _rng;

  /// owners[i] = actor id, or -1 for neutral.
  final List<int> owners = List<int>.filled(totalCells, -1);
  final List<Actor> actors = [];

  int lives = 3;
  int score = 0;
  int playerCaptureCount = 0;
  int playerBotKills = 0;
  bool gameOver = false;
  int steps = 0;

  TerritoryEngine(this.level, {int seed = 42}) : _rng = Random(seed) {
    _spawnActors();
  }

  Actor get player => actors.first;
  bool get playerWon => playerPercent >= level.goalPercent;

  int idx(int x, int y) => y * cols + x;
  bool inBounds(int x, int y) => x >= 0 && y >= 0 && x < cols && y < rows;

  void _spawnActors() {
    final spawns = <(int, int)>[
      (12, rows - 13), // player
      (cols - 13, 12),
      (12, 12),
      (cols - 13, rows - 13),
      (cols ~/ 2, rows ~/ 2),
      (cols ~/ 2, 10),
    ];
    final p = Actor(
      id: 0,
      name: 'You',
      colorArgb: kPlayerColor,
      isPlayer: true,
      spawnX: spawns[0].$1,
      spawnY: spawns[0].$2,
      speed: 1.0,
    );
    p.dx = 0;
    p.dy = -1;
    actors.add(p);
    _claimCircle(p, p.spawnX, p.spawnY, 4);

    for (var i = 0; i < level.botCount; i++) {
      final s = spawns[i + 1];
      final bot = Actor(
        id: i + 1,
        name: kBotNames[i % kBotNames.length],
        colorArgb: level.botColorsArgb[i % level.botColorsArgb.length],
        isPlayer: false,
        spawnX: s.$1,
        spawnY: s.$2,
        speed: level.botSpeed * (0.9 + _rng.nextDouble() * 0.2),
      );
      bot.dx = i.isEven ? 1 : -1;
      bot.dy = 0;
      actors.add(bot);
      _claimCircle(bot, bot.spawnX, bot.spawnY, 4);
    }
  }

  void _claimCircle(Actor a, int cx, int cy, int r) {
    for (var y = cy - r; y <= cy + r; y++) {
      for (var x = cx - r; x <= cx + r; x++) {
        if (inBounds(x, y) &&
            (x - cx) * (x - cx) + (y - cy) * (y - cy) <= r * r) {
          owners[idx(x, y)] = a.id;
        }
      }
    }
  }

  double percentFor(int actorId) {
    var count = 0;
    for (final o in owners) {
      if (o == actorId) count++;
    }
    return count * 100.0 / totalCells;
  }

  double get playerPercent => percentFor(0);

  List<Actor> get leaderboard =>
      [...actors]..sort((a, b) => percentFor(b.id).compareTo(percentFor(a.id)));

  /// Set the player's heading. 180-degree reversals are ignored while the
  /// player is outside on a trail (classic rule, keeps controls forgiving).
  void setPlayerDirection(int ndx, int ndy) {
    final p = player;
    if (!p.alive || gameOver) return;
    if (ndx == -p.dx && ndy == -p.dy && (p.dx != 0 || p.dy != 0)) {
      if (p.isOutside) return;
    }
    if (ndx == p.dx && ndy == p.dy) return;
    p.dx = ndx;
    p.dy = ndy;
  }

  void step() {
    if (gameOver) return;
    steps++;

    // Respawn dead bots.
    for (final a in actors) {
      if (!a.alive && !a.isPlayer) {
        a.respawnSteps--;
        if (a.respawnSteps <= 0) _respawn(a);
      }
    }

    if (player.alive) _moveActor(player);

    for (final a in actors) {
      if (a.isPlayer || !a.alive) continue;
      a.moveAcc += a.speed;
      while (a.moveAcc >= 1.0) {
        a.moveAcc -= 1.0;
        _steerBot(a);
        _moveActor(a);
        if (!a.alive) break;
      }
    }
  }

  void _moveActor(Actor a) {
    final nx = a.x + a.dx;
    final ny = a.y + a.dy;
    if (!inBounds(nx, ny)) {
      if (!a.isPlayer) {
        // Bounce bots off the wall with a fresh AI decision next step.
        a.hasTarget = false;
        a.dx = -a.dx;
        a.dy = -a.dy;
      }
      return;
    }
    a.prevX = a.x;
    a.prevY = a.y;
    a.x = nx;
    a.y = ny;
    _enterCell(a, nx, ny);
  }

  void _enterCell(Actor a, int x, int y) {
    final cell = idx(x, y);
    final owner = owners[cell];

    if (owner == a.id) {
      if (a.trail.isNotEmpty) captureTrail(a);
      return;
    }

    // Trail collision: someone (possibly a itself) has a trail on this cell.
    Actor? victim;
    for (final other in actors) {
      if (other.trailSet.contains(cell)) {
        victim = other;
        break;
      }
    }
    if (victim != null) {
      final v = victim;
      _kill(v, killer: a);
      if (identical(v, a) || !a.alive) return;
    }

    a.trail.add(cell);
    a.trailSet.add(cell);
  }

  /// Claims the actor's trail plus all cells enclosed by it. Public so it
  /// can be unit-tested directly.
  int captureTrail(Actor a) {
    if (a.trail.isEmpty) return 0;
    var before = 0;
    for (final o in owners) {
      if (o == a.id) before++;
    }
    for (final cell in a.trail) {
      owners[cell] = a.id;
    }
    a.trail.clear();
    a.trailSet.clear();

    // Flood fill from every border cell that is not the actor's; anything
    // unreached and not already the actor's is enclosed -> claim it.
    final visited = List<bool>.filled(totalCells, false);
    final stack = <int>[];
    void seed(int cell) {
      if (!visited[cell] && owners[cell] != a.id) {
        visited[cell] = true;
        stack.add(cell);
      }
    }

    for (var x = 0; x < cols; x++) {
      seed(idx(x, 0));
      seed(idx(x, rows - 1));
    }
    for (var y = 0; y < rows; y++) {
      seed(idx(0, y));
      seed(idx(cols - 1, y));
    }
    while (stack.isNotEmpty) {
      final cell = stack.removeLast();
      final cx = cell % cols;
      final cy = cell ~/ cols;
      const dirs = [(1, 0), (-1, 0), (0, 1), (0, -1)];
      for (final d in dirs) {
        final nx = cx + d.$1;
        final ny = cy + d.$2;
        if (!inBounds(nx, ny)) continue;
        final n = idx(nx, ny);
        if (!visited[n] && owners[n] != a.id) {
          visited[n] = true;
          stack.add(n);
        }
      }
    }
    for (var i = 0; i < totalCells; i++) {
      if (!visited[i] && owners[i] != a.id) {
        owners[i] = a.id;
      }
    }

    // Any enemy trail cells swallowed by the capture are removed.
    for (final other in actors) {
      if (identical(other, a) || other.trail.isEmpty) continue;
      other.trail.removeWhere((c) => owners[c] == a.id);
      other.trailSet.removeWhere((c) => owners[c] == a.id);
    }

    var after = 0;
    for (final o in owners) {
      if (o == a.id) after++;
    }
    final gained = after - before;
    if (a.isPlayer) {
      score += gained;
      if (gained > 0) playerCaptureCount++;
    }
    a.phase = 0;
    a.hasTarget = false;
    return gained;
  }

  void _kill(Actor victim, {required Actor killer}) {
    victim.trail.clear();
    victim.trailSet.clear();
    if (!identical(killer, victim)) {
      killer.kills++;
      if (killer.isPlayer) {
        score += 100;
        if (!victim.isPlayer) playerBotKills++;
      }
    }
    if (victim.isPlayer) {
      lives--;
      if (lives <= 0) {
        victim.alive = false;
        gameOver = true;
      } else {
        _respawn(victim);
      }
    } else {
      victim.alive = false;
      victim.respawnSteps = 28;
    }
  }

  void _respawn(Actor a) {
    final mine = <int>[];
    for (var i = 0; i < totalCells; i++) {
      if (owners[i] == a.id) mine.add(i);
    }
    if (mine.isEmpty) {
      _claimCircle(a, a.spawnX, a.spawnY, 4);
      a.x = a.spawnX;
      a.y = a.spawnY;
    } else {
      final cell = mine[_rng.nextInt(mine.length)];
      a.x = cell % cols;
      a.y = cell ~/ cols;
    }
    a.prevX = a.x;
    a.prevY = a.y;
    a.trail.clear();
    a.trailSet.clear();
    a.alive = true;
    a.phase = 0;
    a.hasTarget = false;
    a.dx = 0;
    a.dy = -1;
  }

  (int, int) _homeCentroid(Actor a) {
    var sx = 0, sy = 0, n = 0;
    for (var i = 0; i < totalCells; i++) {
      if (owners[i] == a.id) {
        sx += i % cols;
        sy += i ~/ cols;
        n++;
      }
    }
    if (n == 0) return (a.spawnX, a.spawnY);
    return (sx ~/ n, sy ~/ n);
  }

  void _steerBot(Actor bot) {
    final atHome = owners[idx(bot.x, bot.y)] == bot.id;
    if (atHome && bot.phase == 2) {
      bot.phase = 0;
      bot.hasTarget = false;
    }
    // Safety: very long trails are risky, head home.
    if (bot.trail.length > 90 && bot.phase != 2) {
      bot.phase = 2;
      bot.hasTarget = false;
    }
    if (!bot.hasTarget || (bot.x == bot.targetX && bot.y == bot.targetY)) {
      if (bot.hasTarget) bot.phase = (bot.phase + 1) % 3;
      final home = _homeCentroid(bot);
      switch (bot.phase) {
        case 0:
          final angle = _rng.nextDouble() * 2 * pi;
          final dist = 10 + _rng.nextInt(9);
          bot.targetX = (home.$1 + cos(angle) * dist).round().clamp(
            2,
            cols - 3,
          );
          bot.targetY = (home.$2 + sin(angle) * dist).round().clamp(
            2,
            rows - 3,
          );
          break;
        case 1:
          bot.targetX = (bot.x + _rng.nextInt(13) - 6).clamp(2, cols - 3);
          bot.targetY = (bot.y + _rng.nextInt(13) - 6).clamp(2, rows - 3);
          break;
        default:
          bot.targetX = home.$1;
          bot.targetY = home.$2;
      }
      bot.hasTarget = true;
    }

    const dirs = [(1, 0), (-1, 0), (0, 1), (0, -1)];
    var bestScore = double.infinity;
    var best = (bot.dx, bot.dy);
    for (final d in dirs) {
      final isReverse = d.$1 == -bot.dx && d.$2 == -bot.dy;
      if (isReverse && bot.isOutside) continue;
      final nx = bot.x + d.$1;
      final ny = bot.y + d.$2;
      if (!inBounds(nx, ny)) continue;
      var s = ((nx - bot.targetX).abs() + (ny - bot.targetY).abs()).toDouble();
      final cell = idx(nx, ny);
      if (bot.trailSet.contains(cell)) s += 1000;
      // Mostly avoid enemy trails, occasionally blunder (feels human).
      for (final other in actors) {
        if (!identical(other, bot) && other.trailSet.contains(cell)) {
          s += _rng.nextDouble() < 0.9 ? 60 : 0;
        }
      }
      s += _rng.nextDouble() * 0.5;
      if (s < bestScore) {
        bestScore = s;
        best = d;
      }
    }
    bot.dx = best.$1;
    bot.dy = best.$2;
  }
}
