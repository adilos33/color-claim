/// Player ranks for Color Claim (Stage C).
///
/// Pure Dart, no Flutter imports. Ranks come from LIFETIME earned
/// points — every point ever banked from matches and daily bonuses —
/// so spending points on skins never lowers a rank.
library;

/// One rank tier. A player holds the highest tier whose
/// [minLifetimePoints] threshold their lifetime earnings have reached.
class RankDef {
  final String name;
  final String icon;
  final int minLifetimePoints;

  const RankDef({
    required this.name,
    required this.icon,
    required this.minLifetimePoints,
  });
}

/// Rank ladder, lowest first.
const List<RankDef> kRanks = [
  RankDef(name: 'Bronze', icon: '🥉', minLifetimePoints: 0),
  RankDef(name: 'Silver', icon: '🥈', minLifetimePoints: 500),
  RankDef(name: 'Gold', icon: '🥇', minLifetimePoints: 1500),
  RankDef(name: 'Platinum', icon: '💠', minLifetimePoints: 3500),
  RankDef(name: 'Diamond', icon: '💎', minLifetimePoints: 7000),
];

/// Index into [kRanks] of the rank held at [lifetimePoints].
int rankIndexForLifetime(int lifetimePoints) {
  var index = 0;
  for (var i = 0; i < kRanks.length; i++) {
    if (lifetimePoints >= kRanks[i].minLifetimePoints) index = i;
  }
  return index;
}

/// The rank held at [lifetimePoints] lifetime earned points.
RankDef rankForLifetime(int lifetimePoints) =>
    kRanks[rankIndexForLifetime(lifetimePoints)];

/// The next rank above the one held, or null at the top of the ladder.
RankDef? nextRankForLifetime(int lifetimePoints) {
  final index = rankIndexForLifetime(lifetimePoints);
  return index + 1 < kRanks.length ? kRanks[index + 1] : null;
}

/// Points still needed to reach the next rank (0 at the top).
int pointsToNextRank(int lifetimePoints) {
  final next = nextRankForLifetime(lifetimePoints);
  return next == null ? 0 : next.minLifetimePoints - lifetimePoints;
}

/// Fraction of the way from the current rank to the next one, in
/// 0..1. The top rank is always full.
double rankProgressToNext(int lifetimePoints) {
  final current = rankForLifetime(lifetimePoints);
  final next = nextRankForLifetime(lifetimePoints);
  if (next == null) return 1.0;
  final span = next.minLifetimePoints - current.minLifetimePoints;
  if (span <= 0) return 1.0;
  final value =
      (lifetimePoints - current.minLifetimePoints) / span;
  if (value < 0) return 0;
  if (value > 1) return 1;
  return value;
}
