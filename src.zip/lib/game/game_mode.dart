/// Gameplay modes for Color Claim (Stage A).
///
/// Pure Dart, no Flutter imports. The modes layer different win/lose
/// framing over the same territory engine:
/// - Classic: reach the level goal % before running out of lives.
/// - Quick Match: a 3-minute race — finish with the highest % to win.
///   Reaching the goal while leading ends the match early as a win.
/// - Survival: one life and no goal — last as long as you can.
library;

import 'territory_engine.dart';

enum GameMode { classic, quickMatch, survival }

/// Duration of one Quick Match, in seconds.
const int kQuickMatchSeconds = 180;

extension GameModeInfo on GameMode {
  String get label => switch (this) {
    GameMode.classic => 'Classic',
    GameMode.quickMatch => 'Quick Match',
    GameMode.survival => 'Survival',
  };

  String get tagline => switch (this) {
    GameMode.classic => 'Reach the goal % to clear the level',
    GameMode.quickMatch => '3 minutes — finish #1 to win',
    GameMode.survival => 'One life — survive as long as you can',
  };

  String get description => switch (this) {
    GameMode.classic =>
      'Claim the goal percentage before you run out of lives.',
    GameMode.quickMatch =>
      'Three minutes on the clock. The highest percentage when time '
          'runs out wins — hit the goal while leading to end it early.',
    GameMode.survival =>
      'Only one life and no goal. Survive, grow your zone, and set '
          'your best time.',
  };
}

/// Where the player stands in a Quick Match right now.
class QuickStanding {
  /// 1-based position on the leaderboard (1 = leading).
  final int rank;
  final int totalActors;
  final double playerPercent;
  final String leaderName;
  final double leaderPercent;

  const QuickStanding({
    required this.rank,
    required this.totalActors,
    required this.playerPercent,
    required this.leaderName,
    required this.leaderPercent,
  });

  bool get isLeading => rank == 1;
}

/// Current Quick Match standing, derived from the engine leaderboard.
QuickStanding quickStanding(TerritoryEngine engine) {
  final board = engine.leaderboard;
  final playerIndex = board.indexWhere((a) => a.isPlayer);
  final leader = board.first;
  return QuickStanding(
    rank: playerIndex + 1,
    totalActors: board.length,
    playerPercent: engine.playerPercent,
    leaderName: leader.isPlayer ? 'You' : leader.name,
    leaderPercent: engine.percentFor(leader.id),
  );
}

/// Early Quick Match win: goal reached while leading the field.
bool quickGoalWhileLeading(TerritoryEngine engine) =>
    engine.playerPercent >= engine.level.goalPercent &&
    quickStanding(engine).isLeading;
