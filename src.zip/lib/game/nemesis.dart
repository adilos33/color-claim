/// The Nemesis rival: one persistent bot whose difficulty adapts to
/// the player's recent Daily Arena form.
///
/// Pure Dart, no Flutter imports. The Nemesis is the same bot every
/// day ([kNemesisName], ember skin, never rotates) built on the
/// engine's Hunter concept; only its aggression moves, through the
/// engine's existing difficulty knobs (speed + trail-risk budget).
/// All state lives in the local Daily Arena history — nothing is
/// collected, uploaded, or shared.
library;

import 'challenges.dart' show dateKeyFor;
import 'daily_arena.dart';
import 'territory_engine.dart' show kNemesisColorArgb, kNemesisName;

/// The Nemesis bot's display name — the same every day, by design.
String get nemesisName => kNemesisName;

/// The Nemesis bot's territory color (ember orange).
int get nemesisColorArgb => kNemesisColorArgb;

/// How hard the Nemesis plays today.
enum NemesisDifficulty { backedOff, normal, aggressive }

extension NemesisDifficultyInfo on NemesisDifficulty {
  /// Multiplier applied to the Nemesis bot's engine speed.
  double get speedMultiplier => switch (this) {
    NemesisDifficulty.backedOff => 0.90,
    NemesisDifficulty.normal => 1.0,
    NemesisDifficulty.aggressive => 1.18,
  };

  String get label => switch (this) {
    NemesisDifficulty.backedOff => 'Backed Off',
    NemesisDifficulty.normal => 'On the Hunt',
    NemesisDifficulty.aggressive => 'Relentless',
  };

  String get description => switch (this) {
    NemesisDifficulty.backedOff =>
      'Ember is easing off after your rough patch — a fairer fight while you rebuild.',
    NemesisDifficulty.normal =>
      'Ember hunts your trail like always. Beat the board and the streak starts to matter.',
    NemesisDifficulty.aggressive =>
      'Ember is relentless after your win streak — faster, and it holds its trail longer before banking.',
  };
}

/// Counts consecutive same-result days immediately before [today],
/// walking backwards one calendar day at a time. A skipped day
/// (no record) or an opposite result breaks the streak. Only records
/// strictly before [today] count, so today's not-yet-played board
/// never feeds its own difficulty.
int _streakBefore(
  Map<String, DailyArenaRecord> history,
  DateTime today,
  bool wantWin,
) {
  var streak = 0;
  var cursor = DateTime(today.year, today.month, today.day - 1);
  while (true) {
    final record = history[dateKeyFor(cursor)];
    if (record == null || record.won != wantWin) return streak;
    streak++;
    cursor = DateTime(cursor.year, cursor.month, cursor.day - 1);
  }
}

/// Consecutive Daily Arena wins immediately before [today].
int winStreakBefore(Map<String, DailyArenaRecord> history, DateTime today) =>
    _streakBefore(history, today, true);

/// Consecutive Daily Arena losses immediately before [today].
int lossStreakBefore(Map<String, DailyArenaRecord> history, DateTime today) =>
    _streakBefore(history, today, false);

/// Today's Nemesis difficulty from the player's recent form:
/// 3+ wins in a row → aggressive; 3+ losses in a row → backed off;
/// anything else → normal.
NemesisDifficulty nemesisDifficultyFor(
  Map<String, DailyArenaRecord> history,
  DateTime today,
) {
  if (winStreakBefore(history, today) >= 3) {
    return NemesisDifficulty.aggressive;
  }
  if (lossStreakBefore(history, today) >= 3) {
    return NemesisDifficulty.backedOff;
  }
  return NemesisDifficulty.normal;
}

/// Win rate over the 7 calendar days before [today] (0 when no
/// Daily Arena was played in that window). Shown on the Nemesis card.
double sevenDayWinRate(
  Map<String, DailyArenaRecord> history,
  DateTime today,
) {
  var played = 0;
  var won = 0;
  for (var back = 1; back <= 7; back++) {
    final day = DateTime(today.year, today.month, today.day - back);
    final record = history[dateKeyFor(day)];
    if (record == null) continue;
    played++;
    if (record.won) won++;
  }
  if (played == 0) return 0;
  return won / played;
}

/// All-time Daily Arena wins/losses from [history].
({int wins, int losses}) nemesisHeadToHead(
  Map<String, DailyArenaRecord> history,
) {
  var wins = 0;
  var losses = 0;
  for (final record in history.values) {
    if (record.won) {
      wins++;
    } else {
      losses++;
    }
  }
  return (wins: wins, losses: losses);
}
