/// Match points for Color Claim (Stage B).
///
/// Pure Dart, no Flutter imports. Points are the wallet currency spent
/// on skins. They are awarded once at the end of a match from the run's
/// final numbers, so quitting mid-match earns nothing.
library;

import 'dart:math' as math;

/// Points per percent of the board claimed when the match ends.
const int kPointsPerPercent = 2;

/// Points per bot knocked out (its trail cut by the player).
const int kPointsPerKnockout = 25;

/// Flat bonus for winning a Classic or Quick Match.
const int kWinBonusPoints = 50;

/// Breakdown of the points one finished match earned.
class MatchPoints {
  final int percentPoints;
  final int knockoutPoints;
  final int winBonus;

  const MatchPoints({
    required this.percentPoints,
    required this.knockoutPoints,
    required this.winBonus,
  });

  int get total => percentPoints + knockoutPoints + winBonus;
}

/// Points for a finished match. [percent] is the player's final (or
/// peak, in Survival) claimed percent; [victory] adds the win bonus.
MatchPoints matchPoints({
  required double percent,
  required int knockouts,
  required bool victory,
}) {
  final cleanPercent = percent.isFinite ? math.max(percent, 0.0) : 0.0;
  return MatchPoints(
    percentPoints: (cleanPercent * kPointsPerPercent).round(),
    knockoutPoints: math.max(knockouts, 0) * kPointsPerKnockout,
    winBonus: victory ? kWinBonusPoints : 0,
  );
}
