/// Power-ups for Color Claim (Stage B).
///
/// Pure Dart, no Flutter imports, so spawn rules and effect timing are
/// unit-testable. Pickups appear on unowned playable cells during play;
/// any actor (player or bots) collects one by moving onto its cell.
/// Effects are timed in engine steps (the app ticks at ~80 ms per step,
/// so about 12 steps are roughly one second).
library;

/// The three power-ups that can spawn on the field.
enum PowerUpKind { speed, shield, freeze }

/// Engine steps a speed boost stays active (~5 seconds).
const int kSpeedBoostSteps = 65;

/// Engine steps a freeze stays active (~4 seconds).
const int kFreezeSteps = 54;

/// Engine steps a picked-up shield stays ready (~17 seconds). A shield
/// is also consumed the first time it blocks a cut.
const int kShieldSteps = 217;

/// Engine steps of invulnerability after a shield break (~2 seconds).
const int kInvulnSteps = 22;

/// Steps between pickup spawn attempts (~10 seconds).
const int kPickupSpawnSteps = 130;

/// Maximum pickups on the field at the same time.
const int kMaxPickupsOnField = 2;

/// Speed multiplier while a speed boost is active (+40%).
const double kSpeedMultiplier = 1.4;

/// Speed multiplier applied to the slowed side during a freeze (50%).
const double kFreezeMultiplier = 0.5;

extension PowerUpKindInfo on PowerUpKind {
  String get label => switch (this) {
    PowerUpKind.speed => 'Speed',
    PowerUpKind.shield => 'Shield',
    PowerUpKind.freeze => 'Freeze',
  };

  /// Field icon. Drawn as a styled text chip by the board painter.
  String get emoji => switch (this) {
    PowerUpKind.speed => '⚡',
    PowerUpKind.shield => '🛡',
    PowerUpKind.freeze => '❄',
  };

  /// Accent color (ARGB) for chips, bursts and HUD.
  int get colorArgb => switch (this) {
    PowerUpKind.speed => 0xFFFFB020, // amber
    PowerUpKind.shield => 0xFF38BDF8, // sky
    PowerUpKind.freeze => 0xFF67E8F9, // ice
  };

  /// Engine steps the effect lasts once collected.
  int get durationSteps => switch (this) {
    PowerUpKind.speed => kSpeedBoostSteps,
    PowerUpKind.shield => kShieldSteps,
    PowerUpKind.freeze => kFreezeSteps,
  };

  /// Popup shown when the player collects this power-up.
  String get pickupMessage => switch (this) {
    PowerUpKind.speed => '⚡ Speed boost!',
    PowerUpKind.shield => '🛡 Shield up!',
    PowerUpKind.freeze => '❄ Bots frozen!',
  };
}

/// One power-up waiting on the field to be collected.
class PowerUpPickup {
  final PowerUpKind kind;
  final int x;
  final int y;

  const PowerUpPickup({required this.kind, required this.x, required this.y});
}
