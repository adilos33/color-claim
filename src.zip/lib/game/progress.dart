/// Pure-Dart saved-progress model for Color Claim.
///
/// This file deliberately has no Flutter or plugin imports.  It only knows
/// how progress is represented, validated, serialized, and advanced; the
/// SharedPreferences read/write lives in `services/progress_store.dart`.
class GameProgress {
  /// Highest level number the player may open. Level 1 is always available.
  int highestUnlockedLevel;

  /// Best claimed percentage for each completed/attempted level, keyed by
  /// level number. Values are percentages in the inclusive range 0..100.
  final Map<int, double> bestPercents;

  /// Whether every game sound is muted.
  bool muted;

  GameProgress({
    int highestUnlockedLevel = 1,
    Map<int, double>? bestPercents,
    this.muted = false,
  }) : highestUnlockedLevel = highestUnlockedLevel < 1
           ? 1
           : highestUnlockedLevel,
       bestPercents = _cleanBestPercents(bestPercents);

  /// The state used on a first run, before anything has been saved.
  factory GameProgress.defaults() => GameProgress();

  /// Restores progress from the map produced by [toJson].
  ///
  /// Malformed entries are ignored rather than making saved progress
  /// unusable after an app update.
  factory GameProgress.fromJson(Map<String, dynamic> json) {
    final rawBest = json['bestPercents'];
    final parsedBest = <int, double>{};
    if (rawBest is Map) {
      for (final entry in rawBest.entries) {
        final level = int.tryParse(entry.key.toString());
        final value = entry.value;
        if (level != null && level > 0 && value is num) {
          parsedBest[level] = value.toDouble().clamp(0, 100).toDouble();
        }
      }
    }

    final rawUnlocked = json['highestUnlockedLevel'];
    return GameProgress(
      highestUnlockedLevel: rawUnlocked is num ? rawUnlocked.toInt() : 1,
      bestPercents: parsedBest,
      muted: json['muted'] == true,
    );
  }

  static Map<int, double> _cleanBestPercents(Map<int, double>? source) {
    if (source == null) return <int, double>{};
    return <int, double>{
      for (final entry in source.entries)
        if (entry.key > 0 && entry.value.isFinite)
          entry.key: entry.value.clamp(0, 100).toDouble(),
    };
  }

  /// JSON-compatible representation. Best-percent keys are strings because
  /// JSON object keys cannot be integers.
  Map<String, dynamic> toJson() {
    final sortedLevels = bestPercents.keys.toList()..sort();
    return <String, dynamic>{
      'version': 1,
      'highestUnlockedLevel': highestUnlockedLevel,
      'bestPercents': <String, dynamic>{
        for (final level in sortedLevels) level.toString(): bestPercents[level],
      },
      'muted': muted,
    };
  }

  bool isLevelUnlocked(int levelId) =>
      levelId >= 1 && levelId <= highestUnlockedLevel;

  double bestForLevel(int levelId) => bestPercents[levelId] ?? 0;

  /// Records [percent] only when it improves the saved best for [levelId].
  /// Returns whether the stored value changed.
  bool recordBest(int levelId, double percent) {
    if (levelId < 1 || !percent.isFinite) return false;
    final cleanedPercent = percent.clamp(0, 100).toDouble();
    if (cleanedPercent <= bestForLevel(levelId)) return false;
    bestPercents[levelId] = cleanedPercent;
    return true;
  }

  /// Records a win and unlocks the following level, without ever moving
  /// the unlock boundary backwards when an earlier level is replayed.
  /// Returns whether either stored value changed.
  bool completeLevel(int levelId, double percent, {required int totalLevels}) {
    var changed = recordBest(levelId, percent);
    if (totalLevels > 0 &&
        levelId == highestUnlockedLevel &&
        levelId < totalLevels) {
      highestUnlockedLevel = levelId + 1;
      changed = true;
    }
    return changed;
  }

  void setMuted(bool value) {
    muted = value;
  }
}
