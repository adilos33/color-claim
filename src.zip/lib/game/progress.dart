/// Pure-Dart saved-progress model for Color Claim.
///
/// This file deliberately has no Flutter or plugin imports.  It only knows
/// how progress is represented, validated, serialized, and advanced; the
/// SharedPreferences read/write lives in `services/progress_store.dart`.
library;

import 'challenges.dart';
import 'skins.dart';

class GameProgress {
  /// Highest level number the player may open. Level 1 is always available.
  int highestUnlockedLevel;

  /// Best claimed percentage for each completed/attempted level, keyed by
  /// level number. Values are percentages in the inclusive range 0..100.
  final Map<int, double> bestPercents;

  /// Best Survival time in whole seconds for each level, keyed by level
  /// number. Absent until the player runs Survival on that level.
  final Map<int, int> bestSurvivalSeconds;

  /// Whether every game sound is muted.
  bool muted;

  /// Spendable points earned in matches (see points.dart for awards).
  int points;

  /// Every point ever banked, including ones already spent on skins.
  /// Ranks (see ranks.dart) are read from this, never from [points].
  int lifetimePoints;

  /// `YYYY-MM-DD` of the local day the daily state below belongs to.
  String? dailyDate;

  /// Progress toward today's daily challenge, in the challenge's own
  /// unit (whole percent, knockouts, seconds, or 1 for a win).
  double dailyProgress;

  /// Whether today's daily challenge was completed (bonus banked).
  bool dailyCompleted;

  /// Consecutive days, up to today, with a completed daily challenge.
  int streakDays;

  /// `YYYY-MM-DD` of the most recent daily-challenge completion.
  String? lastDailyCompletedDate;

  /// Ids of the skins the player owns. Always contains the default skin.
  final Set<String> unlockedSkinIds;

  /// Id of the equipped skin; always one of [unlockedSkinIds].
  String selectedSkinId;

  GameProgress({
    int highestUnlockedLevel = 1,
    Map<int, double>? bestPercents,
    Map<int, int>? bestSurvivalSeconds,
    this.muted = false,
    int points = 0,
    int lifetimePoints = 0,
    this.dailyDate,
    double dailyProgress = 0,
    this.dailyCompleted = false,
    int streakDays = 0,
    this.lastDailyCompletedDate,
    Set<String>? unlockedSkinIds,
    String? selectedSkinId,
  }) : highestUnlockedLevel = highestUnlockedLevel < 1
           ? 1
           : highestUnlockedLevel,
       bestPercents = _cleanBestPercents(bestPercents),
       bestSurvivalSeconds = _cleanSurvivalSeconds(bestSurvivalSeconds),
       points = points < 0 ? 0 : points,
       lifetimePoints = _cleanLifetime(lifetimePoints, points),
       dailyProgress = _cleanDailyProgress(dailyProgress),
       streakDays = streakDays < 0 ? 0 : streakDays,
       unlockedSkinIds = _cleanUnlockedSkins(unlockedSkinIds),
       selectedSkinId = _cleanSelectedSkin(selectedSkinId, unlockedSkinIds);

  /// The state used on a first run, before anything has been saved.
  factory GameProgress.defaults() => GameProgress();

  /// Restores progress from the map produced by [toJson].
  ///
  /// Malformed entries are ignored rather than making saved progress
  /// unusable after an app update.
  factory GameProgress.fromJson(Map<String, dynamic> json) {
    final rawBest = json['bestPercents'];
    final parsedBest = <int, double>{};
    if (rawBest is Map) {
      for (final entry in rawBest.entries) {
        final level = int.tryParse(entry.key.toString());
        final value = entry.value;
        if (level != null && level > 0 && value is num) {
          parsedBest[level] = value.toDouble().clamp(0, 100).toDouble();
        }
      }
    }

    // Older saves simply have no survival entries yet.
    final rawSurvival = json['bestSurvivalSeconds'];
    final parsedSurvival = <int, int>{};
    if (rawSurvival is Map) {
      for (final entry in rawSurvival.entries) {
        final level = int.tryParse(entry.key.toString());
        final value = entry.value;
        if (level != null && level > 0 && value is num) {
          parsedSurvival[level] = value.toInt();
        }
      }
    }

    // Older saves simply have no skin/points entries yet.
    final rawPoints = json['points'];
    final parsedPoints = rawPoints is num ? rawPoints.toInt() : 0;
    final rawSkins = json['unlockedSkinIds'];
    final parsedSkins = rawSkins is List
        ? <String>{for (final e in rawSkins) if (e is String) e}
        : null;
    final rawSelected = json['selectedSkinId'];

    // Saves from before Stage C have no lifetime/daily entries. The
    // wallet balance is the best surviving record of past earnings,
    // and every daily/streak field starts fresh.
    final rawLifetime = json['lifetimePoints'];
    final rawDailyDate = json['dailyDate'];
    final rawDailyProgress = json['dailyProgress'];
    final rawStreak = json['streakDays'];
    final rawLastDaily = json['lastDailyCompletedDate'];

    final rawUnlocked = json['highestUnlockedLevel'];
    return GameProgress(
      highestUnlockedLevel: rawUnlocked is num ? rawUnlocked.toInt() : 1,
      bestPercents: parsedBest,
      bestSurvivalSeconds: parsedSurvival,
      muted: json['muted'] == true,
      points: parsedPoints,
      lifetimePoints: rawLifetime is num
          ? rawLifetime.toInt()
          : parsedPoints,
      dailyDate: rawDailyDate is String && rawDailyDate.isNotEmpty
          ? rawDailyDate
          : null,
      dailyProgress: rawDailyProgress is num
          ? rawDailyProgress.toDouble()
          : 0,
      dailyCompleted: json['dailyCompleted'] == true,
      streakDays: rawStreak is num ? rawStreak.toInt() : 0,
      lastDailyCompletedDate:
          rawLastDaily is String && rawLastDaily.isNotEmpty
          ? rawLastDaily
          : null,
      unlockedSkinIds: parsedSkins,
      selectedSkinId: rawSelected is String ? rawSelected : null,
    );
  }

  static Map<int, double> _cleanBestPercents(Map<int, double>? source) {
    if (source == null) return <int, double>{};
    return <int, double>{
      for (final entry in source.entries)
        if (entry.key > 0 && entry.value.isFinite)
          entry.key: entry.value.clamp(0, 100).toDouble(),
    };
  }

  static Map<int, int> _cleanSurvivalSeconds(Map<int, int>? source) {
    if (source == null) return <int, int>{};
    return <int, int>{
      for (final entry in source.entries)
        if (entry.key > 0 && entry.value >= 0) entry.key: entry.value,
    };
  }

  /// Lifetime earnings can never be negative, and never below the
  /// spendable balance — a save cannot have spent more than it earned.
  static int _cleanLifetime(int lifetime, int points) {
    final cleanLifetime = lifetime < 0 ? 0 : lifetime;
    final cleanPoints = points < 0 ? 0 : points;
    return cleanLifetime < cleanPoints ? cleanPoints : cleanLifetime;
  }

  static double _cleanDailyProgress(double value) {
    if (!value.isFinite || value <= 0) return 0;
    return value > 10000 ? 10000 : value;
  }

  /// Day number (whole days since the Unix epoch, on the UTC calendar)
  /// for a `YYYY-MM-DD` key, or null when the key does not parse. UTC
  /// keeps day differences exact across local DST changes.
  static int? _dayNumberFromKey(String key) {
    final parts = key.split('-');
    if (parts.length != 3) return null;
    final year = int.tryParse(parts[0]);
    final month = int.tryParse(parts[1]);
    final day = int.tryParse(parts[2]);
    if (year == null || month == null || day == null) return null;
    return DateTime.utc(year, month, day).millisecondsSinceEpoch ~/
        Duration.millisecondsPerDay;
  }

  /// Keeps only known skin ids and always keeps the free default skin,
  /// so no save can ever end up owning nothing.
  static Set<String> _cleanUnlockedSkins(Set<String>? source) {
    final cleaned = <String>{kDefaultSkinId};
    if (source != null) {
      for (final id in source) {
        if (skinByIdOrNull(id) != null) cleaned.add(id);
      }
    }
    return cleaned;
  }

  /// The equipped skin must be a known, owned skin; anything else
  /// (unknown id, or a skin the save does not own) falls back to the
  /// default skin.
  static String _cleanSelectedSkin(String? selected, Set<String>? unlocked) {
    if (selected == null) return kDefaultSkinId;
    if (skinByIdOrNull(selected) == null) return kDefaultSkinId;
    if (selected == kDefaultSkinId) return selected;
    if (unlocked == null || !unlocked.contains(selected)) {
      return kDefaultSkinId;
    }
    return selected;
  }

  /// JSON-compatible representation. Best-percent keys are strings because
  /// JSON object keys cannot be integers.
  Map<String, dynamic> toJson() {
    final sortedLevels = bestPercents.keys.toList()..sort();
    final sortedSurvival = bestSurvivalSeconds.keys.toList()..sort();
    return <String, dynamic>{
      'version': 1,
      'highestUnlockedLevel': highestUnlockedLevel,
      'bestPercents': <String, dynamic>{
        for (final level in sortedLevels) level.toString(): bestPercents[level],
      },
      'bestSurvivalSeconds': <String, dynamic>{
        for (final level in sortedSurvival)
          level.toString(): bestSurvivalSeconds[level],
      },
      'muted': muted,
      'points': points,
      'lifetimePoints': lifetimePoints,
      'dailyDate': dailyDate,
      'dailyProgress': dailyProgress,
      'dailyCompleted': dailyCompleted,
      'streakDays': streakDays,
      'lastDailyCompletedDate': lastDailyCompletedDate,
      'unlockedSkinIds': unlockedSkinIds.toList()..sort(),
      'selectedSkinId': selectedSkinId,
    };
  }

  bool isLevelUnlocked(int levelId) =>
      levelId >= 1 && levelId <= highestUnlockedLevel;

  double bestForLevel(int levelId) => bestPercents[levelId] ?? 0;

  /// Best Survival time (whole seconds) recorded for [levelId], or 0.
  int bestSurvivalForLevel(int levelId) => bestSurvivalSeconds[levelId] ?? 0;

  /// Records a Survival time only when it beats the saved best for
  /// [levelId]. Returns whether the stored value changed.
  bool recordSurvival(int levelId, int seconds) {
    if (levelId < 1 || seconds < 0) return false;
    if (seconds <= bestSurvivalForLevel(levelId)) return false;
    bestSurvivalSeconds[levelId] = seconds;
    return true;
  }

  /// Records [percent] only when it improves the saved best for [levelId].
  /// Returns whether the stored value changed.
  bool recordBest(int levelId, double percent) {
    if (levelId < 1 || !percent.isFinite) return false;
    final cleanedPercent = percent.clamp(0, 100).toDouble();
    if (cleanedPercent <= bestForLevel(levelId)) return false;
    bestPercents[levelId] = cleanedPercent;
    return true;
  }

  /// Records a win and unlocks the following level, without ever moving
  /// the unlock boundary backwards when an earlier level is replayed.
  /// Returns whether either stored value changed.
  bool completeLevel(int levelId, double percent, {required int totalLevels}) {
    var changed = recordBest(levelId, percent);
    if (totalLevels > 0 &&
        levelId == highestUnlockedLevel &&
        levelId < totalLevels) {
      highestUnlockedLevel = levelId + 1;
      changed = true;
    }
    return changed;
  }

  void setMuted(bool value) {
    muted = value;
  }

  /// Adds earned points to the wallet and to the lifetime total that
  /// ranks are read from. Non-positive amounts are ignored.
  void addPoints(int amount) {
    if (amount <= 0) return;
    points += amount;
    lifetimePoints += amount;
  }

  bool isSkinUnlocked(String skinId) => unlockedSkinIds.contains(skinId);

  /// Buys [skinId] with points. Returns false (changing nothing) when the
  /// skin is unknown, already owned, or too expensive.
  bool unlockSkin(String skinId) {
    final skin = skinByIdOrNull(skinId);
    if (skin == null) return false;
    if (unlockedSkinIds.contains(skinId)) return false;
    if (points < skin.price) return false;
    points -= skin.price;
    unlockedSkinIds.add(skinId);
    return true;
  }

  /// Equips an owned skin. Returns whether the selection changed.
  bool selectSkin(String skinId) {
    if (!unlockedSkinIds.contains(skinId)) return false;
    if (selectedSkinId == skinId) return false;
    selectedSkinId = skinId;
    return true;
  }

  /// Moves the daily-challenge state onto [today]'s local calendar
  /// day: a new day starts with zeroed progress and an unclaimed bonus,
  /// and a streak whose last completion is older than yesterday is
  /// broken. Returns whether anything changed (so callers can save).
  bool syncToDay(DateTime today) {
    var changed = false;
    final todayKey = dateKeyFor(today);
    if (dailyDate != todayKey) {
      dailyDate = todayKey;
      dailyProgress = 0;
      dailyCompleted = false;
      changed = true;
    }
    final lastKey = lastDailyCompletedDate;
    if (streakDays > 0 && lastKey != null && lastKey != todayKey) {
      final lastDay = _dayNumberFromKey(lastKey);
      final todayDay =
          DateTime.utc(today.year, today.month, today.day)
                  .millisecondsSinceEpoch ~/
              Duration.millisecondsPerDay;
      if (lastDay == null || todayDay - lastDay > 1) {
        streakDays = 0;
        changed = true;
      }
    }
    return changed;
  }

  /// Counts one finished match toward today's daily challenge and
  /// returns the bonus to bank ([kDailyChallengeBonusPoints] on the
  /// match that completes it, 0 otherwise). Completing also advances
  /// the streak: yesterday's completion extends it, anything older
  /// restarts it at 1. The bonus itself is credited by the caller via
  /// [addPoints], so points and lifetime stay in step.
  int applyMatchToDaily(MatchStats match, DateTime today) {
    syncToDay(today);
    if (dailyCompleted) return 0;
    final challenge = challengeForDate(today);
    var next = dailyProgressAfter(
      challenge: challenge,
      currentProgress: dailyProgress,
      match: match,
    );
    if (next > challenge.goal) next = challenge.goal.toDouble();
    dailyProgress = next;
    if (next < challenge.goal) return 0;

    dailyCompleted = true;
    final todayKey = dateKeyFor(today);
    // Already counted today cannot normally happen (dailyCompleted
    // gates re-entry), but a repaired save must never double-count.
    if (lastDailyCompletedDate != todayKey) {
      final yesterdayKey = dateKeyFor(
        DateTime(today.year, today.month, today.day - 1),
      );
      streakDays = lastDailyCompletedDate == yesterdayKey
          ? streakDays + 1
          : 1;
      lastDailyCompletedDate = todayKey;
    }
    return kDailyChallengeBonusPoints;
  }
}
