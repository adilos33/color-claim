/// The Daily Arena: a fixed-seed board per calendar day, and the
/// per-day banked record for it.
///
/// Pure Dart, no Flutter imports. This is the upgrade of the existing
/// daily-challenge checklist (`challenges.dart`, which stays intact):
/// instead of only a goal checklist, the player gets a *place* they
/// play — one deterministic board for everyone each day, one banked
/// score per day, and a local history. Fully offline: the seed is
/// derived from the date alone, so the same day always builds the
/// same board on every device with no network access.
library;

import 'arena.dart';
import 'challenges.dart' show dateKeyFor;
import 'territory_engine.dart';

/// Fixed bot count for every Daily Arena board.
const int kDailyArenaBotCount = 5;

/// Goal percent for a Daily Arena run (a win banks a "win" mark).
const double kDailyArenaGoalPercent = 25;

/// `yyyymmdd` seed for the local calendar day of [date]. Only the
/// year/month/day fields are used, so time of day never changes it.
int dailyArenaSeed(DateTime date) =>
    date.year * 10000 + date.month * 100 + date.day;

/// The arena shape for [date]'s board: deterministic rotation over
/// the 5 shapes, driven by the day seed.
ArenaShape dailyArenaShape(DateTime date) =>
    ArenaShape.values[dailyArenaSeed(date) % ArenaShape.values.length];

/// The board configuration for [date]'s Daily Arena. The first bot
/// slot is the Nemesis (ember color); the remaining four rotate
/// through the regular bot roster. The engine is what actually
/// fields the Nemesis — callers must pass `forceNemesis: true` and
/// the day seed when constructing it.
LevelConfig dailyArenaLevel(DateTime date) {
  return LevelConfig(
    id: 0,
    name: 'Daily Arena',
    goalPercent: kDailyArenaGoalPercent,
    botCount: kDailyArenaBotCount,
    botSpeed: 0.90,
    neutralArgb: 0xFF241B4D,
    backgroundArgb: 0xFF141031,
    botColorsArgb: const [
      kNemesisColorArgb,
      0xFFFFD93D,
      0xFF3E9BFF,
      0xFFFF5D8F,
      0xFF2EE6A8,
    ],
    shape: dailyArenaShape(date),
  );
}

/// One banked Daily Arena result. Only the FIRST scored run of a day
/// creates a record; later replays only bump [attempts] and never
/// overwrite [score], [rank] or [won].
class DailyArenaRecord {
  /// `YYYY-MM-DD` key of the day this record belongs to.
  final String date;

  /// Final claimed percent of the banked run.
  final double score;

  /// 1-based leaderboard position of the banked run.
  final int rank;

  /// Total runs played that day, including replays after banking.
  final int attempts;

  /// Whether the banked run reached the arena goal.
  final bool won;

  const DailyArenaRecord({
    required this.date,
    required this.score,
    required this.rank,
    required this.attempts,
    required this.won,
  });

  DailyArenaRecord withAttempt() => DailyArenaRecord(
    date: date,
    score: score,
    rank: rank,
    attempts: attempts + 1,
    won: won,
  );

  factory DailyArenaRecord.fromJson(Map<String, dynamic> json) {
    final date = json['date'];
    final score = json['score'];
    final rank = json['rank'];
    final attempts = json['attempts'];
    if (date is! String ||
        date.isEmpty ||
        score is! num ||
        rank is! num ||
        attempts is! num) {
      throw const FormatException('Invalid DailyArenaRecord');
    }
    return DailyArenaRecord(
      date: date,
      score: score.toDouble().clamp(0, 100).toDouble(),
      rank: rank.toInt().clamp(1, 100),
      attempts: attempts.toInt().clamp(1, 100000),
      won: json['won'] == true,
    );
  }

  Map<String, dynamic> toJson() => <String, dynamic>{
    'date': date,
    'score': score,
    'rank': rank,
    'attempts': attempts,
    'won': won,
  };
}

/// Parses a saved history map (`YYYY-MM-DD` -> record JSON), skipping
/// malformed entries rather than breaking the whole save.
Map<String, DailyArenaRecord> parseDailyArenaHistory(Object? raw) {
  final parsed = <String, DailyArenaRecord>{};
  if (raw is! Map) return parsed;
  for (final entry in raw.entries) {
    final key = entry.key.toString();
    final value = entry.value;
    if (value is! Map) continue;
    try {
      final record = DailyArenaRecord.fromJson(
        value.map((k, v) => MapEntry(k.toString(), v)),
      );
      if (record.date == key) parsed[key] = record;
    } catch (_) {
      // A single bad day must never sink the history.
    }
  }
  return parsed;
}

/// `YYYY-MM-DD` key helper re-exported for callers that only import
/// this file.
String dailyArenaDateKey(DateTime date) => dateKeyFor(date);
