import 'dart:async';
import 'dart:convert';

import 'package:shared_preferences/shared_preferences.dart';

import '../game/challenges.dart';
import '../game/progress.dart';

/// Thin SharedPreferences wrapper around [GameProgress].
///
/// The model stays pure Dart and unit-testable; this class is the only
/// persistence boundary. Storage failures are contained so a preferences
/// problem can never prevent the game itself from opening.
class ProgressStore {
  static const String storageKey = 'color_claim_progress_v1';

  final SharedPreferences _preferences;

  /// Current in-memory state. Mutating methods update this object first,
  /// so screens reflect a win or mute change immediately while the disk
  /// write completes in the background.
  GameProgress progress;

  ProgressStore._(this._preferences, this.progress);

  /// Loads saved progress, or first-run defaults when no valid value is
  /// stored yet.
  static Future<ProgressStore> load() async {
    final preferences = await SharedPreferences.getInstance();
    var progress = GameProgress.defaults();

    try {
      final raw = preferences.getString(storageKey);
      if (raw != null && raw.isNotEmpty) {
        final decoded = jsonDecode(raw);
        if (decoded is Map<String, dynamic>) {
          progress = GameProgress.fromJson(decoded);
        } else if (decoded is Map) {
          progress = GameProgress.fromJson(
            decoded.map((key, value) => MapEntry(key.toString(), value)),
          );
        }
      }
    } catch (_) {
      // Corrupt/old saved data should not lock the player out of the game.
      progress = GameProgress.defaults();
    }

    return ProgressStore._(preferences, progress);
  }

  Future<void> save() async {
    try {
      await _preferences.setString(storageKey, jsonEncode(progress.toJson()));
    } catch (_) {
      // The in-memory state remains correct for this session.
    }
  }

  Future<void> recordWin({
    required int levelId,
    required double percent,
    required int totalLevels,
  }) async {
    progress.completeLevel(levelId, percent, totalLevels: totalLevels);
    await save();
  }

  Future<void> recordBest({
    required int levelId,
    required double percent,
  }) async {
    if (progress.recordBest(levelId, percent)) {
      await save();
    }
  }

  /// Records a finished Survival run: best time plus best percent for the
  /// level. Survival never unlocks the next level.
  Future<void> recordSurvival({
    required int levelId,
    required int seconds,
    required double percent,
  }) async {
    final timeChanged = progress.recordSurvival(levelId, seconds);
    final bestChanged = progress.recordBest(levelId, percent);
    if (timeChanged || bestChanged) {
      await save();
    }
  }

  Future<void> setMuted(bool value) async {
    progress.setMuted(value);
    await save();
  }

  /// Adds match-earned points to the wallet and persists them.
  Future<void> addPoints(int amount) async {
    if (amount <= 0) return;
    progress.addPoints(amount);
    await save();
  }

  /// Banks everything one finished match produced: its match points,
  /// then the daily-challenge update, whose completion bonus is also
  /// credited here. Returns the daily bonus granted (0 when the match
  /// did not complete today's challenge). The model updates
  /// synchronously, so end-of-match UI can read the new totals at
  /// once; the persist write runs in the background like other writes.
  int bankMatch({required int matchPoints, required MatchStats stats}) {
    if (matchPoints > 0) progress.addPoints(matchPoints);
    final bonus = progress.applyMatchToDaily(stats, DateTime.now());
    if (bonus > 0) progress.addPoints(bonus);
    unawaited(save());
    return bonus;
  }

  /// Rolls the daily challenge and streak onto today (also breaking a
  /// stale streak) and persists when anything changed.
  Future<void> syncDaily() async {
    if (progress.syncToDay(DateTime.now())) {
      await save();
    }
  }

  /// Buys a skin with points. Returns whether the purchase happened.
  Future<bool> unlockSkin(String skinId) async {
    if (!progress.unlockSkin(skinId)) return false;
    await save();
    return true;
  }

  /// Equips an owned skin. Returns whether the selection changed.
  Future<bool> selectSkin(String skinId) async {
    if (!progress.selectSkin(skinId)) return false;
    await save();
    return true;
  }
}
