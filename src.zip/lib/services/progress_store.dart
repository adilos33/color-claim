import 'dart:async';
import 'dart:convert';

import 'package:shared_preferences/shared_preferences.dart';

import '../game/challenges.dart';
import '../game/progress.dart';

/// Thin SharedPreferences wrapper around [GameProgress].
///
/// The model stays pure Dart and unit-testable; this class is the only
/// persistence boundary. Storage failures are contained so a preferences
/// problem can never prevent the game itself from opening.
class ProgressStore {
  static const String storageKey = 'color_claim_progress_v2';

  /// Previous store key. On first load after the 1.4.0 update, a
  /// v1 save migrates forward into v2 (all fields preserved, arena
  /// history starts empty) and the v1 entry is removed.
  static const String legacyStorageKey = 'color_claim_progress_v1';

  final SharedPreferences _preferences;

  /// Current in-memory state. Mutating methods update this object first,
  /// so screens reflect a win or mute change immediately while the disk
  /// write completes in the background.
  GameProgress progress;

  ProgressStore._(this._preferences, this.progress);

  static GameProgress? _decode(String raw) {
    try {
      final decoded = jsonDecode(raw);
      if (decoded is Map<String, dynamic>) {
        return GameProgress.fromJson(decoded);
      }
      if (decoded is Map) {
        return GameProgress.fromJson(
          decoded.map((key, value) => MapEntry(key.toString(), value)),
        );
      }
    } catch (_) {
      return null;
    }
    return null;
  }

  /// Loads saved progress, or first-run defaults when no valid value is
  /// stored yet. Prefers v2; falls back to a v1 save and migrates it.
  static Future<ProgressStore> load() async {
    final preferences = await SharedPreferences.getInstance();
    var progress = GameProgress.defaults();
    var migrated = false;

    final rawV2 = preferences.getString(storageKey);
    if (rawV2 != null && rawV2.isNotEmpty) {
      progress = _decode(rawV2) ?? GameProgress.defaults();
    } else {
      final rawV1 = preferences.getString(legacyStorageKey);
      if (rawV1 != null && rawV1.isNotEmpty) {
        final v1 = _decode(rawV1);
        if (v1 != null) {
          progress = v1;
          migrated = true;
        }
      }
    }

    final store = ProgressStore._(preferences, progress);
    if (migrated) {
      await store.save();
      await preferences.remove(legacyStorageKey);
    }
    return store;
  }

  Future<void> save() async {
    try {
      await _preferences.setString(storageKey, jsonEncode(progress.toJson()));
    } catch (_) {
      // The in-memory state remains correct for this session.
    }
  }

  Future<void> recordWin({
    required int levelId,
    required double percent,
    required int totalLevels,
  }) async {
    progress.completeLevel(levelId, percent, totalLevels: totalLevels);
    await save();
  }

  Future<void> recordBest({
    required int levelId,
    required double percent,
  }) async {
    if (progress.recordBest(levelId, percent)) {
      await save();
    }
  }

  /// Records a finished Survival run: best time plus best percent for the
  /// level. Survival never unlocks the next level.
  Future<void> recordSurvival({
    required int levelId,
    required int seconds,
    required double percent,
  }) async {
    final timeChanged = progress.recordSurvival(levelId, seconds);
    final bestChanged = progress.recordBest(levelId, percent);
    if (timeChanged || bestChanged) {
      await save();
    }
  }

  Future<void> setMuted(bool value) async {
    progress.setMuted(value);
    await save();
  }

  /// Adds match-earned points to the wallet and persists them.
  Future<void> addPoints(int amount) async {
    if (amount <= 0) return;
    progress.addPoints(amount);
    await save();
  }

  /// Banks everything one finished match produced: its match points,
  /// then the daily-challenge update, whose completion bonus is also
  /// credited here. Returns the daily bonus granted (0 when the match
  /// did not complete today's challenge). The model updates
  /// synchronously, so end-of-match UI can read the new totals at
  /// once; the persist write runs in the background like other writes.
  int bankMatch({required int matchPoints, required MatchStats stats}) {
    if (matchPoints > 0) progress.addPoints(matchPoints);
    final bonus = progress.applyMatchToDaily(stats, DateTime.now());
    if (bonus > 0) progress.addPoints(bonus);
    unawaited(save());
    return bonus;
  }

  /// Rolls the daily challenge and streak onto today (also breaking a
  /// stale streak) and persists when anything changed.
  Future<void> syncDaily() async {
    if (progress.syncToDay(DateTime.now())) {
      await save();
    }
  }

  /// Banks one finished Daily Arena run. Returns true only when this
  /// was the day's first scored run (replays bump attempts only).
  Future<bool> recordDailyArena({
    required DateTime date,
    required double score,
    required int rank,
    required bool won,
  }) async {
    final banked = progress.recordDailyArena(
      date: date,
      score: score,
      rank: rank,
      won: won,
    );
    await save();
    return banked;
  }

  /// Buys a skin with points. Returns whether the purchase happened.
  Future<bool> unlockSkin(String skinId) async {
    if (!progress.unlockSkin(skinId)) return false;
    await save();
    return true;
  }

  /// Equips an owned skin. Returns whether the selection changed.
  Future<bool> selectSkin(String skinId) async {
    if (!progress.selectSkin(skinId)) return false;
    await save();
    return true;
  }
}
