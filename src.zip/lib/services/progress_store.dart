import 'dart:convert';

import 'package:shared_preferences/shared_preferences.dart';

import '../game/progress.dart';

/// Thin SharedPreferences wrapper around [GameProgress].
///
/// The model stays pure Dart and unit-testable; this class is the only
/// persistence boundary. Storage failures are contained so a preferences
/// problem can never prevent the game itself from opening.
class ProgressStore {
  static const String storageKey = 'color_claim_progress_v1';

  final SharedPreferences _preferences;

  /// Current in-memory state. Mutating methods update this object first,
  /// so screens reflect a win or mute change immediately while the disk
  /// write completes in the background.
  GameProgress progress;

  ProgressStore._(this._preferences, this.progress);

  /// Loads saved progress, or first-run defaults when no valid value is
  /// stored yet.
  static Future<ProgressStore> load() async {
    final preferences = await SharedPreferences.getInstance();
    var progress = GameProgress.defaults();

    try {
      final raw = preferences.getString(storageKey);
      if (raw != null && raw.isNotEmpty) {
        final decoded = jsonDecode(raw);
        if (decoded is Map<String, dynamic>) {
          progress = GameProgress.fromJson(decoded);
        } else if (decoded is Map) {
          progress = GameProgress.fromJson(
            decoded.map((key, value) => MapEntry(key.toString(), value)),
          );
        }
      }
    } catch (_) {
      // Corrupt/old saved data should not lock the player out of the game.
      progress = GameProgress.defaults();
    }

    return ProgressStore._(preferences, progress);
  }

  Future<void> save() async {
    try {
      await _preferences.setString(storageKey, jsonEncode(progress.toJson()));
    } catch (_) {
      // The in-memory state remains correct for this session.
    }
  }

  Future<void> recordWin({
    required int levelId,
    required double percent,
    required int totalLevels,
  }) async {
    progress.completeLevel(levelId, percent, totalLevels: totalLevels);
    await save();
  }

  Future<void> recordBest({
    required int levelId,
    required double percent,
  }) async {
    if (progress.recordBest(levelId, percent)) {
      await save();
    }
  }

  Future<void> setMuted(bool value) async {
    progress.setMuted(value);
    await save();
  }
}
