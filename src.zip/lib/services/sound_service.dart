import 'dart:async';

import 'package:audioplayers/audioplayers.dart';

/// Every feedback sound generated locally for Color Claim.
enum GameSound { pop, capture, die, win, lose }

extension GameSoundDetails on GameSound {
  String get assetPath => switch (this) {
    GameSound.pop => 'sounds/pop.wav',
    GameSound.capture => 'sounds/capture.wav',
    GameSound.die => 'sounds/die.wav',
    GameSound.win => 'sounds/win.wav',
    GameSound.lose => 'sounds/lose.wav',
  };

  double get volume => switch (this) {
    GameSound.pop => 0.45,
    GameSound.capture => 0.60,
    GameSound.die => 0.52,
    GameSound.win => 0.65,
    GameSound.lose => 0.42,
  };
}

/// Small app-wide audio service backed by one [AudioPool] per sound.
///
/// Pools keep quick, occasionally overlapping effects clean. Every error
/// is contained here: audio is feedback only and must never break play,
/// especially in browsers or test hosts without working audio support.
class SoundService {
  SoundService._();

  static final SoundService instance = SoundService._();

  /// Set from saved progress at startup and whenever the in-game speaker
  /// toggle changes. While true, [play] is a no-op.
  bool muted = false;

  final Map<GameSound, AudioPool> _pools = {};
  final Map<GameSound, Future<AudioPool?>> _loadingPools = {};
  final Set<Future<void> Function()> _activeStops = {};

  Future<void> setMuted(bool value) async {
    muted = value;
    if (muted) await stopAll();
  }

  Future<void> stopAll() async {
    final stops = _activeStops.toList(growable: false);
    _activeStops.clear();
    for (final stop in stops) {
      try {
        await stop();
      } catch (_) {
        // A player may already have completed and released itself.
      }
    }
  }

  /// Fire-and-forget playback, normally called from a tap or game event.
  void play(GameSound sound) {
    if (muted) return;
    unawaited(_play(sound));
  }

  Future<void> _play(GameSound sound) async {
    try {
      final pool = await _poolFor(sound);
      if (pool == null || muted) return;
      final stop = await pool.start(volume: sound.volume);
      _activeStops.add(stop);
      unawaited(
        Future<void>.delayed(
          const Duration(seconds: 1),
          () => _activeStops.remove(stop),
        ),
      );
    } catch (_) {
      // Unsupported or interrupted audio simply stays silent.
    }
  }

  Future<AudioPool?> _poolFor(GameSound sound) {
    final existing = _pools[sound];
    if (existing != null) return Future<AudioPool?>.value(existing);
    return _loadingPools[sound] ??= _createPool(sound);
  }

  Future<AudioPool?> _createPool(GameSound sound) async {
    try {
      final pool = await AudioPool.createFromAsset(
        path: sound.assetPath,
        minPlayers: 1,
        maxPlayers: sound == GameSound.pop ? 4 : 2,
      );
      _pools[sound] = pool;
      return pool;
    } catch (_) {
      return null;
    } finally {
      _loadingPools.remove(sound);
    }
  }
}
