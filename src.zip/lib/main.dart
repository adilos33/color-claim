import 'dart:math';

import 'package:flutter/material.dart';

import 'game/territory_engine.dart';
import 'screens/game_screen.dart';
import 'services/progress_store.dart';
import 'services/sound_service.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  final progressStore = await ProgressStore.load();
  SoundService.instance.muted = progressStore.progress.muted;
  runApp(ColorClaimApp(progressStore: progressStore));
}

class ColorClaimApp extends StatelessWidget {
  final ProgressStore progressStore;

  const ColorClaimApp({super.key, required this.progressStore});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Color Claim',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: const Color(kPlayerColor)),
        useMaterial3: true,
      ),
      home: HomeScreen(progressStore: progressStore),
    );
  }
}

/// Bold saturated card gradients per level theme.
const Map<int, List<Color>> kLevelGradients = {
  1: [Color(0xFF22C55E), Color(0xFF15803D)], // Meadow green
  2: [Color(0xFFFF5D8F), Color(0xFFD63384)], // Candy pink
  3: [Color(0xFFFFB020), Color(0xFFF08A24)], // Desert orange
  4: [Color(0xFF38BDF8), Color(0xFF0369A1)], // Ocean blue
  5: [Color(0xFFFF7A18), Color(0xFFE11D48)], // Sunset orange-red
  6: [Color(0xFFA855F7), Color(0xFF4338CA)], // Galaxy purple
};

const _lockedGradient = [Color(0xFF4B5563), Color(0xFF1F2937)];

class HomeScreen extends StatelessWidget {
  final ProgressStore progressStore;

  const HomeScreen({super.key, required this.progressStore});

  void _openLevels(BuildContext context) {
    SoundService.instance.play(GameSound.pop);
    Navigator.of(context).push(
      MaterialPageRoute(
        builder: (_) => LevelSelectScreen(progressStore: progressStore),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final progress = progressStore.progress;
    var bestOverall = 0.0;
    for (final level in kLevels) {
      bestOverall = max(bestOverall, progress.bestForLevel(level.id));
    }
    return Scaffold(
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [Color(0xFF00BFA6), Color(0xFF00838F), Color(0xFF01579B)],
          ),
        ),
        child: Stack(
          children: [
            const Positioned.fill(child: _FloatingBlobs()),
            SafeArea(
              child: Center(
                child: SingleChildScrollView(
                  padding: const EdgeInsets.all(24),
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      const _BouncingMascot(),
                      const SizedBox(height: 18),
                      const Text(
                        'Color Claim',
                        style: TextStyle(
                          fontSize: 46,
                          fontWeight: FontWeight.w900,
                          color: Colors.white,
                          letterSpacing: 0.5,
                          shadows: [
                            Shadow(
                              color: Colors.black38,
                              blurRadius: 8,
                              offset: Offset(0, 3),
                            ),
                          ],
                        ),
                      ),
                      const SizedBox(height: 6),
                      const Text(
                        'Draw a loop. Claim the color. Beat the bots!',
                        textAlign: TextAlign.center,
                        style: TextStyle(
                          fontSize: 16,
                          color: Colors.white70,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                      if (bestOverall > 0) ...[
                        const SizedBox(height: 16),
                        Container(
                          padding: const EdgeInsets.symmetric(
                            horizontal: 14,
                            vertical: 6,
                          ),
                          decoration: BoxDecoration(
                            color: Colors.white.withValues(alpha: 0.22),
                            borderRadius: BorderRadius.circular(999),
                            border: Border.all(
                              color: Colors.white.withValues(alpha: 0.4),
                            ),
                          ),
                          child: Row(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              const Icon(
                                Icons.emoji_events,
                                color: Color(0xFFFFD93D),
                                size: 17,
                              ),
                              const SizedBox(width: 6),
                              Text(
                                'Best: ${bestOverall.toStringAsFixed(1)}%',
                                style: const TextStyle(
                                  color: Colors.white,
                                  fontWeight: FontWeight.w900,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                      const SizedBox(height: 34),
                      _GlossyPlayButton(onPressed: () => _openLevels(context)),
                      const SizedBox(height: 16),
                      SizedBox(
                        width: 260,
                        child: OutlinedButton.icon(
                          style: OutlinedButton.styleFrom(
                            foregroundColor: Colors.white,
                            side: BorderSide(
                              color: Colors.white.withValues(alpha: 0.65),
                              width: 1.6,
                            ),
                            padding: const EdgeInsets.symmetric(vertical: 14),
                            textStyle: const TextStyle(
                              fontSize: 17,
                              fontWeight: FontWeight.w800,
                            ),
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(999),
                            ),
                          ),
                          icon: const Icon(Icons.grid_view),
                          label: const Text('Levels'),
                          onPressed: () => _openLevels(context),
                        ),
                      ),
                      const SizedBox(height: 12),
                      SizedBox(
                        width: 260,
                        child: OutlinedButton.icon(
                          style: OutlinedButton.styleFrom(
                            foregroundColor: Colors.white,
                            side: BorderSide(
                              color: Colors.white.withValues(alpha: 0.65),
                              width: 1.6,
                            ),
                            padding: const EdgeInsets.symmetric(vertical: 14),
                            textStyle: const TextStyle(
                              fontSize: 17,
                              fontWeight: FontWeight.w800,
                            ),
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(999),
                            ),
                          ),
                          icon: const Icon(Icons.help_outline),
                          label: const Text('How to Play'),
                          onPressed: () {
                            SoundService.instance.play(GameSound.pop);
                            Navigator.of(context).push(
                              MaterialPageRoute(
                                builder: (_) => const HowToScreen(),
                              ),
                            );
                          },
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

/// Soft, slow-drifting background blobs for the home screen.
class _FloatingBlobs extends StatefulWidget {
  const _FloatingBlobs();

  @override
  State<_FloatingBlobs> createState() => _FloatingBlobsState();
}

class _FloatingBlobsState extends State<_FloatingBlobs>
    with SingleTickerProviderStateMixin {
  late final AnimationController _ctrl = AnimationController(
    vsync: this,
    duration: const Duration(seconds: 9),
  )..repeat();

  @override
  void dispose() {
    _ctrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: _ctrl,
      builder: (context, _) {
        return CustomPaint(
          painter: _FloatingBlobsPainter(_ctrl.value * 2 * pi),
          size: Size.infinite,
        );
      },
    );
  }
}

class _FloatingBlobsPainter extends CustomPainter {
  final double phase;

  _FloatingBlobsPainter(this.phase);

  @override
  void paint(Canvas canvas, Size size) {
    final w = size.width;
    final h = size.height;
    void blob(double fx, double fy, double r, Color color, double speed) {
      final cx = fx * w + sin(phase * speed) * 18;
      final cy = fy * h + cos(phase * speed * 0.8) * 22;
      canvas.drawCircle(Offset(cx, cy), r, Paint()..color = color);
    }

    blob(0.12, 0.14, 70, Colors.white.withValues(alpha: 0.10), 1.0);
    blob(0.88, 0.10, 52, const Color(0xFFFFD93D).withValues(alpha: 0.14), 0.7);
    blob(0.82, 0.78, 84, const Color(0xFFFF4757).withValues(alpha: 0.12), 0.9);
    blob(0.16, 0.86, 58, Colors.white.withValues(alpha: 0.08), 1.2);
    blob(0.55, 0.45, 34, const Color(0xFF2EE6A8).withValues(alpha: 0.10), 1.4);
    blob(0.35, 0.28, 26, Colors.white.withValues(alpha: 0.10), 0.6);
  }

  @override
  bool shouldRepaint(covariant _FloatingBlobsPainter oldDelegate) =>
      oldDelegate.phase != phase;
}

/// The paint-drop mascot gently bouncing with a squash on landing.
class _BouncingMascot extends StatefulWidget {
  const _BouncingMascot();

  @override
  State<_BouncingMascot> createState() => _BouncingMascotState();
}

class _BouncingMascotState extends State<_BouncingMascot>
    with SingleTickerProviderStateMixin {
  late final AnimationController _ctrl = AnimationController(
    vsync: this,
    duration: const Duration(milliseconds: 850),
  )..repeat(reverse: true);

  @override
  void dispose() {
    _ctrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: _ctrl,
      builder: (context, child) {
        final v = Curves.easeInOut.transform(_ctrl.value);
        final y = -12 * v;
        final squash = 1 - 0.08 * (1 - v);
        return Transform.translate(
          offset: Offset(0, y),
          child: Transform.scale(
            scaleX: 1 / squash,
            scaleY: squash,
            child: child,
          ),
        );
      },
      child: const _Mascot(),
    );
  }
}

/// Original paint-drop mascot (drawn, not an asset).
class _Mascot extends StatelessWidget {
  const _Mascot();

  @override
  Widget build(BuildContext context) {
    return CustomPaint(size: const Size(120, 120), painter: _MascotPainter());
  }
}

class _MascotPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final c = Offset(size.width / 2, size.height / 2 + 8);
    const color = Color(kPlayerColor);
    // Ground shadow.
    canvas.drawOval(
      Rect.fromCenter(
        center: c + const Offset(0, 44),
        width: 62,
        height: 16,
      ),
      Paint()..color = Colors.black.withValues(alpha: 0.18),
    );
    // Plump body: darker base + saturated top.
    canvas.drawCircle(
      c + const Offset(0, 5),
      39,
      Paint()..color = Color.lerp(color, Colors.black, 0.16)!,
    );
    canvas.drawCircle(c, 38, Paint()..color = color);
    // Droplet tip.
    canvas.drawCircle(c + const Offset(0, -42), 14, Paint()..color = color);
    // Glossy highlight.
    canvas.drawOval(
      Rect.fromCenter(
        center: c + const Offset(-14, -16),
        width: 26,
        height: 17,
      ),
      Paint()..color = Colors.white.withValues(alpha: 0.4),
    );
    const ink = Color(0xFF22333B);
    for (final side in [-1, 1]) {
      final eye = c + Offset(side * 13.0, -4);
      canvas.drawCircle(eye, 9.5, Paint()..color = Colors.white);
      canvas.drawCircle(eye, 4.8, Paint()..color = ink);
      canvas.drawCircle(
        eye + const Offset(-1.5, -1.5),
        1.6,
        Paint()..color = Colors.white,
      );
    }
    final smile = Path()
      ..moveTo(c.dx - 12, c.dy + 14)
      ..quadraticBezierTo(c.dx, c.dy + 25, c.dx + 12, c.dy + 14);
    canvas.drawPath(
      smile,
      Paint()
        ..color = ink
        ..style = PaintingStyle.stroke
        ..strokeWidth = 3.2
        ..strokeCap = StrokeCap.round,
    );
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}

/// Big glossy gradient PLAY button with a press-scale animation.
class _GlossyPlayButton extends StatefulWidget {
  final VoidCallback onPressed;

  const _GlossyPlayButton({required this.onPressed});

  @override
  State<_GlossyPlayButton> createState() => _GlossyPlayButtonState();
}

class _GlossyPlayButtonState extends State<_GlossyPlayButton> {
  bool _down = false;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTapDown: (_) => setState(() => _down = true),
      onTapUp: (_) => setState(() => _down = false),
      onTapCancel: () => setState(() => _down = false),
      onTap: widget.onPressed,
      child: AnimatedScale(
        scale: _down ? 0.93 : 1.0,
        duration: const Duration(milliseconds: 120),
        child: Container(
          width: 280,
          height: 66,
          decoration: BoxDecoration(
            gradient: const LinearGradient(
              begin: Alignment.topCenter,
              end: Alignment.bottomCenter,
              colors: [Color(0xFFFF7A59), Color(0xFFFF4757), Color(0xFFE11D48)],
            ),
            borderRadius: BorderRadius.circular(999),
            boxShadow: [
              BoxShadow(
                color: const Color(0xFFFF4757).withValues(alpha: 0.5),
                blurRadius: 18,
                offset: const Offset(0, 8),
              ),
            ],
          ),
          child: Stack(
            children: [
              // Shine band across the top half.
              Positioned.fill(
                child: ClipRRect(
                  borderRadius: BorderRadius.circular(999),
                  child: Align(
                    alignment: Alignment.topCenter,
                    child: Container(
                      height: 30,
                      decoration: BoxDecoration(
                        gradient: LinearGradient(
                          begin: Alignment.topCenter,
                          end: Alignment.bottomCenter,
                          colors: [
                            Colors.white.withValues(alpha: 0.45),
                            Colors.white.withValues(alpha: 0.0),
                          ],
                        ),
                      ),
                    ),
                  ),
                ),
              ),
              const Center(
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Icon(Icons.play_arrow, color: Colors.white, size: 30),
                    SizedBox(width: 6),
                    Text(
                      'PLAY',
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 25,
                        fontWeight: FontWeight.w900,
                        letterSpacing: 1.5,
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class LevelSelectScreen extends StatefulWidget {
  final ProgressStore progressStore;

  const LevelSelectScreen({super.key, required this.progressStore});

  @override
  State<LevelSelectScreen> createState() => _LevelSelectScreenState();
}

class _LevelSelectScreenState extends State<LevelSelectScreen> {
  Future<void> _openLevel(LevelConfig level) async {
    SoundService.instance.play(GameSound.pop);
    await Navigator.of(context).push(
      MaterialPageRoute(
        builder: (_) =>
            GameScreen(level: level, progressStore: widget.progressStore),
      ),
    );
    // A win may have changed the best percent or unlocked the next card.
    if (mounted) setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    final progress = widget.progressStore.progress;
    return Scaffold(
      appBar: AppBar(
        title: const Text(
          'Choose a Level',
          style: TextStyle(fontWeight: FontWeight.w900),
        ),
        backgroundColor: Colors.transparent,
        elevation: 0,
        foregroundColor: Colors.white,
      ),
      extendBodyBehindAppBar: true,
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [Color(0xFF062A3A), Color(0xFF0B3D24), Color(0xFF101828)],
          ),
        ),
        child: SafeArea(
          child: GridView.builder(
            padding: const EdgeInsets.fromLTRB(16, 8, 16, 16),
            gridDelegate: const SliverGridDelegateWithMaxCrossAxisExtent(
              maxCrossAxisExtent: 240,
              mainAxisSpacing: 14,
              crossAxisSpacing: 14,
              childAspectRatio: 1.05,
            ),
            itemCount: kLevels.length,
            itemBuilder: (context, i) {
              final level = kLevels[i];
              final unlocked = progress.isLevelUnlocked(level.id);
              final best = progress.bestForLevel(level.id);
              final colors = unlocked
                  ? kLevelGradients[level.id]!
                  : _lockedGradient;
              return InkWell(
                borderRadius: BorderRadius.circular(20),
                onTap: unlocked ? () => _openLevel(level) : null,
                child: Container(
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      begin: Alignment.topLeft,
                      end: Alignment.bottomRight,
                      colors: colors,
                    ),
                    borderRadius: BorderRadius.circular(20),
                    boxShadow: [
                      BoxShadow(
                        color: colors.last.withValues(alpha: 0.45),
                        blurRadius: 12,
                        offset: const Offset(0, 5),
                      ),
                    ],
                  ),
                  padding: const EdgeInsets.all(14),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        children: [
                          Expanded(
                            child: Text(
                              'Level ${level.id}',
                              style: const TextStyle(
                                fontSize: 21,
                                fontWeight: FontWeight.w900,
                                color: Colors.white,
                              ),
                            ),
                          ),
                          if (!unlocked)
                            const Icon(
                              Icons.lock,
                              color: Colors.white70,
                              size: 21,
                            ),
                        ],
                      ),
                      const SizedBox(height: 4),
                      Text(
                        level.name,
                        style: TextStyle(
                          fontSize: 16,
                          fontWeight: FontWeight.w700,
                          color: Colors.white.withValues(alpha: 0.85),
                        ),
                      ),
                      const Spacer(),
                      if (best > 0)
                        Container(
                          padding: const EdgeInsets.symmetric(
                            horizontal: 9,
                            vertical: 3,
                          ),
                          decoration: BoxDecoration(
                            color: Colors.white.withValues(alpha: 0.25),
                            borderRadius: BorderRadius.circular(999),
                          ),
                          child: Text(
                            'Best: ${best.toStringAsFixed(1)}%',
                            style: const TextStyle(
                              color: Colors.white,
                              fontWeight: FontWeight.w900,
                              fontSize: 12,
                            ),
                          ),
                        ),
                      if (best > 0) const SizedBox(height: 6),
                      Text(
                        'Goal: ${level.goalPercent.toStringAsFixed(0)}%',
                        style: const TextStyle(
                          fontWeight: FontWeight.w800,
                          color: Colors.white,
                        ),
                      ),
                      Text(
                        unlocked ? 'Bots: ${level.botCount}' : 'Locked',
                        style: TextStyle(
                          color: Colors.white.withValues(alpha: 0.8),
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                    ],
                  ),
                ),
              );
            },
          ),
        ),
      ),
    );
  }
}

class HowToScreen extends StatelessWidget {
  const HowToScreen({super.key});

  @override
  Widget build(BuildContext context) {
    const style = TextStyle(fontSize: 16, height: 1.45, color: Colors.white);
    return Scaffold(
      appBar: AppBar(
        title: const Text(
          'How to Play',
          style: TextStyle(fontWeight: FontWeight.w900),
        ),
        backgroundColor: Colors.transparent,
        elevation: 0,
        foregroundColor: Colors.white,
      ),
      extendBodyBehindAppBar: true,
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [Color(0xFF062A3A), Color(0xFF0B3D24)],
          ),
        ),
        child: SafeArea(
          child: ListView(
            padding: const EdgeInsets.all(20),
            children: const [
              Text(
                'Your color is the coral zone. You are the coral paint drop.',
                style: style,
              ),
              SizedBox(height: 12),
              Text(
                '1. Press and drag — your paint drop follows your finger.',
                style: style,
              ),
              SizedBox(height: 8),
              Text(
                '2. Leave your zone and you draw a bright trail behind you.',
                style: style,
              ),
              SizedBox(height: 8),
              Text(
                '3. Come back to your zone to close the loop — everything inside becomes your color!',
                style: style,
              ),
              SizedBox(height: 8),
              Text(
                '4. Careful: if a bot touches your trail while you are outside, you lose a life. You have 3 lives.',
                style: style,
              ),
              SizedBox(height: 8),
              Text(
                '5. Brave move: cross a bot\'s trail to knock that bot out and earn bonus points.',
                style: style,
              ),
              SizedBox(height: 8),
              Text(
                '6. Reach the goal % at the top before you run out of lives to finish the level.',
                style: style,
              ),
            ],
          ),
        ),
      ),
    );
  }
}
