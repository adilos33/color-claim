import 'dart:async';
import 'dart:math';

import 'package:flutter/material.dart';

import 'game/arena.dart';
import 'game/challenges.dart';
import 'game/daily_arena.dart';
import 'game/game_mode.dart';
import 'game/nemesis.dart';
import 'game/progress.dart';
import 'game/ranks.dart';
import 'game/skins.dart';
import 'game/territory_engine.dart';
import 'screens/daily_arena_screen.dart';
import 'screens/game_screen.dart';
import 'screens/nemesis_screen.dart';
import 'screens/skin_picker.dart';
import 'services/progress_store.dart';
import 'services/sound_service.dart';
import 'theme.dart';
import 'widgets/beveled_panel.dart';
import 'widgets/skin_painter.dart';
import 'widgets/sprite_bank.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  final progressStore = await ProgressStore.load();
  SoundService.instance.muted = progressStore.progress.muted;
  runApp(ColorClaimApp(progressStore: progressStore));
}

class ColorClaimApp extends StatelessWidget {
  final ProgressStore progressStore;

  const ColorClaimApp({super.key, required this.progressStore});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Color Claim',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: kEmber),
        useMaterial3: true,
      ),
      home: HomeScreen(progressStore: progressStore),
    );
  }
}

/// Bold saturated card gradients per level theme (in-game content —
/// deliberately kept while all menu/HUD chrome moves to indigo/ember).
const Map<int, List<Color>> kLevelGradients = {
  1: [Color(0xFF22C55E), Color(0xFF15803D)], // Meadow green
  2: [Color(0xFFFF5D8F), Color(0xFFD63384)], // Candy pink
  3: [Color(0xFFFFB020), Color(0xFFF08A24)], // Desert orange
  4: [Color(0xFF38BDF8), Color(0xFF0369A1)], // Ocean blue
  5: [Color(0xFFFF7A18), Color(0xFFE11D48)], // Sunset orange-red
  6: [Color(0xFFA855F7), Color(0xFF4338CA)], // Galaxy purple
};

const _lockedGradient = [Color(0xFF4B5563), Color(0xFF1F2937)];

class HomeScreen extends StatefulWidget {
  final ProgressStore progressStore;

  const HomeScreen({super.key, required this.progressStore});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  ProgressStore get progressStore => widget.progressStore;

  @override
  void initState() {
    super.initState();
    // Pre-rendered character sprites decode in the background; the
    // vector characters stand in until they land.
    unawaited(SpriteBank.instance.ensureLoaded());
    // Roll the daily challenge/streak onto today (breaking a stale
    // streak) before the first frame reads them.
    unawaited(progressStore.syncDaily());
  }

  Future<void> _openLevels(
    BuildContext context, {
    GameMode initialMode = GameMode.classic,
  }) async {
    SoundService.instance.play(GameSound.pop);
    await Navigator.of(context).push(
      MaterialPageRoute(
        builder: (_) => LevelSelectScreen(
          progressStore: progressStore,
          initialMode: initialMode,
        ),
      ),
    );
    // A match may have moved points, ranks, streak and daily progress.
    if (mounted) {
      await progressStore.syncDaily();
      if (mounted) setState(() {});
    }
  }

  Future<void> _openSkins(BuildContext context) async {
    SoundService.instance.play(GameSound.pop);
    await Navigator.of(context).push(
      MaterialPageRoute(
        builder: (_) => SkinPickerScreen(progressStore: progressStore),
      ),
    );
    // The equipped skin / wallet may have changed in the picker.
    if (mounted) setState(() {});
  }

  Future<void> _openDailyArena(BuildContext context) async {
    SoundService.instance.play(GameSound.pop);
    await Navigator.of(context).push(
      MaterialPageRoute(
        builder: (_) => DailyArenaLobbyScreen(progressStore: progressStore),
      ),
    );
    if (mounted) {
      await progressStore.syncDaily();
      if (mounted) setState(() {});
    }
  }

  Future<void> _playLevel(BuildContext context, LevelConfig level) async {
    SoundService.instance.play(GameSound.pop);
    await Navigator.of(context).push(
      MaterialPageRoute(
        builder: (_) => GameScreen(
          level: level,
          progressStore: progressStore,
          mode: GameMode.classic,
        ),
      ),
    );
    if (mounted) {
      await progressStore.syncDaily();
      if (mounted) setState(() {});
    }
  }

  /// Current rank chip with the climb still ahead to the next rank.
  Widget _rankPanel(GameProgress progress) {
    final rank = rankForLifetime(progress.lifetimePoints);
    final next = nextRankForLifetime(progress.lifetimePoints);
    return SizedBox(
      width: 320,
      child: BeveledPanel(
        child: Column(
          children: [
            Row(
              children: [
                Expanded(
                  child: Text(
                    '${rank.icon} ${rank.name}',
                    style: displayHeading(size: 16),
                  ),
                ),
                Text(
                  next == null
                      ? 'Top rank!'
                      : '${pointsToNextRank(progress.lifetimePoints)}⭐ to ${next.name}',
                  style: TextStyle(
                    color: Colors.white.withValues(alpha: 0.85),
                    fontWeight: FontWeight.w700,
                    fontSize: 12.5,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 8),
            ClipRRect(
              borderRadius: BorderRadius.circular(999),
              child: LinearProgressIndicator(
                value: rankProgressToNext(progress.lifetimePoints),
                minHeight: 8,
                backgroundColor: Colors.white.withValues(alpha: 0.25),
                valueColor: const AlwaysStoppedAnimation<Color>(kStarGold),
              ),
            ),
          ],
        ),
      ),
    );
  }

  static String _fmtDuration(int totalSeconds) {
    final m = totalSeconds ~/ 60;
    final s = (totalSeconds % 60).toString().padLeft(2, '0');
    return '$m:$s';
  }

  static String _dailyProgressText(
    DailyChallenge challenge,
    double progress,
  ) {
    switch (challenge.kind) {
      case DailyChallengeKind.capturePercentOnce:
        return '${progress.floor()}% of ${challenge.goal}%';
      case DailyChallengeKind.survivalSecondsOnce:
        return '${_fmtDuration(progress.floor())} of '
            '${_fmtDuration(challenge.goal)}';
      case DailyChallengeKind.knockoutsToday:
      case DailyChallengeKind.quickVictory:
      case DailyChallengeKind.classicVictory:
        return '${progress.floor()} of ${challenge.goal}';
    }
  }

  /// Compact daily-challenge strip (the checklist lives in full in
  /// the Daily Arena lobby; this strip keeps today's goal visible).
  Widget _dailyStrip(GameProgress progress) {
    final challenge = challengeForDate(DateTime.now());
    final done = progress.dailyCompleted;
    final shown = progress.dailyProgress > challenge.goal
        ? challenge.goal.toDouble()
        : progress.dailyProgress;
    return SizedBox(
      width: 320,
      child: BeveledPanel(
        gradient: done
            ? const LinearGradient(
                colors: [Color(0xFF22C55E), Color(0xFF15803D)],
              )
            : kEmberGradient,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Expanded(
                  child: Text(
                    '🎯 Daily Challenge',
                    style: displayHeading(size: 14),
                  ),
                ),
                Text(
                  done
                      ? '⭐ +$kDailyChallengeBonusPoints banked'
                      : '⭐ +$kDailyChallengeBonusPoints',
                  style: displayNumber(size: 12),
                ),
              ],
            ),
            const SizedBox(height: 4),
            Text(
              done ? '✅ Done — come back tomorrow!' : challenge.title,
              style: const TextStyle(
                color: Colors.white,
                fontWeight: FontWeight.w700,
                fontSize: 13.5,
              ),
            ),
            if (!done) ...[
              const SizedBox(height: 4),
              Text(
                _dailyProgressText(challenge, shown),
                style: TextStyle(
                  color: Colors.white.withValues(alpha: 0.9),
                  fontWeight: FontWeight.w700,
                  fontSize: 12.5,
                ),
              ),
            ],
          ],
        ),
      ),
    );
  }

  /// One node on the claim map: a beveled panel with skin-gradient
  /// art, a title, and a status line. Nodes alternate sides down a
  /// winding path instead of stacking as a list of cards.
  Widget _mapNode({
    required String title,
    required String subtitle,
    required String status,
    required Gradient gradient,
    required VoidCallback? onTap,
    required bool leftSide,
  }) {
    final node = SizedBox(
      width: 300,
      child: GestureDetector(
        onTap: onTap,
        child: BeveledPanel(
          gradient: gradient,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(title, style: displayHeading(size: 18)),
              const SizedBox(height: 2),
              Text(
                subtitle,
                style: TextStyle(
                  color: Colors.white.withValues(alpha: 0.88),
                  fontWeight: FontWeight.w700,
                  fontSize: 13.5,
                ),
              ),
              const SizedBox(height: 4),
              Text(
                status,
                style: displayNumber(size: 12.5, color: kStarGold),
              ),
            ],
          ),
        ),
      ),
    );
    return Align(
      alignment: leftSide ? Alignment.centerLeft : Alignment.centerRight,
      child: node,
    );
  }

  Widget _pathDot() => const Padding(
    padding: EdgeInsets.symmetric(vertical: 2),
    child: Center(
      child: SizedBox(
        width: 8,
        height: 8,
        child: DecoratedBox(
          decoration: BoxDecoration(
            color: kEmberLight,
            shape: BoxShape.circle,
          ),
        ),
      ),
    ),
  );

  /// The claim map: Daily Arena first, then the 6 Classic levels in
  /// order, then the Quick Match and Survival modes — as nodes on a
  /// winding board path, each showing its own gradient art.
  Widget _claimMap(GameProgress progress) {
    final today = DateTime.now();
    final arenaRecord = progress.arenaRecordFor(today);
    final arenaShape = dailyArenaShape(today);
    final difficulty =
        nemesisDifficultyFor(progress.dailyArenaHistory, today);
    final nodes = <Widget>[];
    nodes.add(
      _mapNode(
        title: '🏟 DAILY ARENA',
        subtitle:
            '${arenaShape.label} · 5 bots · Nemesis $nemesisName (${difficulty.label})',
        status: arenaRecord == null
            ? 'NOT PLAYED YET — TAP TO PLAY'
            : arenaRecord.won
            ? '🏆 BANKED ${arenaRecord.score.toStringAsFixed(1)}% · #${arenaRecord.rank}'
            : 'BANKED ${arenaRecord.score.toStringAsFixed(1)}% · #${arenaRecord.rank}',
        gradient: kEmberGradient,
        onTap: () => _openDailyArena(context),
        leftSide: true,
      ),
    );
    var leftSide = false;
    for (final level in kLevels) {
      final unlocked = progress.isLevelUnlocked(level.id);
      final best = progress.bestForLevel(level.id);
      final colors = unlocked
          ? kLevelGradients[level.id]!
          : _lockedGradient;
      nodes.add(_pathDot());
      nodes.add(
        _mapNode(
          title: 'LEVEL ${level.id} · ${level.name.toUpperCase()}',
          subtitle:
              '${level.shape.label} · Goal ${level.goalPercent.toStringAsFixed(0)}% · ${level.botCount} bots',
          status: unlocked
              ? (best > 0
                    ? 'BEST ${best.toStringAsFixed(1)}%'
                    : 'TAP TO PLAY')
              : '🔒 LOCKED — CLEAR LEVEL ${level.id - 1} FIRST',
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: colors,
          ),
          onTap: unlocked ? () => _playLevel(context, level) : null,
          leftSide: leftSide,
        ),
      );
      leftSide = !leftSide;
    }
    for (final mode in [GameMode.quickMatch, GameMode.survival]) {
      nodes.add(_pathDot());
      nodes.add(
        _mapNode(
          title: mode.label.toUpperCase(),
          subtitle: mode.tagline,
          gradient: const LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [Color(0xFF3B2F7A), Color(0xFF241B4D)],
          ),
          status: 'CHOOSE A LEVEL →',
          onTap: () => _openLevels(context, initialMode: mode),
          leftSide: leftSide,
        ),
      );
      leftSide = !leftSide;
    }
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: nodes,
    );
  }

  @override
  Widget build(BuildContext context) {
    final progress = progressStore.progress;
    var bestOverall = 0.0;
    for (final level in kLevels) {
      bestOverall = max(bestOverall, progress.bestForLevel(level.id));
    }
    final skin = skinById(progress.selectedSkinId);
    return Scaffold(
      body: Container(
        decoration: const BoxDecoration(gradient: kNightGradient),
        child: Stack(
          children: [
            const Positioned.fill(child: _FloatingBlobs()),
            SafeArea(
              child: Center(
                child: SingleChildScrollView(
                  padding: const EdgeInsets.all(24),
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      _BouncingMascot(skin: skin),
                      const SizedBox(height: 18),
                      Text(
                        'Color Claim',
                        style: displayHeading(
                          size: 44,
                          letterSpacing: 0.5,
                        ),
                      ),
                      const SizedBox(height: 6),
                      const Text(
                        'Draw a loop. Claim the color. Beat the bots!',
                        textAlign: TextAlign.center,
                        style: TextStyle(
                          fontSize: 16,
                          color: Colors.white70,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                      const SizedBox(height: 16),
                      Wrap(
                        spacing: 8,
                        runSpacing: 8,
                        alignment: WrapAlignment.center,
                        children: [
                          if (bestOverall > 0)
                            Container(
                              padding: const EdgeInsets.symmetric(
                                horizontal: 14,
                                vertical: 6,
                              ),
                              decoration: BoxDecoration(
                                color: Colors.white.withValues(alpha: 0.22),
                                borderRadius: BorderRadius.circular(999),
                                border: Border.all(
                                  color: Colors.white.withValues(alpha: 0.4),
                                ),
                              ),
                              child: Row(
                                mainAxisSize: MainAxisSize.min,
                                children: [
                                  const Icon(
                                    Icons.emoji_events,
                                    color: kStarGold,
                                    size: 17,
                                  ),
                                  const SizedBox(width: 6),
                                  Text(
                                    'Best: ${bestOverall.toStringAsFixed(1)}%',
                                    style: displayNumber(size: 13),
                                  ),
                                ],
                              ),
                            ),
                          Container(
                            padding: const EdgeInsets.symmetric(
                              horizontal: 14,
                              vertical: 6,
                            ),
                            decoration: BoxDecoration(
                              color: Colors.white.withValues(alpha: 0.22),
                              borderRadius: BorderRadius.circular(999),
                              border: Border.all(
                                color: Colors.white.withValues(alpha: 0.4),
                              ),
                            ),
                            child: Text(
                              '⭐ ${progress.points} points',
                              style: displayNumber(size: 13),
                            ),
                          ),
                          if (progress.streakDays > 0)
                            Container(
                              padding: const EdgeInsets.symmetric(
                                horizontal: 14,
                                vertical: 6,
                              ),
                              decoration: BoxDecoration(
                                color: kEmber.withValues(alpha: 0.35),
                                borderRadius: BorderRadius.circular(999),
                                border: Border.all(
                                  color: Colors.white.withValues(alpha: 0.4),
                                ),
                              ),
                              child: Text(
                                '🔥 ${progress.streakDays} day streak',
                                style: displayNumber(size: 13),
                              ),
                            ),
                        ],
                      ),
                      const SizedBox(height: 14),
                      _rankPanel(progress),
                      const SizedBox(height: 12),
                      _dailyStrip(progress),
                      const SizedBox(height: 28),
                      Text(
                        'CLAIM MAP',
                        style: displayHeading(size: 20, color: kEmberLight),
                      ),
                      const SizedBox(height: 4),
                      const Text(
                        'Follow the path — arena, levels, modes.',
                        style: TextStyle(
                          color: Colors.white70,
                          fontWeight: FontWeight.w600,
                          fontSize: 13.5,
                        ),
                      ),
                      const SizedBox(height: 16),
                      SizedBox(width: 340, child: _claimMap(progress)),
                      const SizedBox(height: 28),
                      Wrap(
                        spacing: 10,
                        runSpacing: 10,
                        alignment: WrapAlignment.center,
                        children: [
                          BeveledButton(
                            label: 'Skins',
                            icon: Icons.palette,
                            onPressed: () => _openSkins(context),
                          ),
                          BeveledButton(
                            label: 'How to Play',
                            icon: Icons.help_outline,
                            onPressed: () {
                              SoundService.instance.play(GameSound.pop);
                              Navigator.of(context).push(
                                MaterialPageRoute(
                                  builder: (_) => const HowToScreen(),
                                ),
                              );
                            },
                          ),
                          BeveledButton(
                            label: 'Arena History',
                            icon: Icons.calendar_month,
                            onPressed: () {
                              SoundService.instance.play(GameSound.pop);
                              Navigator.of(context).push(
                                MaterialPageRoute(
                                  builder: (_) =>
                                      DailyArenaHistoryScreen(
                                        progressStore: progressStore,
                                      ),
                                ),
                              );
                            },
                          ),
                          BeveledButton(
                            label: 'Nemesis Card',
                            icon: Icons.person,
                            onPressed: () {
                              SoundService.instance.play(GameSound.pop);
                              Navigator.of(context).push(
                                MaterialPageRoute(
                                  builder: (_) => NemesisCardScreen(
                                    progressStore: progressStore,
                                  ),
                                ),
                              );
                            },
                          ),
                        ],
                      ),
                      const SizedBox(height: 12),
                    ],
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

/// Soft, slow-drifting background blobs for the home screen (indigo
/// night sky with ember and gold glints — no teal).
class _FloatingBlobs extends StatefulWidget {
  const _FloatingBlobs();

  @override
  State<_FloatingBlobs> createState() => _FloatingBlobsState();
}

class _FloatingBlobsState extends State<_FloatingBlobs>
    with SingleTickerProviderStateMixin {
  late final AnimationController _ctrl = AnimationController(
    vsync: this,
    duration: const Duration(seconds: 9),
  )..repeat();

  @override
  void dispose() {
    _ctrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: _ctrl,
      builder: (context, _) {
        return CustomPaint(
          painter: _FloatingBlobsPainter(_ctrl.value * 2 * pi),
          size: Size.infinite,
        );
      },
    );
  }
}

class _FloatingBlobsPainter extends CustomPainter {
  final double phase;

  _FloatingBlobsPainter(this.phase);

  @override
  void paint(Canvas canvas, Size size) {
    final w = size.width;
    final h = size.height;
    void blob(double fx, double fy, double r, Color color, double speed) {
      final cx = fx * w + sin(phase * speed) * 18;
      final cy = fy * h + cos(phase * speed * 0.8) * 22;
      canvas.drawCircle(Offset(cx, cy), r, Paint()..color = color);
    }

    blob(0.12, 0.14, 70, Colors.white.withValues(alpha: 0.10), 1.0);
    blob(0.88, 0.10, 52, kStarGold.withValues(alpha: 0.14), 0.7);
    blob(0.82, 0.78, 84, kEmber.withValues(alpha: 0.12), 0.9);
    blob(0.16, 0.86, 58, Colors.white.withValues(alpha: 0.08), 1.2);
    blob(0.55, 0.45, 34, const Color(0xFF8B7CFF).withValues(alpha: 0.12), 1.4);
    blob(0.35, 0.28, 26, Colors.white.withValues(alpha: 0.10), 0.6);
  }

  @override
  bool shouldRepaint(covariant _FloatingBlobsPainter oldDelegate) =>
      oldDelegate.phase != phase;
}

/// The equipped skin character gently bouncing with a squash on landing.
class _BouncingMascot extends StatefulWidget {
  final SkinDef skin;

  const _BouncingMascot({required this.skin});

  @override
  State<_BouncingMascot> createState() => _BouncingMascotState();
}

class _BouncingMascotState extends State<_BouncingMascot>
    with SingleTickerProviderStateMixin {
  late final AnimationController _ctrl = AnimationController(
    vsync: this,
    duration: const Duration(milliseconds: 850),
  )..repeat(reverse: true);

  @override
  void dispose() {
    _ctrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: _ctrl,
      builder: (context, child) {
        final v = Curves.easeInOut.transform(_ctrl.value);
        final y = -12 * v;
        final squash = 1 - 0.08 * (1 - v);
        return Transform.translate(
          offset: Offset(0, y),
          child: Transform.scale(
            scaleX: 1 / squash,
            scaleY: squash,
            child: child,
          ),
        );
      },
      child: CustomPaint(
        size: const Size(120, 120),
        painter: SkinPainter(widget.skin, image: SpriteBank.instance.owlNeutral),
      ),
    );
  }
}

class LevelSelectScreen extends StatefulWidget {
  final ProgressStore progressStore;
  final GameMode initialMode;

  const LevelSelectScreen({
    super.key,
    required this.progressStore,
    this.initialMode = GameMode.classic,
  });

  @override
  State<LevelSelectScreen> createState() => _LevelSelectScreenState();
}

class _LevelSelectScreenState extends State<LevelSelectScreen> {
  late GameMode _mode = widget.initialMode;

  Future<void> _openLevel(LevelConfig level) async {
    SoundService.instance.play(GameSound.pop);
    await Navigator.of(context).push(
      MaterialPageRoute(
        builder: (_) => GameScreen(
          level: level,
          progressStore: widget.progressStore,
          mode: _mode,
        ),
      ),
    );
    // A win may have changed the best percent or unlocked the next card.
    if (mounted) setState(() {});
  }

  static String _fmtSeconds(int total) {
    final m = total ~/ 60;
    final s = (total % 60).toString().padLeft(2, '0');
    return '$m:$s';
  }

  Widget _modeSelector() {
    return Row(
      children: [
        for (final mode in GameMode.values) ...[
          Expanded(
            child: GestureDetector(
              onTap: () {
                SoundService.instance.play(GameSound.pop);
                setState(() => _mode = mode);
              },
              child: ClipPath(
                clipper: const BeveledClipper(cut: 8),
                child: Container(
                  padding: const EdgeInsets.symmetric(vertical: 10),
                  decoration: BoxDecoration(
                    gradient: _mode == mode
                        ? kEmberGradient
                        : null,
                    color: _mode == mode
                        ? null
                        : Colors.white.withValues(alpha: 0.10),
                    border: Border.all(
                      color: Colors.white.withValues(alpha: 0.25),
                    ),
                  ),
                  child: Text(
                    mode.label,
                    textAlign: TextAlign.center,
                    style: displayHeading(size: 13),
                  ),
                ),
              ),
            ),
          ),
          if (mode != GameMode.values.last) const SizedBox(width: 8),
        ],
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    final progress = widget.progressStore.progress;
    return Scaffold(
      appBar: AppBar(
        title: Text('Choose a Level', style: displayHeading(size: 20)),
        backgroundColor: Colors.transparent,
        elevation: 0,
        foregroundColor: Colors.white,
      ),
      extendBodyBehindAppBar: true,
      body: Container(
        decoration: const BoxDecoration(gradient: kNightGradient),
        child: SafeArea(
          child: Column(
            children: [
              Padding(
                padding: const EdgeInsets.fromLTRB(16, 4, 16, 0),
                child: _modeSelector(),
              ),
              Padding(
                padding: const EdgeInsets.fromLTRB(16, 8, 16, 4),
                child: Text(
                  _mode.tagline,
                  style: TextStyle(
                    color: Colors.white.withValues(alpha: 0.85),
                    fontWeight: FontWeight.w700,
                    fontSize: 13.5,
                  ),
                ),
              ),
              Expanded(
                child: GridView.builder(
                  padding: const EdgeInsets.fromLTRB(16, 8, 16, 16),
                  gridDelegate: const SliverGridDelegateWithMaxCrossAxisExtent(
                    maxCrossAxisExtent: 240,
                    mainAxisSpacing: 14,
                    crossAxisSpacing: 14,
                    childAspectRatio: 1.05,
                  ),
                  itemCount: kLevels.length,
                  itemBuilder: (context, i) {
                    final level = kLevels[i];
                    final unlocked = progress.isLevelUnlocked(level.id);
                    final best = progress.bestForLevel(level.id);
                    final colors = unlocked
                        ? kLevelGradients[level.id]!
                        : _lockedGradient;
                    return GestureDetector(
                      onTap: unlocked ? () => _openLevel(level) : null,
                      child: BeveledPanel(
                        padding: const EdgeInsets.all(14),
                        gradient: LinearGradient(
                          begin: Alignment.topLeft,
                          end: Alignment.bottomRight,
                          colors: colors,
                        ),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Row(
                              children: [
                                Expanded(
                                  child: Text(
                                    'Level ${level.id}',
                                    style: displayHeading(size: 20),
                                  ),
                                ),
                                if (!unlocked)
                                  const Icon(
                                    Icons.lock,
                                    color: Colors.white70,
                                    size: 21,
                                  ),
                              ],
                            ),
                            const SizedBox(height: 4),
                            Text(
                              level.name,
                              style: TextStyle(
                                fontSize: 16,
                                fontWeight: FontWeight.w700,
                                color: Colors.white.withValues(alpha: 0.85),
                              ),
                            ),
                            const Spacer(),
                            if (best > 0)
                              Container(
                                padding: const EdgeInsets.symmetric(
                                  horizontal: 9,
                                  vertical: 3,
                                ),
                                decoration: BoxDecoration(
                                  color: Colors.white.withValues(alpha: 0.25),
                                  borderRadius: BorderRadius.circular(999),
                                ),
                                child: Text(
                                  'Best: ${best.toStringAsFixed(1)}%',
                                  style: displayNumber(size: 12),
                                ),
                              ),
                            if (best > 0) const SizedBox(height: 6),
                            Text(
                              'Goal: ${level.goalPercent.toStringAsFixed(0)}%',
                              style: displayNumber(size: 13),
                            ),
                            Text(
                              unlocked ? 'Bots: ${level.botCount}' : 'Locked',
                              style: TextStyle(
                                color: Colors.white.withValues(alpha: 0.8),
                                fontWeight: FontWeight.w600,
                              ),
                            ),
                            const SizedBox(height: 5),
                            Container(
                              padding: const EdgeInsets.symmetric(
                                horizontal: 8,
                                vertical: 2.5,
                              ),
                              decoration: BoxDecoration(
                                color: Colors.black.withValues(alpha: 0.22),
                                borderRadius: BorderRadius.circular(999),
                              ),
                              child: Text(
                                '🏟 ${level.shape.label}',
                                style: const TextStyle(
                                  color: Colors.white,
                                  fontWeight: FontWeight.w800,
                                  fontSize: 11.5,
                                ),
                              ),
                            ),
                            if (_mode == GameMode.survival &&
                                progress.bestSurvivalForLevel(level.id) >
                                    0) ...[
                              const SizedBox(height: 5),
                              Text(
                                '⏱ Best ${_fmtSeconds(progress.bestSurvivalForLevel(level.id))}',
                                style: displayNumber(size: 12),
                              ),
                            ],
                          ],
                        ),
                      ),
                    );
                  },
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class HowToScreen extends StatelessWidget {
  const HowToScreen({super.key});

  @override
  Widget build(BuildContext context) {
    const style = TextStyle(fontSize: 16, height: 1.45, color: Colors.white);
    Widget section(String heading, List<String> lines) {
      return Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          BeveledPanel(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(heading, style: displayHeading(size: 17)),
                const SizedBox(height: 8),
                for (var i = 0; i < lines.length; i++) ...[
                  Text(lines[i], style: style),
                  if (i != lines.length - 1) const SizedBox(height: 8),
                ],
              ],
            ),
          ),
          const SizedBox(height: 14),
        ],
      );
    }

    return Scaffold(
      appBar: AppBar(
        title: Text('How to Play', style: displayHeading(size: 20)),
        backgroundColor: Colors.transparent,
        elevation: 0,
        foregroundColor: Colors.white,
      ),
      extendBodyBehindAppBar: true,
      body: Container(
        decoration: const BoxDecoration(gradient: kNightGradient),
        child: SafeArea(
          child: ListView(
            padding: const EdgeInsets.all(20),
            children: [
              Text(
                'Your zone glows in your skin\'s color, and your character wears the skin you equipped.',
                style: style,
              ),
              const SizedBox(height: 14),
              section('THE LOOP', [
                '1. Press and drag — your paint drop follows your finger.',
                '2. Leave your zone and you draw a bright trail behind you.',
                '3. Come back to your zone to close the loop — everything inside becomes your color!',
                '4. Careful: if a bot touches your trail while you are outside, you lose a life. You have 3 lives.',
                '5. Brave move: cross a bot\'s trail to knock that bot out and earn bonus points.',
                '6. Reach the goal % at the top before you run out of lives to finish the level.',
              ]),
              section('POWER-UPS', [
                '7. Glowing chips are power-ups — grab them before a bot does! ⚡ speeds you up, 🛡 is a shield that saves you from one cut, and ❄ freezes every bot. Bots can grab them too, so be quick.',
              ]),
              section('POINTS, RANKS & STREAKS', [
                '8. Finishing a match earns ⭐ points for the ground you claimed, every knockout, and winning. Spend points in Skins on a fresh new look!',
                '9. Every day brings one Daily Challenge — finish it for a ⭐ +150 bonus and grow your 🔥 streak. Miss a day and the streak resets!',
                '10. Every point you ever earn also climbs your rank, from Bronze 🥉 to Diamond 💎. Spending points on skins never lowers your rank.',
              ]),
              section('DAILY ARENA & NEMESIS', [
                '11. The Daily Arena is one fixed board per day — the same arena for everyone, with 5 bots. Your first scored run banks for the day; replays are practice and never overwrite it. The last 30 days live in Arena History.',
                '12. Ember is your permanent Nemesis rival in the Daily Arena — same name and ember color every day. Win 3 in a row and Ember gets faster and bolder; lose 3 in a row and Ember backs off.',
              ]),
              section('MODES & ARENAS', [
                'Modes: Classic is the goal race above. Quick Match gives you 3 minutes — the highest % when time runs out wins. Survival gives you one life and no goal — just last as long as you can.',
                'Arenas change every level: round fields, a blocked core, cross channels and rock islands. Dark cells are solid — no one can cross or claim them, but walls can help you close a loop!',
              ]),
            ],
          ),
        ),
      ),
    );
  }
}
