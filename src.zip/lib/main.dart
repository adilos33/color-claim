import 'package:flutter/material.dart';

import 'game/territory_engine.dart';
import 'screens/game_screen.dart';
import 'services/progress_store.dart';
import 'services/sound_service.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  final progressStore = await ProgressStore.load();
  SoundService.instance.muted = progressStore.progress.muted;
  runApp(ColorClaimApp(progressStore: progressStore));
}

class ColorClaimApp extends StatelessWidget {
  final ProgressStore progressStore;

  const ColorClaimApp({super.key, required this.progressStore});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Color Claim',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: const Color(kPlayerColor)),
        useMaterial3: true,
      ),
      home: HomeScreen(progressStore: progressStore),
    );
  }
}

const _ink = Color(0xFF22333B);

class HomeScreen extends StatelessWidget {
  final ProgressStore progressStore;

  const HomeScreen({super.key, required this.progressStore});

  void _openLevels(BuildContext context) {
    SoundService.instance.play(GameSound.pop);
    Navigator.of(context).push(
      MaterialPageRoute(
        builder: (_) => LevelSelectScreen(progressStore: progressStore),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [Color(0xFFB8F1EA), Color(0xFFF2FAEA)],
          ),
        ),
        child: SafeArea(
          child: Center(
            child: SingleChildScrollView(
              padding: const EdgeInsets.all(24),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  const _Mascot(),
                  const SizedBox(height: 16),
                  const Text(
                    'Color Claim',
                    style: TextStyle(
                      fontSize: 44,
                      fontWeight: FontWeight.w900,
                      color: _ink,
                    ),
                  ),
                  const SizedBox(height: 6),
                  const Text(
                    'Draw a loop. Claim the color. Beat the bots!',
                    textAlign: TextAlign.center,
                    style: TextStyle(fontSize: 16, color: Colors.black54),
                  ),
                  const SizedBox(height: 32),
                  SizedBox(
                    width: 260,
                    child: ElevatedButton.icon(
                      style: ElevatedButton.styleFrom(
                        padding: const EdgeInsets.symmetric(vertical: 16),
                        textStyle: const TextStyle(
                          fontSize: 20,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      icon: const Icon(Icons.play_arrow),
                      label: const Text('Play'),
                      onPressed: () => _openLevels(context),
                    ),
                  ),
                  const SizedBox(height: 12),
                  SizedBox(
                    width: 260,
                    child: OutlinedButton.icon(
                      style: OutlinedButton.styleFrom(
                        padding: const EdgeInsets.symmetric(vertical: 14),
                        textStyle: const TextStyle(fontSize: 17),
                      ),
                      icon: const Icon(Icons.grid_view),
                      label: const Text('Levels'),
                      onPressed: () => _openLevels(context),
                    ),
                  ),
                  const SizedBox(height: 12),
                  SizedBox(
                    width: 260,
                    child: OutlinedButton.icon(
                      style: OutlinedButton.styleFrom(
                        padding: const EdgeInsets.symmetric(vertical: 14),
                        textStyle: const TextStyle(fontSize: 17),
                      ),
                      icon: const Icon(Icons.help_outline),
                      label: const Text('How to Play'),
                      onPressed: () {
                        SoundService.instance.play(GameSound.pop);
                        Navigator.of(context).push(
                          MaterialPageRoute(
                            builder: (_) => const HowToScreen(),
                          ),
                        );
                      },
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}

/// Original paint-drop mascot (drawn, not an asset).
class _Mascot extends StatelessWidget {
  const _Mascot();

  @override
  Widget build(BuildContext context) {
    return CustomPaint(size: const Size(110, 110), painter: _MascotPainter());
  }
}

class _MascotPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final c = Offset(size.width / 2, size.height / 2 + 8);
    const color = Color(kPlayerColor);
    canvas.drawCircle(
      c + const Offset(0, 40),
      30,
      Paint()..color = Colors.black12,
    );
    canvas.drawCircle(c, 38, Paint()..color = color);
    canvas.drawCircle(c + const Offset(0, -42), 14, Paint()..color = color);
    for (final side in [-1, 1]) {
      final eye = c + Offset(side * 13.0, -4);
      canvas.drawCircle(eye, 9, Paint()..color = Colors.white);
      canvas.drawCircle(eye, 4.5, Paint()..color = _ink);
    }
    final smile = Path()
      ..moveTo(c.dx - 12, c.dy + 14)
      ..quadraticBezierTo(c.dx, c.dy + 24, c.dx + 12, c.dy + 14);
    canvas.drawPath(
      smile,
      Paint()
        ..color = _ink
        ..style = PaintingStyle.stroke
        ..strokeWidth = 3
        ..strokeCap = StrokeCap.round,
    );
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}

class LevelSelectScreen extends StatefulWidget {
  final ProgressStore progressStore;

  const LevelSelectScreen({super.key, required this.progressStore});

  @override
  State<LevelSelectScreen> createState() => _LevelSelectScreenState();
}

class _LevelSelectScreenState extends State<LevelSelectScreen> {
  Future<void> _openLevel(LevelConfig level) async {
    SoundService.instance.play(GameSound.pop);
    await Navigator.of(context).push(
      MaterialPageRoute(
        builder: (_) =>
            GameScreen(level: level, progressStore: widget.progressStore),
      ),
    );
    // A win may have changed the best percent or unlocked the next card.
    if (mounted) setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    final progress = widget.progressStore.progress;
    return Scaffold(
      appBar: AppBar(title: const Text('Choose a Level')),
      body: GridView.builder(
        padding: const EdgeInsets.all(16),
        gridDelegate: const SliverGridDelegateWithMaxCrossAxisExtent(
          maxCrossAxisExtent: 240,
          mainAxisSpacing: 14,
          crossAxisSpacing: 14,
          childAspectRatio: 1.05,
        ),
        itemCount: kLevels.length,
        itemBuilder: (context, i) {
          final level = kLevels[i];
          final unlocked = progress.isLevelUnlocked(level.id);
          final best = progress.bestForLevel(level.id);
          return InkWell(
            borderRadius: BorderRadius.circular(18),
            onTap: unlocked ? () => _openLevel(level) : null,
            child: Container(
              decoration: BoxDecoration(
                color: unlocked
                    ? Color(level.neutralArgb)
                    : const Color(0xFFE7ECEF),
                borderRadius: BorderRadius.circular(18),
                border: Border.all(color: Colors.black12),
              ),
              padding: const EdgeInsets.all(14),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Expanded(
                        child: Text(
                          'Level ${level.id}',
                          style: const TextStyle(
                            fontSize: 20,
                            fontWeight: FontWeight.bold,
                            color: _ink,
                          ),
                        ),
                      ),
                      if (!unlocked)
                        const Icon(Icons.lock, color: Colors.black45, size: 21),
                    ],
                  ),
                  const SizedBox(height: 4),
                  Text(
                    level.name,
                    style: const TextStyle(fontSize: 16, color: Colors.black54),
                  ),
                  const Spacer(),
                  if (best > 0)
                    Text(
                      'Best: ${best.toStringAsFixed(1)}%',
                      style: const TextStyle(
                        color: _ink,
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                  Text(
                    'Goal: ${level.goalPercent.toStringAsFixed(0)}%',
                    style: const TextStyle(fontWeight: FontWeight.w600),
                  ),
                  Text(
                    unlocked ? 'Bots: ${level.botCount}' : 'Locked',
                    style: const TextStyle(color: Colors.black54),
                  ),
                ],
              ),
            ),
          );
        },
      ),
    );
  }
}

class HowToScreen extends StatelessWidget {
  const HowToScreen({super.key});

  @override
  Widget build(BuildContext context) {
    const style = TextStyle(fontSize: 16, height: 1.45);
    return Scaffold(
      appBar: AppBar(title: const Text('How to Play')),
      body: ListView(
        padding: const EdgeInsets.all(20),
        children: const [
          Text(
            'Your color is the teal zone. You are the teal paint drop.',
            style: style,
          ),
          SizedBox(height: 12),
          Text(
            '1. Press and drag — your paint drop follows your finger.',
            style: style,
          ),
          SizedBox(height: 8),
          Text(
            '2. Leave your zone and you draw a bright trail behind you.',
            style: style,
          ),
          SizedBox(height: 8),
          Text(
            '3. Come back to your zone to close the loop — everything inside becomes your color!',
            style: style,
          ),
          SizedBox(height: 8),
          Text(
            '4. Careful: if a bot touches your trail while you are outside, you lose a life. You have 3 lives.',
            style: style,
          ),
          SizedBox(height: 8),
          Text(
            '5. Brave move: cross a bot\'s trail to knock that bot out and earn bonus points.',
            style: style,
          ),
          SizedBox(height: 8),
          Text(
            '6. Reach the goal % at the top before you run out of lives to finish the level.',
            style: style,
          ),
        ],
      ),
    );
  }
}
