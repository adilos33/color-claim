import 'dart:math';

import 'package:flutter/material.dart';

import '../game/territory_engine.dart';

/// One juice particle, positioned in board cell coordinates.
class FxParticle {
  double cx;
  double cy;
  double vx; // cells per second
  double vy;
  double age; // seconds
  final double life;
  final double size; // in cells
  final Color color;
  final bool gravity;
  final bool confetti;
  double rot;

  FxParticle({
    required this.cx,
    required this.cy,
    required this.vx,
    required this.vy,
    required this.life,
    required this.size,
    required this.color,
    this.gravity = false,
    this.confetti = false,
    this.rot = 0,
  }) : age = 0;

  double get t => (age / life).clamp(0.0, 1.0);
  bool get dead => age >= life;
}

/// Expanding ring shown when a loop closes.
class FxRing {
  final double cx;
  final double cy;
  final Color color;
  double age;
  final double life;

  FxRing({
    required this.cx,
    required this.cy,
    required this.color,
    this.life = 0.55,
  }) : age = 0;

  double get t => (age / life).clamp(0.0, 1.0);
  bool get dead => age >= life;
}

/// Floating text popup (e.g. '+4.2%').
class FxPopup {
  final double cx;
  final double cy;
  final String text;
  final Color color;
  double age;
  final double life;

  FxPopup({
    required this.cx,
    required this.cy,
    required this.text,
    required this.color,
    this.life = 1.05,
  }) : age = 0;

  double get t => (age / life).clamp(0.0, 1.0);
  bool get dead => age >= life;
}

/// Mutable bag of visual effects shared between the game screen
/// (which spawns/updates them) and the board painter (which draws them).
class FxState {
  final List<FxParticle> particles = [];
  final List<FxRing> rings = [];
  final List<FxPopup> popups = [];

  /// White capture flash, 0..0.4 alpha.
  double flash = 0;

  /// Red danger vignette strength, 0..1.
  double danger = 0;

  void clear() {
    particles.clear();
    rings.clear();
    popups.clear();
    flash = 0;
    danger = 0;
  }
}

class BoardPainter extends CustomPainter {
  final TerritoryEngine engine;

  /// Interpolation factor 0..1 between each actor's previous and current cell.
  final double t;

  final FxState fx;

  BoardPainter(this.engine, this.t, this.fx);

  @override
  void paint(Canvas canvas, Size size) {
    final cell = size.width / TerritoryEngine.cols;
    canvas.drawRect(
      Offset.zero & size,
      Paint()..color = Color(engine.level.neutralArgb),
    );

    final paint = Paint();
    // Territory cells (saturated fill, drawn slightly oversized to
    // avoid grid seams).
    for (var y = 0; y < TerritoryEngine.rows; y++) {
      for (var x = 0; x < TerritoryEngine.cols; x++) {
        final owner = engine.owners[engine.idx(x, y)];
        if (owner < 0) continue;
        paint.color = Color(engine.actors[owner].colorArgb);
        canvas.drawRect(
          Rect.fromLTWH(x * cell, y * cell, cell + 0.5, cell + 0.5),
          paint,
        );
      }
    }

    // Trails: thick, glossy, with a soft glow layer underneath.
    for (final actor in engine.actors) {
      if (actor.trail.isEmpty) continue;
      final bright = Color.lerp(Color(actor.colorArgb), Colors.white, 0.32)!;
      for (final c in actor.trailSet) {
        final x = c % TerritoryEngine.cols;
        final y = c ~/ TerritoryEngine.cols;
        final rect = Rect.fromLTWH(
          x * cell - cell * 0.04,
          y * cell - cell * 0.04,
          cell * 1.08,
          cell * 1.08,
        );
        paint.color = bright.withValues(alpha: 0.45);
        canvas.drawRRect(
          RRect.fromRectAndRadius(rect, Radius.circular(cell * 0.34)),
          paint,
        );
        paint.color = bright;
        canvas.drawRRect(
          RRect.fromRectAndRadius(
            rect.deflate(cell * 0.08),
            Radius.circular(cell * 0.28),
          ),
          paint,
        );
      }
    }

    // Capture rings (under the heads, over the trails).
    for (final ring in fx.rings) {
      final p = ring.t;
      final eased = 1 - pow(1 - p, 3).toDouble();
      paint
        ..style = PaintingStyle.stroke
        ..strokeWidth = cell * 0.32 * (1 - p * 0.6)
        ..color = ring.color.withValues(alpha: (1 - p) * 0.85);
      canvas.drawCircle(
        Offset(ring.cx * cell, ring.cy * cell),
        0.6 * cell + eased * 5.2 * cell,
        paint,
      );
    }
    paint.style = PaintingStyle.fill;

    // Particles.
    for (final p in fx.particles) {
      final alpha = (1 - p.t).clamp(0.0, 1.0);
      final pos = Offset(p.cx * cell, p.cy * cell);
      if (p.confetti) {
        canvas.save();
        canvas.translate(pos.dx, pos.dy);
        canvas.rotate(p.rot);
        paint.color = p.color.withValues(alpha: alpha);
        canvas.drawRect(
          Rect.fromCenter(
            center: Offset.zero,
            width: p.size * cell * 1.5,
            height: p.size * cell * 0.75,
          ),
          paint,
        );
        canvas.restore();
      } else {
        paint.color = p.color.withValues(alpha: alpha);
        canvas.drawCircle(pos, p.size * cell * 0.5, paint);
        paint.color = Colors.white.withValues(alpha: alpha * 0.75);
        canvas.drawCircle(pos, p.size * cell * 0.22, paint);
      }
    }

    // Heads: original glossy blob characters.
    for (final actor in engine.actors) {
      if (!actor.alive) continue;
      final fxPos = actor.prevX + (actor.x - actor.prevX) * t;
      final fyPos = actor.prevY + (actor.y - actor.prevY) * t;
      final center = Offset((fxPos + 0.5) * cell, (fyPos + 0.5) * cell);
      _blob(canvas, center, cell * 0.88, actor);
    }

    // Floating popups.
    for (final popup in fx.popups) {
      final scaleIn = min(1.0, popup.age * 7);
      final scale = 0.6 + 0.4 * scaleIn;
      final rise = popup.t * 2.4 * cell;
      final pos = Offset(popup.cx * cell, popup.cy * cell - rise);
      final alpha = popup.t < 0.7 ? 1.0 : (1 - popup.t) / 0.3;
      final tp = TextPainter(
        text: TextSpan(
          text: popup.text,
          style: TextStyle(
            fontSize: cell * 1.9 * scale,
            fontWeight: FontWeight.w900,
            color: popup.color.withValues(alpha: alpha.clamp(0.0, 1.0)),
            shadows: [
              Shadow(
                color: Colors.black.withValues(alpha: 0.55 * alpha),
                blurRadius: 4,
                offset: const Offset(0, 2),
              ),
            ],
          ),
        ),
        textDirection: TextDirection.ltr,
      )..layout();
      tp.paint(canvas, pos - Offset(tp.width / 2, tp.height / 2));
    }

    // Glossy sheen across the top of the arena.
    final sheen = Paint()
      ..shader = LinearGradient(
        begin: Alignment.topCenter,
        end: Alignment.center,
        colors: [
          Colors.white.withValues(alpha: 0.13),
          Colors.white.withValues(alpha: 0.0),
        ],
      ).createShader(Offset.zero & size);
    canvas.drawRect(Offset.zero & size, sheen);

    // Capture flash.
    if (fx.flash > 0.005) {
      canvas.drawRect(
        Offset.zero & size,
        Paint()..color = Colors.white.withValues(alpha: fx.flash),
      );
    }

    // Danger vignette: pulsing red edges while a bot closes in on
    // the player's exposed trail.
    if (fx.danger > 0.01) {
      final rect = Offset.zero & size;
      final vignette = Paint()
        ..shader = RadialGradient(
          radius: 0.78,
          colors: [
            Colors.transparent,
            Colors.transparent,
            const Color(0xFFFF2D40).withValues(alpha: 0.38 * fx.danger),
          ],
          stops: const [0.0, 0.62, 1.0],
        ).createShader(rect);
      canvas.drawRect(rect, vignette);
    }
  }

  /// Draws one original rounded blob character: saturated body, glossy
  /// highlight, two eyes that look toward the movement direction.
  /// The player additionally carries a little paint-drop tip.
  void _blob(Canvas canvas, Offset center, double r, Actor actor) {
    final color = Color(actor.colorArgb);

    // Soft ground shadow.
    canvas.drawOval(
      Rect.fromCenter(
        center: center + Offset(0, r * 0.82),
        width: r * 1.55,
        height: r * 0.5,
      ),
      Paint()..color = Colors.black.withValues(alpha: 0.20),
    );

    // Gentle squash-and-stretch bounce tied to the step interpolation.
    final bounce = sin(t * pi);
    canvas.save();
    canvas.translate(center.dx, center.dy);
    canvas.scale(1 + 0.05 * bounce, 1 - 0.05 * bounce);
    canvas.translate(-center.dx, -center.dy);

    // Bottom shade for a plump, premium look.
    canvas.drawCircle(
      center + Offset(0, r * 0.16),
      r * 0.94,
      Paint()..color = Color.lerp(color, Colors.black, 0.16)!,
    );
    // Main body.
    canvas.drawCircle(center, r * 0.94, Paint()..color = color);

    if (actor.isPlayer) {
      // Paint-drop tip (matches the original mascot/icon).
      canvas.drawCircle(
        center + Offset(0, -r * 1.02),
        r * 0.36,
        Paint()..color = color,
      );
    }

    // Glossy highlight.
    canvas.drawOval(
      Rect.fromCenter(
        center: center + Offset(-r * 0.36, -r * 0.44),
        width: r * 0.62,
        height: r * 0.4,
      ),
      Paint()..color = Colors.white.withValues(alpha: 0.38),
    );
    canvas.drawCircle(
      center + Offset(-r * 0.52, -r * 0.58),
      r * 0.09,
      Paint()..color = Colors.white.withValues(alpha: 0.7),
    );

    _face(canvas, center, r * 0.94, actor.dx, actor.dy, actor.isPlayer);
    canvas.restore();
  }

  void _face(Canvas canvas, Offset center, double r, int dx, int dy, bool isPlayer) {
    final look = Offset(dx.toDouble(), dy.toDouble()) * r * 0.13;
    const ink = Color(0xFF22333B);
    for (final side in [-1, 1]) {
      final eye = center + Offset(side * r * 0.34, -r * 0.06) + look;
      canvas.drawCircle(eye, r * 0.27, Paint()..color = Colors.white);
      canvas.drawCircle(eye + look, r * 0.14, Paint()..color = ink);
      canvas.drawCircle(
        eye + look + Offset(-r * 0.045, -r * 0.045),
        r * 0.05,
        Paint()..color = Colors.white,
      );
    }
    if (isPlayer) {
      final smile = Path()
        ..moveTo(center.dx - r * 0.2, center.dy + r * 0.28)
        ..quadraticBezierTo(
          center.dx,
          center.dy + r * 0.44,
          center.dx + r * 0.2,
          center.dy + r * 0.28,
        );
      canvas.drawPath(
        smile,
        Paint()
          ..color = ink
          ..style = PaintingStyle.stroke
          ..strokeWidth = r * 0.07
          ..strokeCap = StrokeCap.round,
      );
    }
  }

  @override
  bool shouldRepaint(covariant BoardPainter oldDelegate) => true;
}

/// Small corner minimap: territory micro-cells + actor dots.
class MinimapPainter extends CustomPainter {
  final TerritoryEngine engine;

  MinimapPainter(this.engine);

  @override
  void paint(Canvas canvas, Size size) {
    final cw = size.width / TerritoryEngine.cols;
    final ch = size.height / TerritoryEngine.rows;
    canvas.drawRect(
      Offset.zero & size,
      Paint()..color = Color(engine.level.neutralArgb).withValues(alpha: 0.35),
    );
    final paint = Paint();
    for (var y = 0; y < TerritoryEngine.rows; y++) {
      for (var x = 0; x < TerritoryEngine.cols; x++) {
        final owner = engine.owners[engine.idx(x, y)];
        if (owner < 0) continue;
        paint.color = Color(engine.actors[owner].colorArgb);
        canvas.drawRect(Rect.fromLTWH(x * cw, y * ch, cw + 0.4, ch + 0.4), paint);
      }
    }
    for (final actor in engine.actors) {
      if (!actor.alive) continue;
      final pos = Offset((actor.x + 0.5) * cw, (actor.y + 0.5) * ch);
      final dotR = actor.isPlayer ? cw * 2.1 : cw * 1.6;
      canvas.drawCircle(
        pos,
        dotR,
        Paint()
          ..color = Colors.white
          ..style = PaintingStyle.stroke
          ..strokeWidth = actor.isPlayer ? 1.6 : 1.1,
      );
      canvas.drawCircle(pos, dotR - 0.8, Paint()..color = Color(actor.colorArgb));
    }
  }

  @override
  bool shouldRepaint(covariant MinimapPainter oldDelegate) => true;
}
