import 'dart:math';
import 'dart:ui' as ui;

import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';

import '../game/powerups.dart';
import '../game/skins.dart';
import '../game/territory_engine.dart';
import 'skin_painter.dart';
import 'sprite_bank.dart';

/// One juice particle, positioned in board cell coordinates.
class FxParticle {
  double cx;
  double cy;
  double vx; // cells per second
  double vy;
  double age; // seconds
  final double life;
  final double size; // in cells
  final Color color;
  final bool gravity;
  final bool confetti;
  double rot;

  FxParticle({
    required this.cx,
    required this.cy,
    required this.vx,
    required this.vy,
    required this.life,
    required this.size,
    required this.color,
    this.gravity = false,
    this.confetti = false,
    this.rot = 0,
  }) : age = 0;

  double get t => (age / life).clamp(0.0, 1.0);
  bool get dead => age >= life;
}

/// Expanding ring shown when a loop closes.
class FxRing {
  final double cx;
  final double cy;
  final Color color;
  double age;
  final double life;

  FxRing({
    required this.cx,
    required this.cy,
    required this.color,
    this.life = 0.55,
  }) : age = 0;

  double get t => (age / life).clamp(0.0, 1.0);
  bool get dead => age >= life;
}

/// Floating text popup (e.g. '+4.2%').
class FxPopup {
  final double cx;
  final double cy;
  final String text;
  final Color color;
  double age;
  final double life;

  FxPopup({
    required this.cx,
    required this.cy,
    required this.text,
    required this.color,
    this.life = 1.05,
  }) : age = 0;

  double get t => (age / life).clamp(0.0, 1.0);
  bool get dead => age >= life;
}

/// Mutable bag of visual effects shared between the game screen
/// (which spawns/updates them) and the board painter (which draws them).
class FxState {
  final List<FxParticle> particles = [];
  final List<FxRing> rings = [];
  final List<FxPopup> popups = [];

  /// White capture flash, 0..0.4 alpha.
  double flash = 0;

  /// Red danger vignette strength, 0..1.
  double danger = 0;

  /// FX clock in seconds, advanced by the game screen with the same
  /// dt that ages the particles — there are deliberately no separate
  /// timers; every expression and motion beat below derives from it.
  double nowSec = 0;

  /// FX-clock time at which the current match (re)started: spawn-in
  /// animation, the "GO!" pop and the excited opening face key off it.
  double matchStartSec = 0;

  /// FX-clock deadlines for the owl's happy (capture) and dizzy
  /// (lost a life) faces.
  double happyUntilSec = -1;
  double hurtUntilSec = -1;

  /// Match outcome once finished: true = win, false = loss,
  /// null while the run is live. Drives celebrate/sad faces.
  bool? endVictory;

  /// Big-capture "breathing" pulse, 1 → 0 over about half a second;
  /// the painter scales the whole board by a hair while it decays.
  double breath = 0;

  void clear() {
    particles.clear();
    rings.clear();
    popups.clear();
    flash = 0;
    danger = 0;
    // A cleared FX bag means a fresh match: replay the spawn-in and
    // "GO!" beats from the current clock reading.
    matchStartSec = nowSec;
    happyUntilSec = -1;
    hurtUntilSec = -1;
    endVictory = null;
    breath = 0;
  }
}

/// Cross-frame render caches shared by the board and minimap painters.
///
/// The territory grid only changes when cell ownership does (captures
/// and claim circles), so it is recorded once into a [ui.Picture] and
/// replayed each frame instead of re-issuing ~3136 cell draws from Dart
/// per frame. The cache is keyed by engine instance, the engine's
/// `boardRevision`, and the paint size; a new engine (restart), a new
/// revision (a capture happened), or a resize re-records it.
class BoardRenderCache {
  ui.Picture? _boardPicture;
  TerritoryEngine? _boardEngine;
  int _boardRevision = -1;
  Size _boardSize = Size.zero;

  ui.Picture? _minimapPicture;
  TerritoryEngine? _minimapEngine;
  int _minimapRevision = -1;
  Size _minimapSize = Size.zero;

  Shader? _sheenShader;
  Size _sheenSize = Size.zero;

  final Map<String, TextPainter> _labels = {};

  ui.Picture boardPictureFor(
    TerritoryEngine engine,
    Size size,
    void Function(Canvas canvas, Size size) record,
  ) {
    if (_boardPicture == null ||
        !identical(_boardEngine, engine) ||
        _boardRevision != engine.boardRevision ||
        _boardSize != size) {
      final recorder = ui.PictureRecorder();
      record(Canvas(recorder), size);
      _boardPicture?.dispose();
      _boardPicture = recorder.endRecording();
      _boardEngine = engine;
      _boardRevision = engine.boardRevision;
      _boardSize = size;
    }
    return _boardPicture!;
  }

  ui.Picture minimapPictureFor(
    TerritoryEngine engine,
    Size size,
    void Function(Canvas canvas, Size size) record,
  ) {
    if (_minimapPicture == null ||
        !identical(_minimapEngine, engine) ||
        _minimapRevision != engine.boardRevision ||
        _minimapSize != size) {
      final recorder = ui.PictureRecorder();
      record(Canvas(recorder), size);
      _minimapPicture?.dispose();
      _minimapPicture = recorder.endRecording();
      _minimapEngine = engine;
      _minimapRevision = engine.boardRevision;
      _minimapSize = size;
    }
    return _minimapPicture!;
  }

  /// Top sheen gradient, created once per board size.
  Shader sheenFor(Size size) {
    if (_sheenShader == null || _sheenSize != size) {
      _sheenSize = size;
      _sheenShader = LinearGradient(
        begin: Alignment.topCenter,
        end: Alignment.center,
        colors: [
          Colors.white.withValues(alpha: 0.13),
          Colors.white.withValues(alpha: 0.0),
        ],
      ).createShader(Offset.zero & size);
    }
    return _sheenShader!;
  }

  /// Laid-out text for static labels (pickup icons), laid out once per
  /// (text, font size) instead of on every frame.
  TextPainter label(String text, TextStyle style) {
    final key = '$text/${style.fontSize?.toStringAsFixed(2)}';
    return _labels.putIfAbsent(
      key,
      () => TextPainter(
        text: TextSpan(text: text, style: style),
        textDirection: TextDirection.ltr,
      )..layout(),
    );
  }

  // --- Cinematic motion state (integrated per paint, never timed) ---

  /// Last continuous step-time seen, so wing/bank integrators can use
  /// real elapsed steps even though paint has no clock of its own.
  double _lastStepTime = 0;

  /// Per-actor wing flap phase (radians) and smoothed amplitude.
  final Map<int, double> _wingPhase = {};
  final Map<int, double> _wingAmp = {};

  /// Per-actor smoothed banking (roll) angle in radians.
  final Map<int, double> _bank = {};

  /// Player expression transition bookkeeping: the face currently
  /// shown, when it took over, and what it replaced. A switch pops
  /// the eyes briefly instead of swapping faces mid-frame.
  OwlExpression exprCurr = OwlExpression.neutral;
  OwlExpression exprPrev = OwlExpression.neutral;
  double exprSwitchSec = -10;

  /// Advances the wing/bank integrators by [dtSteps] engine steps and
  /// returns the wing flap angle (radians, + = raised) for [actorId].
  /// [freq] is flap cycles per step, [amp] the target swing in
  /// radians; amplitude eases toward its target so state changes
  /// (boost on/off, turns) never snap the wings.
  double wingFlapFor(int actorId, double dtSteps, double freq, double amp) {
    final phase = (_wingPhase[actorId] ?? 0) + dtSteps * freq * 2 * pi;
    _wingPhase[actorId] = phase;
    final prevAmp = _wingAmp[actorId] ?? amp;
    final smoothed = prevAmp + (amp - prevAmp) * min(1.0, dtSteps * 1.5 + 0.06);
    _wingAmp[actorId] = smoothed;
    return sin(phase) * smoothed;
  }

  /// Eases actor [actorId]'s banking toward [target] radians.
  double bankFor(int actorId, double dtSteps, double target) {
    final current = _bank[actorId] ?? 0;
    final next = current + (target - current) * min(1.0, dtSteps * 1.8 + 0.08);
    _bank[actorId] = next;
    return next;
  }

  /// Step-time delta since the previous paint, clamped so tab-switch
  /// stalls do not teleport the integrators.
  double stepDelta(double stepTime) {
    final dt = (stepTime - _lastStepTime).clamp(0.0, 0.6);
    _lastStepTime = stepTime;
    return dt;
  }

  /// Records an expression switch at [nowSec] (FX clock).
  void noteExpression(OwlExpression next, double nowSec) {
    if (next == exprCurr) return;
    exprPrev = exprCurr;
    exprCurr = next;
    exprSwitchSec = nowSec;
  }
}

class BoardPainter extends CustomPainter {
  final TerritoryEngine engine;

  /// Live interpolation clock: the fraction (0..1) of the current
  /// engine step, updated by the game screen on every ticker tick and
  /// used both as the CustomPaint repaint signal and read here at paint
  /// time, so heads render from the freshest simulation state without
  /// rebuilding the widget tree per frame.
  final ValueListenable<double> interp;

  final FxState fx;

  /// Shared cross-frame caches (territory picture, text, shaders).
  final BoardRenderCache cache;

  /// Equipped skin drawn for the player's head.
  final SkinDef playerSkin;

  /// Pre-rendered character sprites; until the bank finishes
  /// decoding (or if a sprite is missing) heads fall back to the
  /// code-drawn characters.
  final SpriteBank sprites;

  BoardPainter(
    this.engine,
    this.interp,
    this.fx, {
    required this.cache,
    this.playerSkin = kCoralDropSkin,
    SpriteBank? sprites,
  }) : sprites = sprites ?? SpriteBank.instance,
       super(repaint: interp);

  double get t => interp.value;

  /// The player owl's current expression, derived fresh each paint
  /// from FX timestamps and live engine state — most urgent first:
  /// hurt beats everything, then the end-of-match mood, a nearby
  /// threat, the Speed-boost glare, the capture grin, the excited
  /// opening face, and finally the skin's neutral personality.
  OwlExpression _playerExpression(Actor player) {
    final now = fx.nowSec;
    if (now < fx.hurtUntilSec) return OwlExpression.dizzy;
    final end = fx.endVictory;
    if (end != null) {
      return end ? OwlExpression.celebrate : OwlExpression.sad;
    }
    if (fx.danger > 0.15) return OwlExpression.scared;
    if (player.speedBoostSteps > 0) return OwlExpression.determined;
    if (now < fx.happyUntilSec) return OwlExpression.happy;
    if (now - fx.matchStartSec < 1.1) return OwlExpression.happy;
    return OwlExpression.neutral;
  }

  static double _easeOutBack(double p) {
    const c1 = 1.70158;
    const c3 = c1 + 1;
    final q = p - 1;
    return 1 + c3 * q * q * q + c1 * q * q;
  }

  /// Where [actor]'s head is drawn, in cell coordinates (cell centers
  /// at +0.5). Starts from the actor's logical cell and adds its true
  /// fractional advance toward the next cell, derived from the
  /// movement accumulator: `moveAcc + speed * t` is exactly how far
  /// the actor will have travelled into its next step, so the head is
  /// never drawn a step behind the simulation, and a turn shows the
  /// instant its direction is set. The advance is capped by how many
  /// cells ahead are actually enterable, so heads never glide into a
  /// wall they are pressed against.
  Offset _headCells(Actor actor) {
    var advance = 0.0;
    if (t > 0 && (actor.dx != 0 || actor.dy != 0)) {
      var run = 0;
      var cx = actor.x;
      var cy = actor.y;
      while (run < 2) {
        final nx = cx + actor.dx;
        final ny = cy + actor.dy;
        if (!engine.inBounds(nx, ny) || engine.mask.isBlocked(nx, ny)) break;
        cx = nx;
        cy = ny;
        run++;
      }
      if (run > 0) {
        final raw = actor.moveAcc + engine.effectiveSpeed(actor) * t;
        advance = min(raw, run.toDouble());
      }
    }
    return Offset(
      actor.x + actor.dx * advance + 0.5,
      actor.y + actor.dy * advance + 0.5,
    );
  }

  @override
  void paint(Canvas canvas, Size size) {
    final cell = size.width / TerritoryEngine.cols;

    // Big-capture breathing: the whole board leans in by a hair
    // while fx.breath decays. Pure canvas transform — no layout
    // shift, no widget rebuilds.
    if (fx.breath > 0.003) {
      final s = 1 + 0.012 * fx.breath;
      canvas.translate(size.width / 2, size.height / 2);
      canvas.scale(s);
      canvas.translate(-size.width / 2, -size.height / 2);
    }

    // Static layer (void bed + every cell): cached picture, replayed.
    canvas.drawPicture(cache.boardPictureFor(engine, size, _recordStatic));

    final paint = Paint();

    // Trails: bold ribbons. Each actor's trail is stroked as one
    // polyline through its cell centers with round caps and joins, so
    // turns read as a smooth, thick ribbon instead of scalloped cells.
    // A wide soft glow stroke sits under a near-cell-width bright core;
    // the player's core is slightly wider with a glossy center stripe,
    // so your own line always reads first. Two or three draw calls per
    // actor keeps the frame cheap.
    for (final actor in engine.actors) {
      if (actor.trail.isEmpty) continue;
      final bright = Color.lerp(Color(actor.colorArgb), Colors.white, 0.32)!;
      final path = Path();
      for (var i = 0; i < actor.trail.length; i++) {
        final c = actor.trail[i];
        final px = (c % TerritoryEngine.cols + 0.5) * cell;
        final py = (c ~/ TerritoryEngine.cols + 0.5) * cell;
        if (i == 0) {
          path.moveTo(px, py);
        } else {
          path.lineTo(px, py);
        }
      }
      // A one-cell trail is a zero-length subpath; give it a dot so the
      // round cap always has something to paint.
      final single = actor.trail.length == 1;
      if (single) {
        final c = actor.trail.first;
        path.lineTo(
          (c % TerritoryEngine.cols + 0.5) * cell + 0.01,
          (c ~/ TerritoryEngine.cols + 0.5) * cell,
        );
      }
      paint
        ..style = PaintingStyle.stroke
        ..strokeCap = StrokeCap.round
        ..strokeJoin = StrokeJoin.round;
      // Soft contact shadow hugging the ground under the ribbon.
      canvas.save();
      canvas.translate(cell * 0.12, cell * 0.20);
      paint
        ..strokeWidth = cell * (actor.isPlayer ? 1.52 : 1.25)
        ..color = Colors.black.withValues(alpha: 0.15);
      canvas.drawPath(path, paint);
      canvas.restore();
      paint
        ..strokeWidth = cell * (actor.isPlayer ? 2.05 : 1.75)
        ..color = bright.withValues(alpha: 0.45);
      canvas.drawPath(path, paint);
      paint
        ..strokeWidth = cell * (actor.isPlayer ? 1.52 : 1.25)
        ..color = bright;
      canvas.drawPath(path, paint);
      if (actor.isPlayer) {
        paint
          ..strokeWidth = cell * 0.60
          ..color = Colors.white.withValues(alpha: 0.28);
        canvas.drawPath(path, paint);
      }
      paint.style = PaintingStyle.fill;
    }

    // Power-up pickups: pulsing glow chip with its icon, drawn over the
    // trails so it is always easy to spot. The pulse phase comes from
    // the engine step count (the painter has no clock of its own).
    // The chip is a shaded jewel: contact shadow, radial gradient from
    // a white-hot core to the accent tint, accent rim, gloss dot.
    final pulse = 1 + 0.10 * sin(engine.steps * 2 * pi / 22);
    for (final pickup in engine.pickups) {
      final center = Offset((pickup.x + 0.5) * cell, (pickup.y + 0.5) * cell);
      final accent = Color(pickup.kind.colorArgb);
      paint.color = accent.withValues(alpha: 0.35);
      canvas.drawCircle(center, cell * 0.95 * pulse, paint);
      paint.color = Colors.black.withValues(alpha: 0.22);
      canvas.drawCircle(
        center + Offset(0, cell * 0.14),
        cell * 0.62,
        paint,
      );
      final chipRect = Rect.fromCircle(center: center, radius: cell * 0.68);
      canvas.drawCircle(
        center,
        cell * 0.68,
        Paint()
          ..shader = RadialGradient(
            center: const Alignment(-0.35, -0.4),
            radius: 1.15,
            colors: [
              Colors.white,
              Color.lerp(accent, Colors.white, 0.45)!,
            ],
          ).createShader(chipRect),
      );
      paint
        ..style = PaintingStyle.stroke
        ..strokeWidth = cell * 0.11
        ..color = accent;
      canvas.drawCircle(center, cell * 0.68, paint);
      paint.style = PaintingStyle.fill;
      paint.color = Colors.white.withValues(alpha: 0.55);
      canvas.drawCircle(
        center + Offset(-cell * 0.22, -cell * 0.30),
        cell * 0.10,
        paint,
      );
      final tp = cache.label(
        pickup.kind.emoji,
        TextStyle(fontSize: cell * 1.12),
      );
      tp.paint(canvas, center - Offset(tp.width / 2, tp.height / 2));
    }

    // Frozen actors get an icy halo behind their heads.
    if (engine.botsFrozenSteps > 0 || engine.playerFrozenSteps > 0) {
      for (final actor in engine.actors) {
        if (!actor.alive) continue;
        final frozen = actor.isPlayer
            ? engine.playerFrozenSteps > 0
            : engine.botsFrozenSteps > 0;
        if (!frozen) continue;
        final head = _headCells(actor);
        final pos = Offset(head.dx * cell, head.dy * cell);
        paint.color = const Color(0xFF9BE8FF).withValues(alpha: 0.4);
        canvas.drawCircle(pos, cell * 1.60, paint);
      }
    }

    // Capture rings (under the heads, over the trails).
    for (final ring in fx.rings) {
      final p = ring.t;
      final eased = 1 - pow(1 - p, 3).toDouble();
      paint
        ..style = PaintingStyle.stroke
        ..strokeWidth = cell * 0.32 * (1 - p * 0.6)
        ..color = ring.color.withValues(alpha: (1 - p) * 0.85);
      canvas.drawCircle(
        Offset(ring.cx * cell, ring.cy * cell),
        0.6 * cell + eased * 5.2 * cell,
        paint,
      );
    }
    paint.style = PaintingStyle.fill;

    // Particles.
    for (final p in fx.particles) {
      final alpha = (1 - p.t).clamp(0.0, 1.0);
      final pos = Offset(p.cx * cell, p.cy * cell);
      if (p.confetti) {
        canvas.save();
        canvas.translate(pos.dx, pos.dy);
        canvas.rotate(p.rot);
        paint.color = p.color.withValues(alpha: alpha);
        canvas.drawRect(
          Rect.fromCenter(
            center: Offset.zero,
            width: p.size * cell * 1.5,
            height: p.size * cell * 0.75,
          ),
          paint,
        );
        canvas.restore();
      } else {
        paint.color = p.color.withValues(alpha: alpha);
        canvas.drawCircle(pos, p.size * cell * 0.5, paint);
        paint.color = Colors.white.withValues(alpha: alpha * 0.75);
        canvas.drawCircle(pos, p.size * cell * 0.22, paint);
      }
    }

    // Heads: huge bold characters (body about 2.9 cells across) riding
    // the trail tips — the player wears the equipped owl skin, bots
    // are glossy blobs with rotating creature features. Motion is
    // cinematic rather than stepped: heads bob as they glide, roll
    // (bank) into turns, the owl's wings flap with the pace, and at
    // match start everyone drops in with a spring settle while a
    // chunky "GO!" pops. All of it integrates off the continuous
    // step-time and the FX clock — no timers, no extra repaints.
    const headScale = 1.55; // head radius, in cells
    final stepTime = engine.steps + t;
    final dtSteps = cache.stepDelta(stepTime);
    var botOrdinal = 0;
    for (final actor in engine.actors) {
      if (!actor.alive) continue;
      final isBot = !actor.isPlayer;
      final variant = isBot ? botOrdinal++ % 5 : 0;

      // Match-start drop-in, staggered per bot, with a springy
      // scale settle. Actors still waiting their turn stay hidden.
      final spawnAge =
          fx.nowSec - fx.matchStartSec - (isBot ? actor.id * 0.055 : 0.0);
      if (spawnAge < 0) continue;
      var spawnDrop = 0.0;
      var spawnScale = 1.0;
      if (spawnAge < 0.6) {
        final p = (spawnAge / 0.6).clamp(0.0, 1.0);
        final eased = 1 - pow(1 - p, 3).toDouble();
        spawnDrop = (1 - eased) * cell * 2.6;
        spawnScale = 0.55 + 0.45 * _easeOutBack(p);
      }

      final head = _headCells(actor);
      // Gentle bob while gliding (period ~7 steps), bots subtler.
      final bob = (actor.dx != 0 || actor.dy != 0)
          ? sin(stepTime * 2 * pi / 7) * cell * (isBot ? 0.06 : 0.09)
          : 0.0;
      final center = Offset(head.dx * cell, head.dy * cell + bob);
      final headR = cell * headScale;

      // Banking: roll toward the signed turn between the last step's
      // direction and the current heading, eased back when straight.
      final lastVx = actor.x - actor.prevX;
      final lastVy = actor.y - actor.prevY;
      var bankTarget = 0.0;
      if ((lastVx != 0 || lastVy != 0) && (actor.dx != 0 || actor.dy != 0)) {
        final cross = lastVx * actor.dy - lastVy * actor.dx;
        final dot = lastVx * actor.dx + lastVy * actor.dy;
        if (cross != 0) {
          bankTarget = cross * 0.16;
        } else if (dot < 0) {
          bankTarget = 0.14; // 180° reversal still leans in
        }
      }
      final bank = cache.bankFor(actor.id, dtSteps, bankTarget);
      final turning = bankTarget != 0;

      canvas.save();
      canvas.translate(center.dx, center.dy - spawnDrop);
      canvas.scale(spawnScale);
      canvas.translate(-center.dx, -(center.dy - spawnDrop));
      final drawCenter = Offset(center.dx, center.dy - spawnDrop);

      if (actor.isPlayer) {
        final boosting = actor.speedBoostSteps > 0;
        // Wing pace: frantic on turns and boosts, a working flap
        // while trailing, lazy spread glide when safe at home.
        final double wingFreq;
        final double wingAmp;
        if (boosting || turning) {
          wingFreq = 0.30;
          wingAmp = 0.85;
        } else if (actor.isOutside) {
          wingFreq = 0.16;
          wingAmp = 0.50;
        } else {
          wingFreq = 0.05;
          wingAmp = 0.16;
        }
        final flap = cache.wingFlapFor(actor.id, dtSteps, wingFreq, wingAmp);
        final expression = _playerExpression(actor);
        cache.noteExpression(expression, fx.nowSec);
        final exprAge = fx.nowSec - cache.exprSwitchSec;
        final exprPop = (exprAge / 0.13).clamp(0.0, 1.0);
        final owlSprite = sprites.owlFor(expression);
        if (owlSprite != null) {
          _drawOwlSprite(
            canvas,
            owlSprite,
            drawCenter,
            headR,
            expression: expression,
            exprAge: exprAge,
            bank: bank,
            boosting: boosting,
          );
        } else {
          drawSkinCharacter(
            canvas,
            drawCenter,
            headR,
            playerSkin,
            dx: actor.dx,
            dy: actor.dy,
            phase: t,
            expression: expression,
            exprPop: exprPop,
            exprAge: exprAge,
            bank: bank,
            wingFlap: flap,
            boosting: boosting,
          );
        }
      } else {
        final botSprite = sprites.botFor(variant);
        if (botSprite != null) {
          _drawBotSprite(
            canvas,
            botSprite,
            drawCenter,
            headR,
            actor,
            variant: variant,
            frozen: engine.botsFrozenSteps > 0,
            hunting: actor.hunting,
            bank: bank,
          );
        } else {
          _blob(
            canvas,
            drawCenter,
            headR,
            actor,
            variant: variant,
            frozen: engine.botsFrozenSteps > 0,
            hunting: actor.hunting,
            bank: bank,
          );
        }
      }
      // A ready shield shows as a sky ring around the character.
      if (actor.hasShield) {
        paint
          ..style = PaintingStyle.stroke
          ..strokeWidth = cell * 0.12
          ..color = const Color(0xFF38BDF8).withValues(alpha: 0.9);
        canvas.drawCircle(drawCenter, headR * 1.16, paint);
        paint
          ..strokeWidth = cell * 0.06
          ..color = Colors.white.withValues(alpha: 0.65);
        canvas.drawCircle(drawCenter, headR * 1.30, paint);
        paint.style = PaintingStyle.fill;
      }
      canvas.restore();
    }

    // Floating popups.
    for (final popup in fx.popups) {
      final scaleIn = min(1.0, popup.age * 7);
      final scale = 0.6 + 0.4 * scaleIn;
      final rise = popup.t * 2.4 * cell;
      final pos = Offset(popup.cx * cell, popup.cy * cell - rise);
      final alpha = popup.t < 0.7 ? 1.0 : (1 - popup.t) / 0.3;
      final tp = TextPainter(
        text: TextSpan(
          text: popup.text,
          style: TextStyle(
            fontSize: cell * 1.9 * scale,
            fontWeight: FontWeight.w900,
            color: popup.color.withValues(alpha: alpha.clamp(0.0, 1.0)),
            shadows: [
              Shadow(
                color: Colors.black.withValues(alpha: 0.55 * alpha),
                blurRadius: 4,
                offset: const Offset(0, 2),
              ),
            ],
          ),
        ),
        textDirection: TextDirection.ltr,
      )..layout();
      tp.paint(canvas, pos - Offset(tp.width / 2, tp.height / 2));
    }

    // Glossy sheen across the top of the arena.
    canvas.drawRect(Offset.zero & size, Paint()..shader = cache.sheenFor(size));

    // Capture flash.
    if (fx.flash > 0.005) {
      canvas.drawRect(
        Offset.zero & size,
        Paint()..color = Colors.white.withValues(alpha: fx.flash),
      );
    }

    // Chunky "GO!" pop as the spawn-in lands, gone inside a second.
    final goAge = fx.nowSec - fx.matchStartSec;
    if (goAge >= 0.30 && goAge < 1.10) {
      final gp = (goAge - 0.30) / 0.80;
      final popIn = gp < 0.22 ? _easeOutBack(gp / 0.22) : 1.0;
      final alpha = (gp > 0.68 ? (1 - gp) / 0.32 : 1.0).clamp(0.0, 1.0);
      final tp = TextPainter(
        text: TextSpan(
          text: 'GO!',
          style: TextStyle(
            fontSize: cell * 3.4 * popIn,
            fontWeight: FontWeight.w900,
            color: const Color(0xFFFFD93D).withValues(alpha: alpha),
            shadows: [
              Shadow(
                color: Colors.black.withValues(alpha: 0.45 * alpha),
                blurRadius: 6,
                offset: const Offset(0, 3),
              ),
            ],
          ),
        ),
        textDirection: TextDirection.ltr,
      )..layout();
      final c = Offset(size.width / 2, size.height / 2);
      tp.paint(canvas, c - Offset(tp.width / 2, tp.height / 2));
    }

    // Danger vignette: pulsing red edges while a bot closes in on
    // the player's exposed trail.
    if (fx.danger > 0.01) {
      final rect = Offset.zero & size;
      final vignette = Paint()
        ..shader = RadialGradient(
          radius: 0.78,
          colors: [
            Colors.transparent,
            Colors.transparent,
            const Color(0xFFFF2D40).withValues(alpha: 0.38 * fx.danger),
          ],
          stops: const [0.0, 0.62, 1.0],
        ).createShader(rect);
      canvas.drawRect(rect, vignette);
    }
  }

  /// The board's static layer: void bed plus every cell (neutral,
  /// territory, or rock). Recorded into the shared cache only when
  /// ownership changes; see [BoardRenderCache].
  ///
  /// Professional shading rules, all baked into the cached picture so
  /// the per-frame cost is zero: light comes from the top-left —
  /// territories get a pale gloss band across their top and a darker
  /// foot, a dark rim runs wherever two owners (or the void) meet,
  /// neutral ground carries a very subtle themed texture (dots, plus
  /// marks, waves or sparkles), and rocks are lit from above with a
  /// shadowed base.
  void _recordStatic(Canvas canvas, Size size) {
    final cell = size.width / TerritoryEngine.cols;
    // Void base: blocked cells sit on this dark bed, so arena silhouettes
    // (round edges, core, channels, rocks) read at a glance.
    final voidColor = Color.lerp(
      Color(engine.level.backgroundArgb),
      Colors.black,
      0.45,
    )!;
    canvas.drawRect(Offset.zero & size, Paint()..color = voidColor);

    final paint = Paint();
    final neutral = Color(engine.level.neutralArgb);
    // Territory rim segments, batched one Path per owner.
    final rims = <int, Path>{};
    // Playable cells: neutral ground, territory, or rock.
    for (var y = 0; y < TerritoryEngine.rows; y++) {
      for (var x = 0; x < TerritoryEngine.cols; x++) {
        final cellIndex = engine.idx(x, y);
        final rect = Rect.fromLTWH(x * cell, y * cell, cell + 0.5, cell + 0.5);
        if (engine.mask.isBlockedCell(cellIndex)) {
          // Rock / void cell: lit cap, mid tone, shadowed base, speck.
          paint.color = Color.lerp(voidColor, Colors.white, 0.13)!;
          canvas.drawRect(rect, paint);
          paint.color = Colors.white.withValues(alpha: 0.10);
          canvas.drawRect(
            Rect.fromLTWH(x * cell, y * cell, cell + 0.5, cell * 0.26),
            paint,
          );
          paint.color = Color.lerp(voidColor, Colors.black, 0.40)!;
          canvas.drawRect(
            Rect.fromLTWH(
              x * cell,
              y * cell + cell * 0.72,
              cell + 0.5,
              cell * 0.28 + 0.5,
            ),
            paint,
          );
          paint.color = Colors.white.withValues(alpha: 0.08);
          canvas.drawRect(
            Rect.fromLTWH(
              x * cell + cell * 0.28,
              y * cell + cell * 0.36,
              cell * 0.20,
              cell * 0.13,
            ),
            paint,
          );
          continue;
        }
        final owner = engine.owners[cellIndex];
        if (owner < 0) {
          paint.color = neutral;
          canvas.drawRect(rect, paint);
          _groundTexture(canvas, x, y, cell, neutral);
          continue;
        }
        final base = Color(engine.actors[owner].colorArgb);
        paint.color = base;
        canvas.drawRect(rect, paint);
        // Top-light gloss band and darker foot (light from top-left).
        paint.color = Color.lerp(base, Colors.white, 0.13)!;
        canvas.drawRect(
          Rect.fromLTWH(x * cell, y * cell, cell + 0.5, cell * 0.40),
          paint,
        );
        paint.color = Color.lerp(base, Colors.black, 0.10)!;
        canvas.drawRect(
          Rect.fromLTWH(
            x * cell,
            y * cell + cell * 0.80,
            cell + 0.5,
            cell * 0.20 + 0.5,
          ),
          paint,
        );
        // Rim where this territory meets a different owner, the
        // neutral ground or the void.
        final path = rims.putIfAbsent(owner, Path.new);
        if (x + 1 >= TerritoryEngine.cols ||
            engine.owners[engine.idx(x + 1, y)] != owner) {
          path.moveTo((x + 1) * cell, y * cell);
          path.lineTo((x + 1) * cell, (y + 1) * cell);
        }
        if (y + 1 >= TerritoryEngine.rows ||
            engine.owners[engine.idx(x, y + 1)] != owner) {
          path.moveTo(x * cell, (y + 1) * cell);
          path.lineTo((x + 1) * cell, (y + 1) * cell);
        }
      }
    }
    final rimWidth = max(1.1, cell * 0.07);
    for (final entry in rims.entries) {
      final base = Color(engine.actors[entry.key].colorArgb);
      paint
        ..style = PaintingStyle.stroke
        ..strokeWidth = rimWidth
        ..color = Color.lerp(base, Colors.black, 0.30)!.withValues(alpha: 0.5);
      canvas.drawPath(entry.value, paint);
    }
    paint.style = PaintingStyle.fill;
  }

  /// Very subtle themed texture on neutral ground, keyed by level:
  /// dot fields on Meadow/Candy/Sunset, plus marks on Desert, wave
  /// arcs on Ocean, sparkle dust on Galaxy. Recorded only into the
  /// cached static layer.
  void _groundTexture(Canvas canvas, int x, int y, double cell, Color neutral) {
    final paint = Paint();
    final cx = (x + 0.5) * cell;
    final cy = (y + 0.5) * cell;
    switch (engine.level.id) {
      case 4: // Ocean — tiny wave arcs in staggered rows.
        if (x % 3 == 0 && y % 2 == 0) {
          paint
            ..style = PaintingStyle.stroke
            ..strokeWidth = cell * 0.07
            ..strokeCap = StrokeCap.round
            ..color = Colors.white.withValues(alpha: 0.09);
          final wave = Path()
            ..moveTo(x * cell + cell * 0.18, cy + cell * 0.10)
            ..quadraticBezierTo(
              cx,
              y * cell + cell * 0.22,
              x * cell + cell * 0.82,
              cy + cell * 0.10,
            );
          canvas.drawPath(wave, paint);
          paint.style = PaintingStyle.fill;
        }
      case 3: // Desert — sparse plus marks.
        if ((x * 3 + y) % 5 == 0) {
          paint.color = Colors.black.withValues(alpha: 0.10);
          final s = cell * 0.15;
          canvas.drawRect(
            Rect.fromLTWH(cx - s, cy - cell * 0.045, s * 2, cell * 0.09),
            paint,
          );
          canvas.drawRect(
            Rect.fromLTWH(cx - cell * 0.045, cy - s, cell * 0.09, s * 2),
            paint,
          );
        }
      case 6: // Galaxy — sparse four-point sparkles.
        if ((x * 7 + y * 11) % 29 == 0) {
          paint.color = Colors.white.withValues(alpha: 0.13);
          final star = Path()
            ..moveTo(cx, cy - cell * 0.16)
            ..quadraticBezierTo(
              cx,
              cy,
              cx + cell * 0.16,
              cy,
            )
            ..quadraticBezierTo(
              cx,
              cy,
              cx,
              cy + cell * 0.16,
            )
            ..quadraticBezierTo(
              cx,
              cy,
              cx - cell * 0.16,
              cy,
            )
            ..quadraticBezierTo(
              cx,
              cy,
              cx,
              cy - cell * 0.16,
            )
            ..close();
          canvas.drawPath(star, paint);
        }
      case 2: // Candy — pale dots on the off-beat cells.
        if ((x + y) % 2 == 1) {
          paint.color = Colors.white.withValues(alpha: 0.10);
          canvas.drawCircle(Offset(cx, cy), cell * 0.08, paint);
        }
      case 5: // Sunset — pale dots.
        if ((x + y) % 2 == 0) {
          paint.color = Colors.white.withValues(alpha: 0.08);
          canvas.drawCircle(Offset(cx, cy), cell * 0.09, paint);
        }
      default: // Meadow — soft shadow dots.
        if ((x + y) % 2 == 0) {
          paint.color = Color.lerp(neutral, Colors.black, 0.16)!
              .withValues(alpha: 0.30);
          canvas.drawCircle(Offset(cx, cy), cell * 0.09, paint);
        }
    }
  }

  /// Draws the player's pre-rendered glossy owl sprite: the same
  /// contact shadow, banking, squash-and-stretch and expression
  /// timing as the vector owl, with the skin's hue retint and
  /// signature marking laid over the bake. Determined (boost) gets
  /// drawn brow lines and celebrate a pair of sparkles, since those
  /// two faces have no dedicated bake.
  void _drawOwlSprite(
    Canvas canvas,
    ui.Image img,
    Offset center,
    double r, {
    required OwlExpression expression,
    required double exprAge,
    required double bank,
    required bool boosting,
  }) {
    // Soft ground shadow.
    canvas.drawOval(
      Rect.fromCenter(
        center: center + Offset(0, r * 0.92),
        width: r * 1.55,
        height: r * 0.48,
      ),
      Paint()..color = Colors.black.withValues(alpha: 0.22),
    );

    final bounce = sin(t * pi);
    var wobble = 0.0;
    if (expression == OwlExpression.dizzy) {
      wobble = sin(exprAge * 16) * 0.10 * max(0.0, 1 - exprAge);
    }
    canvas.save();
    canvas.translate(center.dx, center.dy);
    canvas.rotate(bank + wobble);
    canvas.scale(
      (1 + 0.05 * bounce) * (boosting ? 1.04 : 1.0),
      (1 - 0.05 * bounce) * (boosting ? 0.96 : 1.0),
    );

    final h = r * 2.30;
    final w = h * img.width / img.height;
    final paint = Paint()..filterQuality = FilterQuality.medium;
    final tint = expression == OwlExpression.sad
        ? const ColorFilter.mode(Color(0x40202033), BlendMode.srcATop)
        : skinTintFilter(playerSkin);
    if (tint != null) paint.colorFilter = tint;
    canvas.drawImageRect(
      img,
      Rect.fromLTWH(0, 0, img.width.toDouble(), img.height.toDouble()),
      Rect.fromCenter(center: Offset(0, -r * 0.02), width: w, height: h),
      paint,
    );

    // The equipped skin's signature marking rides on the sprite.
    drawOwlSkinMark(canvas, Offset.zero, r * 0.98, playerSkin);

    const ink = Color(0xFF22333B);
    if (expression == OwlExpression.determined) {
      // Angled brows over the bake: the boost glare.
      final brow = Paint()
        ..color = ink
        ..strokeWidth = r * 0.075
        ..strokeCap = StrokeCap.round;
      canvas.drawLine(
        Offset(-r * 0.56, -r * 0.52),
        Offset(-r * 0.16, -r * 0.36),
        brow,
      );
      canvas.drawLine(
        Offset(r * 0.56, -r * 0.52),
        Offset(r * 0.16, -r * 0.36),
        brow,
      );
    }
    if (expression == OwlExpression.celebrate) {
      final sparkle = Paint()..color = const Color(0xFFFFD93D);
      canvas.drawPath(_spriteStar(Offset(-r * 0.85, -r * 0.38), r * 0.11), sparkle);
      canvas.drawPath(_spriteStar(Offset(r * 0.88, -r * 0.22), r * 0.09), sparkle);
    }
    canvas.restore();
  }

  /// Draws one bot's pre-rendered critter sprite with the same
  /// contact shadow, banking and squash as the vector blob; the bake
  /// is hue-rotated from its base hue to the bot's own territory hue
  /// so head, trail and territory stay one color. Frozen bots get
  /// X-eye overlays and hunters a brow glare.
  void _drawBotSprite(
    Canvas canvas,
    ui.Image img,
    Offset center,
    double r,
    Actor actor, {
    required int variant,
    required bool frozen,
    required bool hunting,
    required double bank,
  }) {
    // Soft ground shadow.
    canvas.drawOval(
      Rect.fromCenter(
        center: center + Offset(0, r * 0.82),
        width: r * 1.55,
        height: r * 0.5,
      ),
      Paint()..color = Colors.black.withValues(alpha: 0.22),
    );

    final bounce = sin(t * pi);
    canvas.save();
    canvas.translate(center.dx, center.dy);
    canvas.rotate(bank);
    canvas.scale(1 + 0.05 * bounce, 1 - 0.05 * bounce);
    final h = r * 2.20;
    final w = h * img.width / img.height;
    // Base hue of each critter bake, indexed by creature variant:
    // 0 blue horns, 1 green antenna, 2 teal cat, 3 purple cyclops,
    // 4 pink bear.
    const botBaseHues = [208.0, 130.0, 175.0, 265.0, 335.0];
    final targetHue = HSVColor.fromColor(Color(actor.colorArgb)).hue;
    var delta = (targetHue - botBaseHues[variant]) % 360.0;
    if (delta > 180.0) delta -= 360.0;
    final botPaint = Paint()..filterQuality = FilterQuality.medium;
    if (delta.abs() >= 6.0) botPaint.colorFilter = hueRotateFilter(delta);
    canvas.drawImageRect(
      img,
      Rect.fromLTWH(0, 0, img.width.toDouble(), img.height.toDouble()),
      Rect.fromCenter(center: Offset(0, -r * 0.02), width: w, height: h),
      botPaint,
    );

    const ink = Color(0xFF22333B);
    if (frozen) {
      // Dizzy X eyes overlaid on the bake while frozen solid.
      final xPaint = Paint()
        ..color = ink
        ..strokeWidth = r * 0.09
        ..strokeCap = StrokeCap.round;
      for (final side in [-1, 1]) {
        final e = Offset(side * r * 0.30, -r * 0.08);
        final s = r * 0.15;
        canvas.drawLine(e + Offset(-s, -s), e + Offset(s, s), xPaint);
        canvas.drawLine(e + Offset(-s, s), e + Offset(s, -s), xPaint);
      }
    } else if (hunting) {
      // Angled brows: this one is coming for your trail.
      final brow = Paint()
        ..color = ink
        ..strokeWidth = r * 0.08
        ..strokeCap = StrokeCap.round;
      canvas.drawLine(
        Offset(-r * 0.50, -r * 0.42),
        Offset(-r * 0.13, -r * 0.28),
        brow,
      );
      canvas.drawLine(
        Offset(r * 0.50, -r * 0.42),
        Offset(r * 0.13, -r * 0.28),
        brow,
      );
    }
    canvas.restore();
  }

  /// Small four-point sparkle centered at [center] with radius [r].
  Path _spriteStar(Offset center, double r) {
    return Path()
      ..moveTo(center.dx, center.dy - r)
      ..quadraticBezierTo(center.dx, center.dy, center.dx + r, center.dy)
      ..quadraticBezierTo(center.dx, center.dy, center.dx, center.dy + r)
      ..quadraticBezierTo(center.dx, center.dy, center.dx - r, center.dy)
      ..quadraticBezierTo(center.dx, center.dy, center.dx, center.dy - r)
      ..close();
  }

  /// Draws one bot: a glossy blob in its own color, wearing one of
  /// five rotating creature features (tiny horns, antenna, cat ears,
  /// a single cyclops eye, bear ears) so every rival reads as its own
  /// little character — simpler than the player's owl by design.
  /// Frozen bots get X eyes; a hunting bot glares under angled brows.
  void _blob(
    Canvas canvas,
    Offset center,
    double r,
    Actor actor, {
    required int variant,
    required bool frozen,
    required bool hunting,
    required double bank,
  }) {
    final color = Color(actor.colorArgb);
    final darker = Color.lerp(color, Colors.black, 0.22)!;

    // Soft ground shadow.
    canvas.drawOval(
      Rect.fromCenter(
        center: center + Offset(0, r * 0.82),
        width: r * 1.55,
        height: r * 0.5,
      ),
      Paint()..color = Colors.black.withValues(alpha: 0.22),
    );

    // Gentle squash-and-stretch bounce plus a roll into turns.
    final bounce = sin(t * pi);
    canvas.save();
    canvas.translate(center.dx, center.dy);
    canvas.rotate(bank);
    canvas.scale(1 + 0.05 * bounce, 1 - 0.05 * bounce);
    canvas.translate(-center.dx, -center.dy);

    // Creature feature, tucked behind the body.
    switch (variant) {
      case 0: // Tiny horns.
        for (final side in [-1, 1]) {
          final horn = Path()
            ..moveTo(center.dx + side * r * 0.28, center.dy - r * 0.76)
            ..lineTo(center.dx + side * r * 0.88, center.dy - r * 1.16)
            ..lineTo(center.dx + side * r * 0.68, center.dy - r * 0.56)
            ..close();
          canvas.drawPath(horn, Paint()..color = darker);
        }
      case 1: // Antenna with a bobble.
        canvas.drawLine(
          center + Offset(0, -r * 0.80),
          center + Offset(0, -r * 1.22),
          Paint()
            ..color = darker
            ..strokeWidth = r * 0.09
            ..strokeCap = StrokeCap.round,
        );
        canvas.drawCircle(
          center + Offset(0, -r * 1.32),
          r * 0.17,
          Paint()..color = Color.lerp(color, Colors.white, 0.5)!,
        );
        canvas.drawCircle(
          center + Offset(-r * 0.05, -r * 1.38),
          r * 0.05,
          Paint()..color = Colors.white.withValues(alpha: 0.8),
        );
      case 2: // Cat ears.
        for (final side in [-1, 1]) {
          final ear = Path()
            ..moveTo(center.dx + side * r * 0.14, center.dy - r * 0.78)
            ..lineTo(center.dx + side * r * 0.56, center.dy - r * 1.22)
            ..lineTo(center.dx + side * r * 0.74, center.dy - r * 0.60)
            ..close();
          canvas.drawPath(ear, Paint()..color = color);
          final inner = Path()
            ..moveTo(center.dx + side * r * 0.32, center.dy - r * 0.80)
            ..lineTo(center.dx + side * r * 0.54, center.dy - r * 1.06)
            ..lineTo(center.dx + side * r * 0.64, center.dy - r * 0.68)
            ..close();
          canvas.drawPath(
            inner,
            Paint()..color = Color.lerp(color, Colors.white, 0.45)!,
          );
        }
      case 4: // Round bear ears.
        for (final side in [-1, 1]) {
          canvas.drawCircle(
            center + Offset(side * r * 0.66, -r * 0.68),
            r * 0.30,
            Paint()..color = darker,
          );
          canvas.drawCircle(
            center + Offset(side * r * 0.66, -r * 0.68),
            r * 0.16,
            Paint()..color = Color.lerp(color, Colors.white, 0.35)!,
          );
        }
      default: // 3 = cyclops: no headgear, the eye does the talking.
        break;
    }

    // Bottom shade for a plump, premium look.
    canvas.drawCircle(
      center + Offset(0, r * 0.16),
      r * 0.94,
      Paint()..color = Color.lerp(color, Colors.black, 0.16)!,
    );
    // Main body.
    canvas.drawCircle(center, r * 0.94, Paint()..color = color);

    // Glossy highlight (light from top-left, same as the owl).
    canvas.drawOval(
      Rect.fromCenter(
        center: center + Offset(-r * 0.36, -r * 0.44),
        width: r * 0.62,
        height: r * 0.4,
      ),
      Paint()..color = Colors.white.withValues(alpha: 0.38),
    );
    canvas.drawCircle(
      center + Offset(-r * 0.52, -r * 0.58),
      r * 0.09,
      Paint()..color = Colors.white.withValues(alpha: 0.7),
    );

    const ink = Color(0xFF22333B);
    if (frozen) {
      // Dizzy X eyes while frozen solid.
      final xPaint = Paint()
        ..color = ink
        ..strokeWidth = r * 0.09
        ..strokeCap = StrokeCap.round;
      for (final side in [-1, 1]) {
        final e = center + Offset(side * r * 0.34, -r * 0.06);
        final s = r * 0.17;
        canvas.drawLine(e + Offset(-s, -s), e + Offset(s, s), xPaint);
        canvas.drawLine(e + Offset(-s, s), e + Offset(s, -s), xPaint);
      }
    } else if (variant == 3) {
      // Cyclops: one big eye, pupil tracking the heading.
      final look = Offset(actor.dx.toDouble(), actor.dy.toDouble()) * r * 0.13;
      final eye = center + Offset(0, -r * 0.05) + look * 0.6;
      canvas.drawCircle(eye, r * 0.40, Paint()..color = Colors.white);
      canvas.drawCircle(eye + look, r * 0.20, Paint()..color = ink);
      canvas.drawCircle(
        eye + look + Offset(-r * 0.06, -r * 0.06),
        r * 0.07,
        Paint()..color = Colors.white,
      );
    } else {
      _face(canvas, center, r * 0.94, actor.dx, actor.dy, actor.isPlayer);
      if (hunting) {
        // Angled brows: this one is coming for your trail.
        final brow = Paint()
          ..color = ink
          ..strokeWidth = r * 0.08
          ..strokeCap = StrokeCap.round;
        canvas.drawLine(
          center + Offset(-r * 0.54, -r * 0.48),
          center + Offset(-r * 0.14, -r * 0.32),
          brow,
        );
        canvas.drawLine(
          center + Offset(r * 0.54, -r * 0.48),
          center + Offset(r * 0.14, -r * 0.32),
          brow,
        );
      }
    }
    canvas.restore();
  }

  void _face(
    Canvas canvas,
    Offset center,
    double r,
    int dx,
    int dy,
    bool isPlayer,
  ) {
    final look = Offset(dx.toDouble(), dy.toDouble()) * r * 0.13;
    const ink = Color(0xFF22333B);
    for (final side in [-1, 1]) {
      final eye = center + Offset(side * r * 0.34, -r * 0.06) + look;
      canvas.drawCircle(eye, r * 0.27, Paint()..color = Colors.white);
      canvas.drawCircle(eye + look, r * 0.14, Paint()..color = ink);
      canvas.drawCircle(
        eye + look + Offset(-r * 0.045, -r * 0.045),
        r * 0.05,
        Paint()..color = Colors.white,
      );
    }
    if (isPlayer) {
      final smile = Path()
        ..moveTo(center.dx - r * 0.2, center.dy + r * 0.28)
        ..quadraticBezierTo(
          center.dx,
          center.dy + r * 0.44,
          center.dx + r * 0.2,
          center.dy + r * 0.28,
        );
      canvas.drawPath(
        smile,
        Paint()
          ..color = ink
          ..style = PaintingStyle.stroke
          ..strokeWidth = r * 0.07
          ..strokeCap = StrokeCap.round,
      );
    }
  }

  @override
  bool shouldRepaint(covariant BoardPainter oldDelegate) => true;
}

/// Small corner minimap: territory micro-cells + actor dots.
class MinimapPainter extends CustomPainter {
  final TerritoryEngine engine;

  /// Live frame clock used as the repaint signal (same listenable the
  /// board painter uses).
  final ValueListenable<double> interp;

  /// Shared cross-frame caches (the minimap's cell layer is cached the
  /// same way as the main board's).
  final BoardRenderCache cache;

  MinimapPainter(this.engine, {required this.interp, required this.cache})
    : super(repaint: interp);

  @override
  void paint(Canvas canvas, Size size) {
    final cw = size.width / TerritoryEngine.cols;
    final ch = size.height / TerritoryEngine.rows;
    // Static cells (background, rocks, territory): cached picture.
    canvas.drawPicture(cache.minimapPictureFor(engine, size, _recordStatic));
    // Power-up pickups read as small accent dots.
    for (final pickup in engine.pickups) {
      final pos = Offset((pickup.x + 0.5) * cw, (pickup.y + 0.5) * ch);
      canvas.drawCircle(pos, cw * 1.5, Paint()..color = Colors.white);
      canvas.drawCircle(
        pos,
        cw * 1.0,
        Paint()..color = Color(pickup.kind.colorArgb),
      );
    }
    for (final actor in engine.actors) {
      if (!actor.alive) continue;
      final pos = Offset((actor.x + 0.5) * cw, (actor.y + 0.5) * ch);
      final dotR = actor.isPlayer ? cw * 2.1 : cw * 1.6;
      canvas.drawCircle(
        pos,
        dotR,
        Paint()
          ..color = Colors.white
          ..style = PaintingStyle.stroke
          ..strokeWidth = actor.isPlayer ? 1.6 : 1.1,
      );
      canvas.drawCircle(
        pos,
        dotR - 0.8,
        Paint()..color = Color(actor.colorArgb),
      );
    }
  }

  /// The minimap's static layer: dark bed, rock cells, owned cells.
  void _recordStatic(Canvas canvas, Size size) {
    final cw = size.width / TerritoryEngine.cols;
    final ch = size.height / TerritoryEngine.rows;
    canvas.drawRect(
      Offset.zero & size,
      Paint()..color = Color(engine.level.neutralArgb).withValues(alpha: 0.35),
    );
    final paint = Paint();
    for (var y = 0; y < TerritoryEngine.rows; y++) {
      for (var x = 0; x < TerritoryEngine.cols; x++) {
        final cellIndex = engine.idx(x, y);
        if (engine.mask.isBlockedCell(cellIndex)) {
          paint.color = Colors.black.withValues(alpha: 0.55);
          canvas.drawRect(
            Rect.fromLTWH(x * cw, y * ch, cw + 0.4, ch + 0.4),
            paint,
          );
          continue;
        }
        final owner = engine.owners[cellIndex];
        if (owner < 0) continue;
        paint.color = Color(engine.actors[owner].colorArgb);
        canvas.drawRect(
          Rect.fromLTWH(x * cw, y * ch, cw + 0.4, ch + 0.4),
          paint,
        );
      }
    }
  }

  @override
  bool shouldRepaint(covariant MinimapPainter oldDelegate) => true;
}
