import 'package:flutter/material.dart';

import '../game/territory_engine.dart';

class BoardPainter extends CustomPainter {
  final TerritoryEngine engine;

  /// Interpolation factor 0..1 between each actor's previous and current cell.
  final double t;

  BoardPainter(this.engine, this.t);

  @override
  void paint(Canvas canvas, Size size) {
    final cell = size.width / TerritoryEngine.cols;
    final bg = Paint()..color = Color(engine.level.neutralArgb);
    canvas.drawRect(Offset.zero & size, bg);

    final paint = Paint();
    // Territory cells.
    for (var y = 0; y < TerritoryEngine.rows; y++) {
      for (var x = 0; x < TerritoryEngine.cols; x++) {
        final owner = engine.owners[engine.idx(x, y)];
        if (owner < 0) continue;
        paint.color = Color(engine.actors[owner].colorArgb);
        canvas.drawRect(
          Rect.fromLTWH(x * cell, y * cell, cell + 0.5, cell + 0.5),
          paint,
        );
      }
    }

    // Trails (brighter than territory).
    for (final actor in engine.actors) {
      if (actor.trail.isEmpty) continue;
        paint.color = Color.lerp(Color(actor.colorArgb), Colors.white, 0.35)!;
      for (final c in actor.trailSet) {
        final x = c % TerritoryEngine.cols;
        final y = c ~/ TerritoryEngine.cols;
        canvas.drawRRect(
          RRect.fromRectAndRadius(
            Rect.fromLTWH(
              x * cell + cell * 0.12,
              y * cell + cell * 0.12,
              cell * 0.76,
              cell * 0.76,
            ),
            Radius.circular(cell * 0.2),
          ),
          paint,
        );
      }
    }

    // Heads.
    for (final actor in engine.actors) {
      if (!actor.alive) continue;
      final fx = actor.prevX + (actor.x - actor.prevX) * t;
      final fy = actor.prevY + (actor.y - actor.prevY) * t;
      final center = Offset((fx + 0.5) * cell, (fy + 0.5) * cell);
      final r = cell * 0.85;
      final color = Color(actor.colorArgb);

      canvas.drawCircle(
        center + const Offset(0, 1.5),
        r,
        Paint()..color = Colors.black.withValues(alpha: 0.15),
      );

      if (actor.isPlayer) {
        // Original teal paint-drop blob: round body + little droplet tip.
        canvas.drawCircle(center, r, Paint()..color = color);
        canvas.drawCircle(
          center + Offset(0, -r * 0.95),
          r * 0.38,
          Paint()..color = color,
        );
        _face(canvas, center, r, actor.dx, actor.dy);
      } else if (actor.id.isEven) {
        canvas.drawCircle(center, r * 0.92, Paint()..color = color);
        _face(canvas, center, r * 0.92, actor.dx, actor.dy);
      } else {
        canvas.drawRRect(
          RRect.fromRectAndRadius(
            Rect.fromCenter(center: center, width: r * 1.7, height: r * 1.7),
            Radius.circular(r * 0.45),
          ),
          Paint()..color = color,
        );
        _face(canvas, center, r * 0.85, actor.dx, actor.dy);
      }
    }
  }

  void _face(Canvas canvas, Offset center, double r, int dx, int dy) {
    final look = Offset(dx.toDouble(), dy.toDouble()) * r * 0.12;
    for (final side in [-1, 1]) {
      final eye = center + Offset(side * r * 0.34, -r * 0.08) + look;
      canvas.drawCircle(eye, r * 0.26, Paint()..color = Colors.white);
      canvas.drawCircle(eye + look, r * 0.13, Paint()..color = const Color(0xFF22333B));
    }
  }

  @override
  bool shouldRepaint(covariant BoardPainter oldDelegate) => true;
}
