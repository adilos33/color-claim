import 'dart:math';
import 'dart:ui' as ui;

import 'package:flutter/material.dart';

import '../game/skins.dart';

/// The player owl's moment-to-moment face. The board painter derives
/// one of these per frame from FX timestamps and live game state (no
/// timers anywhere): [neutral] shows the skin's own personality face,
/// the rest are short-lived reactions.
enum OwlExpression {
  neutral,
  happy, // capture grin: arc eyes + open beak smile
  scared, // a hunter is closing in: wide eyes, small pupils
  dizzy, // just lost a life: X eyes + wobble
  determined, // Speed boost: angled brows, forward stare
  celebrate, // win: closed happy eyes, beak wide open
  sad, // loss: droopy eyes, small frown
}

/// Draws one original owl character centered at [center], with body
/// radius [r] (half the character's width, in canvas pixels).
///
/// Our own code-drawn owl: a plump round body with two ear tufts, a
/// cream face panel with big eye discs whose pupils aim along
/// [dx]/[dy], a small orange beak, a lighter belly, two side wings
/// and one signature marking per skin.
///
/// Cinematic motion inputs, all computed by the caller from the
/// continuous step-time — this painter keeps no clocks:
/// - [phase] (0..1 across one step) drives the squash-and-stretch.
/// - [bank] rolls the body into turns (radians).
/// - [wingFlap] swings the wings (radians, + = raised); the caller
///   paces it — lazy glide, working flap, frantic on turns/boosts.
/// - [boosting] pitches the body a touch forward.
/// - [expression] picks the face; [exprPop] (0..1) settles a fresh
///   expression with a quick eye pop instead of a hard swap, and
///   [exprAge] (seconds in the expression) drives the dizzy wobble.
void drawSkinCharacter(
  Canvas canvas,
  Offset center,
  double r,
  SkinDef skin, {
  int dx = 0,
  int dy = 0,
  double phase = 0,
  OwlExpression expression = OwlExpression.neutral,
  double exprPop = 1,
  double exprAge = 0,
  double bank = 0,
  double wingFlap = 0,
  bool boosting = false,
}) {
  final color = Color(skin.colorArgb);
  final accent = Color(skin.accentArgb);
  final darker = Color.lerp(color, Colors.black, 0.16)!;
  const beakColor = Color(0xFFFF9F1A);
  const ink = Color(0xFF22333B);

  // Soft ground shadow.
  canvas.drawOval(
    Rect.fromCenter(
      center: center + Offset(0, r * 0.92),
      width: r * 1.55,
      height: r * 0.48,
    ),
    Paint()..color = Colors.black.withValues(alpha: 0.22),
  );

  // Squash-and-stretch bounce tied to the step phase, a roll into
  // turns, and a decaying wobble while dizzy. A Speed boost pitches
  // the body slightly forward (longer, lower silhouette).
  final bounce = sin(phase * pi);
  var wobble = 0.0;
  if (expression == OwlExpression.dizzy) {
    wobble = sin(exprAge * 16) * 0.10 * max(0.0, 1 - exprAge);
  }
  canvas.save();
  canvas.translate(center.dx, center.dy);
  canvas.rotate(bank + wobble);
  canvas.scale(
    (1 + 0.05 * bounce) * (boosting ? 1.04 : 1.0),
    (1 - 0.05 * bounce) * (boosting ? 0.96 : 1.0),
  );
  canvas.translate(-center.dx, -center.dy);

  // Ear tufts, tucked behind the body: two pointed plumes in the
  // darker shade so the silhouette reads "owl" at a glance. They
  // prick up when scared and droop when sad.
  final tuftLift = switch (expression) {
    OwlExpression.scared => 0.14,
    OwlExpression.celebrate => 0.06,
    OwlExpression.sad => -0.10,
    _ => 0.0,
  };
  final tuftPaint = Paint()..color = darker;
  for (final side in [-1, 1]) {
    final tuft = Path()
      ..moveTo(center.dx + side * r * 0.30, center.dy - r * 0.70)
      ..quadraticBezierTo(
        center.dx + side * r * 0.88,
        center.dy - r * 0.86,
        center.dx + side * r * 0.94,
        center.dy - r * (1.24 + tuftLift),
      )
      ..quadraticBezierTo(
        center.dx + side * r * 0.62,
        center.dy - r * 0.94,
        center.dx + side * r * 0.66,
        center.dy - r * 0.55,
      )
      ..close();
    canvas.drawPath(tuft, tuftPaint);
  }

  // Side wings, behind the body: rounded feathers that swing with
  // [wingFlap] around the shoulder. Darker rim, lighter inner vane.
  for (final side in [-1, 1]) {
    canvas.save();
    canvas.translate(center.dx + side * r * 0.78, center.dy + r * 0.04);
    canvas.rotate(side * (0.35 + wingFlap));
    canvas.drawOval(
      Rect.fromCenter(
        center: Offset(side * r * 0.30, 0),
        width: r * 0.66,
        height: r * 0.32,
      ),
      Paint()..color = darker,
    );
    canvas.drawOval(
      Rect.fromCenter(
        center: Offset(side * r * 0.26, -r * 0.04),
        width: r * 0.44,
        height: r * 0.20,
      ),
      Paint()..color = Color.lerp(color, Colors.white, 0.18)!,
    );
    canvas.restore();
  }

  // Plump body: darker base, saturated top.
  canvas.drawCircle(center + Offset(0, r * 0.15), r * 0.94, Paint()..color = darker);
  canvas.drawCircle(center, r * 0.94, Paint()..color = color);

  // Tiny orange feet peeking out at the bottom.
  final footPaint = Paint()..color = beakColor;
  for (final side in [-1, 1]) {
    canvas.drawOval(
      Rect.fromCenter(
        center: center + Offset(side * r * 0.34, r * 0.92),
        width: r * 0.36,
        height: r * 0.17,
      ),
      footPaint,
    );
  }

  // Lighter belly patch.
  canvas.drawOval(
    Rect.fromCenter(
      center: center + Offset(0, r * 0.42),
      width: r * 1.00,
      height: r * 0.74,
    ),
    Paint()..color = Color.lerp(color, Colors.white, 0.55)!.withValues(alpha: 0.9),
  );

  // Cream face panel, wider than tall — the classic owl mask.
  const faceCream = Color(0xFFFFF4DE);
  canvas.drawOval(
    Rect.fromCenter(
      center: center + Offset(0, -r * 0.12),
      width: r * 1.54,
      height: r * 1.26,
    ),
    Paint()..color = faceCream,
  );

  _owlFace(
    canvas,
    center,
    r,
    skin,
    ink,
    beakColor,
    dx: dx,
    dy: dy,
    expression: expression,
    exprPop: exprPop,
  );
  _owlMark(canvas, center, r, skin, accent, color);
  // The Flame Owl's tuft and the Leaf Owl's leaf ride on top of
  // everything, drawn last so nothing covers them.
  _owlCrest(canvas, center, r, skin, accent, darker);

  // Glossy highlight on the body's left shoulder, clear of the
  // face panel, plus a tiny sparkle dot.
  canvas.drawOval(
    Rect.fromCenter(
      center: center + Offset(-r * 0.70, -r * 0.42),
      width: r * 0.34,
      height: r * 0.22,
    ),
    Paint()..color = Colors.white.withValues(alpha: 0.30),
  );
  canvas.drawCircle(
    center + Offset(-r * 0.80, -r * 0.60),
    r * 0.05,
    Paint()..color = Colors.white.withValues(alpha: 0.65),
  );

  canvas.restore();
}

/// The owl's face: eye discs (or closed arcs / X eyes), the orange
/// beak and a small mouth. [expression] overrides the skin's
/// personality face; [exprPop] scales the eyes briefly after every
/// expression switch so faces never swap mid-frame.
void _owlFace(
  Canvas canvas,
  Offset center,
  double r,
  SkinDef skin,
  Color ink,
  Color beakColor, {
  required int dx,
  required int dy,
  required OwlExpression expression,
  required double exprPop,
}) {
  final look = Offset(dx.toDouble(), dy.toDouble()) * r * 0.10;
  final ringColor = Color.lerp(Color(skin.colorArgb), Colors.black, 0.30)!;
  // Quick settle pop: eyes start at 80% and ease out to full.
  final popT = 1 - pow(1 - exprPop, 2).toDouble();
  final eyeScale = 0.8 + 0.2 * popT;

  void eyeDisc(int side, {double discScale = 1, double pupilScale = 1, Offset? stare}) {
    final eye = center + Offset(side * r * 0.335, -r * 0.14) + look * 0.6;
    final discR = r * 0.30 * discScale * eyeScale;
    canvas.drawCircle(eye, discR, Paint()..color = Colors.white);
    canvas.drawCircle(
      eye,
      discR,
      Paint()
        ..color = ringColor
        ..style = PaintingStyle.stroke
        ..strokeWidth = r * 0.045,
    );
    final pupilLift = skin.face == FaceStyle.happy && expression == OwlExpression.neutral
        ? Offset(0, -r * 0.03)
        : Offset.zero;
    final pupil = eye + (stare ?? look) + pupilLift;
    canvas.drawCircle(pupil, r * 0.145 * pupilScale * eyeScale, Paint()..color = ink);
    canvas.drawCircle(
      pupil + Offset(-r * 0.05, -r * 0.05),
      r * 0.05,
      Paint()..color = Colors.white,
    );
  }

  void arcEye(int side, {required bool droopy}) {
    final c = center + Offset(side * r * 0.335, -r * 0.10) + look * 0.6;
    final w = r * 0.21 * eyeScale;
    final path = Path()
      ..moveTo(c.dx - w, c.dy)
      ..quadraticBezierTo(
        c.dx,
        c.dy + (droopy ? r * 0.15 : -r * 0.22) * eyeScale,
        c.dx + w,
        c.dy,
      );
    canvas.drawPath(
      path,
      Paint()
        ..color = ink
        ..style = PaintingStyle.stroke
        ..strokeWidth = r * 0.075
        ..strokeCap = StrokeCap.round,
    );
  }

  void xEye(int side) {
    final e = center + Offset(side * r * 0.335, -r * 0.12);
    final s = r * 0.16 * eyeScale;
    final xPaint = Paint()
      ..color = ink
      ..strokeWidth = r * 0.085
      ..strokeCap = StrokeCap.round;
    canvas.drawLine(e + Offset(-s, -s), e + Offset(s, s), xPaint);
    canvas.drawLine(e + Offset(-s, s), e + Offset(s, -s), xPaint);
  }

  void beak({bool open = false}) {
    if (open) {
      // Upper beak tipped up, lower beak dropped, warm mouth showing.
      final upper = Path()
        ..moveTo(center.dx - r * 0.15, center.dy + r * 0.02)
        ..lineTo(center.dx + r * 0.15, center.dy + r * 0.02)
        ..lineTo(center.dx, center.dy - r * 0.10)
        ..close();
      canvas.drawPath(upper, Paint()..color = beakColor);
      canvas.drawOval(
        Rect.fromCenter(
          center: center + Offset(0, r * 0.12),
          width: r * 0.22,
          height: r * 0.16,
        ),
        Paint()..color = const Color(0xFF7A2E1D),
      );
      final lower = Path()
        ..moveTo(center.dx - r * 0.11, center.dy + r * 0.16)
        ..lineTo(center.dx + r * 0.11, center.dy + r * 0.16)
        ..lineTo(center.dx, center.dy + r * 0.28)
        ..close();
      canvas.drawPath(lower, Paint()..color = beakColor);
      return;
    }
    final tri = Path()
      ..moveTo(center.dx - r * 0.14, center.dy - r * 0.01)
      ..lineTo(center.dx + r * 0.14, center.dy - r * 0.01)
      ..lineTo(center.dx, center.dy + r * 0.21)
      ..close();
    canvas.drawPath(tri, Paint()..color = beakColor);
    canvas.drawPath(
      tri,
      Paint()
        ..color = const Color(0xFFE07B00)
        ..style = PaintingStyle.stroke
        ..strokeWidth = r * 0.03
        ..strokeJoin = StrokeJoin.round,
    );
  }

  final mouthStroke = Paint()
    ..color = ink
    ..style = PaintingStyle.stroke
    ..strokeWidth = r * 0.07
    ..strokeCap = StrokeCap.round;

  switch (expression) {
    case OwlExpression.happy:
      arcEye(-1, droopy: false);
      arcEye(1, droopy: false);
      beak(open: true);
    case OwlExpression.celebrate:
      arcEye(-1, droopy: false);
      arcEye(1, droopy: false);
      beak(open: true);
      // Cheer sparkles beside the face.
      final sparkle = Paint()..color = const Color(0xFFFFD93D);
      canvas.drawPath(
        _starPath(center + Offset(-r * 0.78, -r * 0.34), r * 0.10),
        sparkle,
      );
      canvas.drawPath(
        _starPath(center + Offset(r * 0.80, -r * 0.20), r * 0.08),
        sparkle,
      );
    case OwlExpression.scared:
      // Staring straight ahead: wide discs, pin pupils, tiny o-beak.
      eyeDisc(-1, discScale: 1.15, pupilScale: 0.6, stare: Offset.zero);
      eyeDisc(1, discScale: 1.15, pupilScale: 0.6, stare: Offset.zero);
      canvas.drawCircle(
        Offset(center.dx, center.dy + r * 0.14),
        r * 0.075,
        Paint()
          ..color = ink
          ..style = PaintingStyle.stroke
          ..strokeWidth = r * 0.055,
      );
    case OwlExpression.dizzy:
      xEye(-1);
      xEye(1);
      beak();
      // Wobbly little mouth line.
      final wob = Path()
        ..moveTo(center.dx - r * 0.18, center.dy + r * 0.32);
      for (var i = 1; i <= 4; i++) {
        wob.lineTo(
          center.dx - r * 0.18 + i * r * 0.09,
          center.dy + r * 0.32 + (i.isOdd ? -r * 0.035 : r * 0.035),
        );
      }
      canvas.drawPath(wob, mouthStroke);
    case OwlExpression.determined:
      eyeDisc(-1, stare: look * 0.5);
      eyeDisc(1, stare: look * 0.5);
      final brow = Paint()
        ..color = ink
        ..strokeWidth = r * 0.075
        ..strokeCap = StrokeCap.round;
      canvas.drawLine(
        center + Offset(-r * 0.56, -r * 0.52),
        center + Offset(-r * 0.16, -r * 0.36),
        brow,
      );
      canvas.drawLine(
        center + Offset(r * 0.56, -r * 0.52),
        center + Offset(r * 0.16, -r * 0.36),
        brow,
      );
      beak();
    case OwlExpression.sad:
      arcEye(-1, droopy: true);
      arcEye(1, droopy: true);
      beak();
      final frown = Path()
        ..moveTo(center.dx - r * 0.18, center.dy + r * 0.42)
        ..quadraticBezierTo(
          center.dx,
          center.dy + r * 0.30,
          center.dx + r * 0.18,
          center.dy + r * 0.42,
        );
      canvas.drawPath(frown, mouthStroke);
    case OwlExpression.neutral:
      // The skin's own personality face.
      switch (skin.face) {
        case FaceStyle.smile:
        case FaceStyle.grin:
        case FaceStyle.happy:
          eyeDisc(-1);
          eyeDisc(1);
        case FaceStyle.wink:
          eyeDisc(-1);
          arcEye(1, droopy: false);
        case FaceStyle.sleepy:
          arcEye(-1, droopy: true);
          arcEye(1, droopy: true);
      }
      beak();
      switch (skin.face) {
        case FaceStyle.grin:
        case FaceStyle.happy:
          final grin = Path()
            ..moveTo(center.dx - r * 0.21, center.dy + r * 0.27)
            ..quadraticBezierTo(
              center.dx,
              center.dy + r * 0.52,
              center.dx + r * 0.21,
              center.dy + r * 0.27,
            )
            ..close();
          canvas.drawPath(grin, Paint()..color = ink);
        case FaceStyle.sleepy:
          canvas.drawCircle(
            Offset(center.dx, center.dy + r * 0.34),
            r * 0.085,
            mouthStroke,
          );
        case FaceStyle.smile:
        case FaceStyle.wink:
          final smile = Path()
            ..moveTo(center.dx - r * 0.19, center.dy + r * 0.27)
            ..quadraticBezierTo(
              center.dx,
              center.dy + r * 0.42,
              center.dx + r * 0.19,
              center.dy + r * 0.27,
            );
          canvas.drawPath(smile, mouthStroke);
      }
  }
}

/// Forehead charms and belly motifs — one small signature marking
/// per owl, in its accent color.
void _owlMark(
  Canvas canvas,
  Offset center,
  double r,
  SkinDef skin,
  Color accent,
  Color bodyColor,
) {
  final forehead = center + Offset(0, -r * 0.86);
  switch (skin.mark) {
    case OwlMark.none:
      break;
    case OwlMark.wave:
      // Three tiny wave strokes across the belly.
      final wave = Paint()
        ..color = Color.lerp(accent, Colors.black, 0.25)!.withValues(alpha: 0.8)
        ..style = PaintingStyle.stroke
        ..strokeWidth = r * 0.05
        ..strokeCap = StrokeCap.round;
      for (var i = 0; i < 3; i++) {
        final y = center.dy + r * (0.36 + 0.14 * i);
        final wavePath = Path()
          ..moveTo(center.dx - r * 0.26, y)
          ..quadraticBezierTo(
            center.dx - r * 0.13,
            y - r * 0.09,
            center.dx,
            y,
          )
          ..quadraticBezierTo(
            center.dx + r * 0.13,
            y + r * 0.09,
            center.dx + r * 0.26,
            y,
          );
        canvas.drawPath(wavePath, wave);
      }
    case OwlMark.sun:
      // A mini sun beaming on the forehead.
      final sunPaint = Paint()..color = accent;
      for (var i = 0; i < 6; i++) {
        final a = i * pi / 3 + 0.26;
        final from = forehead + Offset(cos(a), sin(a)) * r * 0.16;
        final to = forehead + Offset(cos(a), sin(a)) * r * 0.24;
        canvas.drawLine(
          from,
          to,
          Paint()
            ..color = accent
            ..strokeWidth = r * 0.045
            ..strokeCap = StrokeCap.round,
        );
      }
      canvas.drawCircle(forehead, r * 0.115, sunPaint);
    case OwlMark.crescent:
      // Golden crescent carved out of the forehead.
      canvas.drawCircle(forehead, r * 0.155, Paint()..color = accent);
      canvas.drawCircle(
        forehead + Offset(r * 0.07, -r * 0.04),
        r * 0.125,
        Paint()..color = bodyColor,
      );
      // Two sleepy stars keep the Moon Owl company on its cheek.
      final starPaint = Paint()..color = accent;
      canvas.drawPath(
        _starPath(center + Offset(r * 0.55, r * 0.36), r * 0.11),
        starPaint,
      );
      canvas.drawPath(
        _starPath(center + Offset(r * 0.70, r * 0.10), r * 0.075),
        starPaint,
      );
    case OwlMark.star:
      canvas.drawPath(
        _starPath(forehead, r * 0.175),
        Paint()..color = accent,
      );
    case OwlMark.gem:
      canvas.drawPath(_gemPath(forehead, r * 0.19), Paint()..color = accent);
      canvas.drawLine(
        forehead + Offset(-r * 0.175, -r * 0.06),
        forehead + Offset(r * 0.175, -r * 0.06),
        Paint()
          ..color = Colors.white.withValues(alpha: 0.7)
          ..strokeWidth = r * 0.035,
      );
    case OwlMark.flame:
    case OwlMark.leaf:
      // Drawn as crests in _owlCrest.
      break;
  }
}

/// Top-of-head crests: the Flame Owl's flame tuft and the Leaf
/// Owl's little leaf.
void _owlCrest(
  Canvas canvas,
  Offset center,
  double r,
  SkinDef skin,
  Color accent,
  Color darker,
) {
  switch (skin.mark) {
    case OwlMark.flame:
      final crestBase = center + Offset(0, -r * 0.92);
      canvas.drawPath(
        _flamePath(crestBase, r * 0.28),
        Paint()..color = accent,
      );
      canvas.drawPath(
        _flamePath(crestBase + Offset(0, r * 0.08), r * 0.16),
        Paint()..color = Color(skin.colorArgb),
      );
    case OwlMark.leaf:
      canvas.save();
      canvas.translate(center.dx - r * 0.06, center.dy - r * 1.06);
      canvas.rotate(-0.45);
      canvas.drawOval(
        Rect.fromCenter(center: Offset.zero, width: r * 0.52, height: r * 0.26),
        Paint()..color = accent,
      );
      canvas.drawLine(
        Offset(-r * 0.24, 0),
        Offset(r * 0.24, 0),
        Paint()
          ..color = darker
          ..strokeWidth = r * 0.04
          ..strokeCap = StrokeCap.round,
      );
      canvas.restore();
    default:
      break;
  }
}

Path _starPath(Offset center, double outerR) {
  final path = Path();
  final innerR = outerR * 0.52;
  for (var i = 0; i < 10; i++) {
    final radius = i.isEven ? outerR : innerR;
    final a = -pi / 2 + i * pi / 5;
    final point = center + Offset(cos(a) * radius, sin(a) * radius);
    if (i == 0) {
      path.moveTo(point.dx, point.dy);
    } else {
      path.lineTo(point.dx, point.dy);
    }
  }
  return path..close();
}

Path _flamePath(Offset center, double r) {
  // Teardrop flame: pointed, slightly wavy tip, round belly.
  return Path()
    ..moveTo(center.dx, center.dy - r * 1.3)
    ..quadraticBezierTo(
      center.dx + r * 0.72,
      center.dy - r * 0.55,
      center.dx + r * 0.78,
      center.dy + r * 0.18,
    )
    ..quadraticBezierTo(
      center.dx + r * 0.8,
      center.dy + r * 0.95,
      center.dx,
      center.dy + r * 1.02,
    )
    ..quadraticBezierTo(
      center.dx - r * 0.8,
      center.dy + r * 0.95,
      center.dx - r * 0.78,
      center.dy + r * 0.18,
    )
    ..quadraticBezierTo(
      center.dx - r * 0.55,
      center.dy - r * 0.5,
      center.dx,
      center.dy - r * 1.3,
    )
    ..close();
}

Path _gemPath(Offset center, double r) {
  return Path()
    ..moveTo(center.dx, center.dy - r * 1.18)
    ..lineTo(center.dx + r * 0.92, center.dy - r * 0.32)
    ..lineTo(center.dx + r * 0.58, center.dy + r * 1.0)
    ..lineTo(center.dx, center.dy + r * 1.22)
    ..lineTo(center.dx - r * 0.58, center.dy + r * 1.0)
    ..lineTo(center.dx - r * 0.92, center.dy - r * 0.32)
    ..close();
}

/// Draws only the skin's signature marking (forehead charm, belly
/// motif, head crest) for [skin] in owl space around [center] with
/// body radius [r]. Used to dress the pre-rendered owl sprite so the
/// eight skins still read differently over the same base character.
void drawOwlSkinMark(Canvas canvas, Offset center, double r, SkinDef skin) {
  final color = Color(skin.colorArgb);
  final accent = Color(skin.accentArgb);
  final darker = Color.lerp(color, Colors.black, 0.16)!;
  _owlMark(canvas, center, r, skin, accent, color);
  _owlCrest(canvas, center, r, skin, accent, darker);
}

/// Hue-rotate filter that retints the coral base owl sprite toward
/// [skin]'s body color, so each skin keeps its identity hue over the
/// shared pre-rendered character. Returns null when the skin already
/// matches the sprite's coral hue (no filtering needed).
ColorFilter? skinTintFilter(SkinDef skin) {
  // Hue of the coral base sprite, measured from its body color.
  const baseHue = 6.0;
  final skinHue = HSVColor.fromColor(Color(skin.colorArgb)).hue;
  var delta = (skinHue - baseHue) % 360.0;
  if (delta > 180.0) delta -= 360.0;
  if (delta.abs() < 6.0) return null;
  return hueRotateFilter(delta);
}

/// Standard luminance-preserving hue-rotate by [degrees] (negative
/// allowed), for retinting pre-rendered sprites toward a target hue.
ColorFilter hueRotateFilter(double degrees) {
  final rad = degrees * pi / 180.0;
  final c = cos(rad);
  final s = sin(rad);
  return ColorFilter.matrix(<double>[
    0.213 + 0.787 * c - 0.213 * s,
    0.715 - 0.715 * c - 0.715 * s,
    0.072 - 0.072 * c + 0.928 * s,
    0,
    0,
    0.213 - 0.213 * c + 0.143 * s,
    0.715 + 0.285 * c + 0.140 * s,
    0.072 - 0.072 * c - 0.283 * s,
    0,
    0,
    0.213 - 0.213 * c - 0.787 * s,
    0.715 - 0.715 * c + 0.715 * s,
    0.072 + 0.928 * c + 0.072 * s,
    0,
    0,
    0,
    0,
    0,
    1,
    0,
  ]);
}

/// Static portrait of a skin, for the home mascot and the skin picker.
class SkinPainter extends CustomPainter {
  final SkinDef skin;

  /// Pre-rendered owl sprite to portrait instead of the vector owl,
  /// when the sprite bank has it ready.
  final ui.Image? image;

  const SkinPainter(this.skin, {this.image});

  @override
  void paint(Canvas canvas, Size size) {
    final center = Offset(size.width / 2, size.height / 2);
    final r = min(size.width, size.height) * 0.34;
    final img = image;
    if (img == null) {
      drawSkinCharacter(canvas, center, r, skin);
      return;
    }
    // Glossy sprite portrait: retinted toward the skin hue, wearing
    // the skin's signature marking.
    final h = r * 2.30;
    final w = h * img.width / img.height;
    final paint = Paint()..filterQuality = FilterQuality.medium;
    final tint = skinTintFilter(skin);
    if (tint != null) paint.colorFilter = tint;
    canvas.drawImageRect(
      img,
      Rect.fromLTWH(0, 0, img.width.toDouble(), img.height.toDouble()),
      Rect.fromCenter(center: center, width: w, height: h),
      paint,
    );
    drawOwlSkinMark(canvas, center, r * 0.98, skin);
  }

  @override
  bool shouldRepaint(covariant SkinPainter oldDelegate) =>
      oldDelegate.skin != skin || oldDelegate.image != image;
}
