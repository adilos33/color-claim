/// Angled/beveled panels — Color Claim's panel shape language.
///
/// The old pill/rounded-card look is what the sibling apps share, so
/// menu panels here are cut-corner (beveled) instead: a chamfer on
/// each corner, an ember edge highlight, and a translucent indigo
/// fill. Pure presentation; no game logic.
library;

import 'package:flutter/material.dart';

import '../theme.dart';

/// Clips a rectangle with chamfered (angled) corners.
class BeveledClipper extends CustomClipper<Path> {
  final double cut;

  const BeveledClipper({this.cut = 14});

  @override
  Path getClip(Size size) {
    final c = cut;
    final path = Path()
      ..moveTo(c, 0)
      ..lineTo(size.width - c, 0)
      ..lineTo(size.width, c)
      ..lineTo(size.width, size.height - c)
      ..lineTo(size.width - c, size.height)
      ..lineTo(c, size.height)
      ..lineTo(0, size.height - c)
      ..lineTo(0, c)
      ..close();
    return path;
  }

  @override
  bool shouldReclip(covariant BeveledClipper oldClipper) =>
      oldClipper.cut != cut;
}

/// A beveled panel: angled corners, translucent fill, and an optional
/// ember gradient fill for featured panels.
class BeveledPanel extends StatelessWidget {
  final Widget child;
  final EdgeInsetsGeometry padding;
  final double cut;
  final Gradient? gradient;
  final Color? fill;
  final Color borderColor;
  final double borderWidth;

  const BeveledPanel({
    super.key,
    required this.child,
    this.padding = const EdgeInsets.all(16),
    this.cut = 14,
    this.gradient,
    this.fill,
    this.borderColor = const Color(0x66FFFFFF),
    this.borderWidth = 1.2,
  });

  @override
  Widget build(BuildContext context) {
    return ClipPath(
      clipper: BeveledClipper(cut: cut),
      child: Container(
        padding: padding,
        decoration: BoxDecoration(
          gradient: gradient,
          color: gradient == null
              ? (fill ?? Colors.white.withValues(alpha: 0.10))
              : null,
          border: Border.all(color: borderColor, width: borderWidth),
        ),
        child: child,
      ),
    );
  }
}

/// A beveled button: ember gradient, angled corners, display type.
class BeveledButton extends StatelessWidget {
  final String label;
  final IconData? icon;
  final VoidCallback? onPressed;
  final bool featured;

  const BeveledButton({
    super.key,
    required this.label,
    this.icon,
    required this.onPressed,
    this.featured = false,
  });

  @override
  Widget build(BuildContext context) {
    final gradient = featured
        ? kEmberGradient
        : const LinearGradient(
            colors: [Color(0xFF3B2F7A), Color(0xFF241B4D)],
          );
    return GestureDetector(
      onTap: onPressed,
      child: ClipPath(
        clipper: const BeveledClipper(cut: 10),
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 14),
          decoration: BoxDecoration(
            gradient: gradient,
            border: Border.all(
              color: featured
                  ? Colors.white.withValues(alpha: 0.55)
                  : Colors.white.withValues(alpha: 0.35),
              width: 1.4,
            ),
          ),
          child: Row(
            mainAxisSize: MainAxisSize.min,
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              if (icon != null) ...[
                Icon(icon, color: Colors.white, size: 20),
                const SizedBox(width: 8),
              ],
              Text(
                label,
                textAlign: TextAlign.center,
                style: displayHeading(size: 16, letterSpacing: 0.8),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
