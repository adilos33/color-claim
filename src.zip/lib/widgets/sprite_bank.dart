import 'dart:async';
import 'dart:ui' as ui;

import 'package:flutter/services.dart';

import 'skin_painter.dart';

/// Pre-rendered glossy 3D character sprites (original art generated
/// for this game, keyed to transparency), decoded once and cached as
/// GPU images.
///
/// The board painter repaints at display rate off the interpolation
/// clock, so it reads whatever has landed here each frame: frames
/// before the decode finishes simply draw the code-drawn characters
/// as a fallback, then the sprites take over seamlessly — no widget
/// rebuilds, no timers, no jank.
class SpriteBank {
  SpriteBank._();

  static final SpriteBank instance = SpriteBank._();

  /// Player owl faces, one per broad expression family.
  ui.Image? owlNeutral;
  ui.Image? owlHappy;
  ui.Image? owlScared;
  ui.Image? owlDizzy;

  /// Bot critters indexed by the board painter's creature variant:
  /// 0 tiny horns, 1 antenna, 2 cat ears, 3 cyclops, 4 bear ears.
  final List<ui.Image?> bots = List<ui.Image?>.filled(5, null);

  bool _started = false;

  /// True once the neutral owl (the fallback face) has decoded.
  bool get owlReady => owlNeutral != null;

  /// Kicks off decoding of every sprite. Idempotent; safe to call
  /// from several screens. Failures leave the corresponding slot null
  /// so the vector characters remain as fallback.
  Future<void> ensureLoaded() async {
    if (_started) return;
    _started = true;
    owlNeutral = await _load('assets/sprites/owl_neutral.png');
    owlHappy = await _load('assets/sprites/owl_happy.png');
    owlScared = await _load('assets/sprites/owl_scared.png');
    owlDizzy = await _load('assets/sprites/owl_dizzy.png');
    const botAssets = [
      'assets/sprites/bot_horns.png',
      'assets/sprites/bot_antenna.png',
      'assets/sprites/bot_cat.png',
      'assets/sprites/bot_cyclops.png',
      'assets/sprites/bot_bear.png',
    ];
    for (var i = 0; i < botAssets.length; i++) {
      bots[i] = await _load(botAssets[i]);
    }
  }

  /// The owl face for [expression]; celebrate borrows the happy
  /// sprite and everything else falls back toward neutral.
  ui.Image? owlFor(OwlExpression expression) => switch (expression) {
    OwlExpression.happy || OwlExpression.celebrate =>
      owlHappy ?? owlNeutral,
    OwlExpression.scared => owlScared ?? owlNeutral,
    OwlExpression.dizzy => owlDizzy ?? owlNeutral,
    _ => owlNeutral,
  };

  /// The bot sprite for creature [variant], or null while loading /
  /// when the variant has no sprite.
  ui.Image? botFor(int variant) =>
      (variant >= 0 && variant < bots.length) ? bots[variant] : null;

  Future<ui.Image?> _load(String asset) async {
    try {
      final data = await rootBundle.load(asset);
      final codec = await ui.instantiateImageCodec(
        data.buffer.asUint8List(),
        targetHeight: 256,
      );
      final frame = await codec.getNextFrame();
      return frame.image;
    } catch (_) {
      return null;
    }
  }
}
