import 'package:flutter/material.dart';

import '../game/progress.dart';
import '../game/skins.dart';
import '../services/progress_store.dart';
import '../services/sound_service.dart';
import '../widgets/skin_painter.dart';
import '../widgets/sprite_bank.dart';

/// Skin shop / wardrobe: shows every original skin with its drawn
/// portrait, price, and locked / owned / equipped state. Points come
/// from finished matches; buying a skin equips it right away.
class SkinPickerScreen extends StatefulWidget {
  final ProgressStore progressStore;

  const SkinPickerScreen({super.key, required this.progressStore});

  @override
  State<SkinPickerScreen> createState() => _SkinPickerScreenState();
}

class _SkinPickerScreenState extends State<SkinPickerScreen> {
  Future<void> _tapSkin(SkinDef skin) async {
    final store = widget.progressStore;
    if (store.progress.selectedSkinId == skin.id) return;
    if (store.progress.isSkinUnlocked(skin.id)) {
      if (await store.selectSkin(skin.id)) {
        SoundService.instance.play(GameSound.pop);
        if (mounted) setState(() {});
      }
      return;
    }
    // Locked: buy it (and equip it) when the wallet covers the price.
    if (await store.unlockSkin(skin.id)) {
      await store.selectSkin(skin.id);
      SoundService.instance.play(GameSound.capture);
      if (mounted) setState(() {});
    }
  }

  @override
  Widget build(BuildContext context) {
    final progress = widget.progressStore.progress;
    return Scaffold(
      appBar: AppBar(
        title: const Text(
          'Skins',
          style: TextStyle(fontWeight: FontWeight.w900),
        ),
        backgroundColor: Colors.transparent,
        elevation: 0,
        foregroundColor: Colors.white,
        actions: [
          Center(
            child: Container(
              margin: const EdgeInsets.only(right: 16),
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
              decoration: BoxDecoration(
                color: Colors.white.withValues(alpha: 0.18),
                borderRadius: BorderRadius.circular(999),
                border: Border.all(color: Colors.white.withValues(alpha: 0.35)),
              ),
              child: Text(
                '⭐ ${progress.points}',
                style: const TextStyle(
                  color: Colors.white,
                  fontWeight: FontWeight.w900,
                  fontSize: 15,
                ),
              ),
            ),
          ),
        ],
      ),
      extendBodyBehindAppBar: true,
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [Color(0xFF062A3A), Color(0xFF0B3D24), Color(0xFF101828)],
          ),
        ),
        child: SafeArea(
          child: Column(
            children: [
              const Padding(
                padding: EdgeInsets.fromLTRB(16, 4, 16, 8),
                child: Text(
                  'Finish matches to earn ⭐ points, then unlock a new look. Your skin colors your whole zone!',
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    color: Colors.white70,
                    fontWeight: FontWeight.w600,
                    fontSize: 13.5,
                  ),
                ),
              ),
              Expanded(
                child: GridView.builder(
                  padding: const EdgeInsets.fromLTRB(16, 4, 16, 16),
                  gridDelegate:
                      const SliverGridDelegateWithMaxCrossAxisExtent(
                        maxCrossAxisExtent: 190,
                        mainAxisSpacing: 14,
                        crossAxisSpacing: 14,
                        childAspectRatio: 0.78,
                      ),
                  itemCount: kSkins.length,
                  itemBuilder: (context, i) =>
                      _skinCard(context, kSkins[i], progress),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _skinCard(
    BuildContext context,
    SkinDef skin,
    GameProgress progress,
  ) {
    final owned = progress.isSkinUnlocked(skin.id);
    final selected = progress.selectedSkinId == skin.id;
    final affordable = progress.points >= skin.price;
    return InkWell(
      borderRadius: BorderRadius.circular(20),
      onTap: () => _tapSkin(skin),
      child: Container(
        decoration: BoxDecoration(
          color: Colors.white.withValues(alpha: selected ? 0.16 : 0.08),
          borderRadius: BorderRadius.circular(20),
          border: Border.all(
            color: selected
                ? Color(skin.colorArgb)
                : Colors.white.withValues(alpha: 0.18),
            width: selected ? 2.2 : 1.2,
          ),
        ),
        padding: const EdgeInsets.fromLTRB(10, 12, 10, 10),
        child: Column(
          children: [
            SizedBox(
              width: 84,
              height: 84,
              child: CustomPaint(
                painter: SkinPainter(skin, image: SpriteBank.instance.owlNeutral),
              ),
            ),
            const SizedBox(height: 6),
            Text(
              skin.name,
              textAlign: TextAlign.center,
              style: const TextStyle(
                color: Colors.white,
                fontWeight: FontWeight.w900,
                fontSize: 15,
              ),
            ),
            const SizedBox(height: 2),
            Text(
              skin.blurb,
              textAlign: TextAlign.center,
              maxLines: 2,
              overflow: TextOverflow.ellipsis,
              style: TextStyle(
                color: Colors.white.withValues(alpha: 0.65),
                fontWeight: FontWeight.w600,
                fontSize: 11,
              ),
            ),
            const Spacer(),
            _stateChip(skin, owned: owned, selected: selected, affordable: affordable),
          ],
        ),
      ),
    );
  }

  Widget _stateChip(
    SkinDef skin, {
    required bool owned,
    required bool selected,
    required bool affordable,
  }) {
    if (selected) {
      return _chip(
        const Text(
          '✓ Equipped',
          style: TextStyle(color: Colors.white, fontWeight: FontWeight.w900, fontSize: 12.5),
        ),
        const Color(0xFF15803D),
      );
    }
    if (owned) {
      return _chip(
        const Text(
          'Use',
          style: TextStyle(color: Colors.white, fontWeight: FontWeight.w900, fontSize: 12.5),
        ),
        Color(skin.colorArgb),
      );
    }
    return _chip(
      Text(
        '⭐ ${skin.price}',
        style: TextStyle(
          color: affordable ? const Color(0xFF3A2400) : Colors.white54,
          fontWeight: FontWeight.w900,
          fontSize: 12.5,
        ),
      ),
      affordable ? const Color(0xFFFFD93D) : Colors.white.withValues(alpha: 0.14),
    );
  }

  Widget _chip(Widget child, Color background) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
      decoration: BoxDecoration(
        color: background,
        borderRadius: BorderRadius.circular(999),
      ),
      child: child,
    );
  }
}
