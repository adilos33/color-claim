import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart';
import 'package:flutter/services.dart';

import '../game/territory_engine.dart';
import '../services/progress_store.dart';
import '../services/sound_service.dart';
import '../widgets/board_painter.dart';

class GameScreen extends StatefulWidget {
  final LevelConfig level;
  final ProgressStore progressStore;

  const GameScreen({
    super.key,
    required this.level,
    required this.progressStore,
  });

  @override
  State<GameScreen> createState() => _GameScreenState();
}

class _GameScreenState extends State<GameScreen>
    with SingleTickerProviderStateMixin {
  late TerritoryEngine engine;
  late final Ticker _ticker;
  Duration _last = Duration.zero;
  double _accMs = 0;
  static const double _stepMs = 115;

  bool paused = false;
  bool muted = false;
  bool won = false;
  bool lost = false;
  int _lastLives = 3;
  int _lastCaptureCount = 0;
  int _lastBotKillCount = 0;
  bool _outcomeSaved = false;

  /// Key on the board widget so steering can measure where the finger
  /// is relative to the player's blob on screen.
  final GlobalKey _boardKey = GlobalKey();

  @override
  void initState() {
    super.initState();
    muted = widget.progressStore.progress.muted;
    SoundService.instance.muted = muted;
    engine = TerritoryEngine(widget.level);
    _ticker = createTicker(_onTick)..start();
  }

  @override
  void dispose() {
    _ticker.dispose();
    super.dispose();
  }

  void _onTick(Duration elapsed) {
    if (_last == Duration.zero) {
      _last = elapsed;
      return;
    }
    final dt = (elapsed - _last).inMicroseconds / 1000.0;
    _last = elapsed;
    if (!paused && !won && !lost) {
      _accMs += dt;
      while (_accMs >= _stepMs) {
        _accMs -= _stepMs;
        engine.step();
      }
      final p = engine.playerPercent;
      if (engine.playerCaptureCount > _lastCaptureCount) {
        _lastCaptureCount = engine.playerCaptureCount;
        SoundService.instance.play(GameSound.capture);
        if (!muted) HapticFeedback.lightImpact();
      }
      if (engine.playerBotKills > _lastBotKillCount) {
        _lastBotKillCount = engine.playerBotKills;
        SoundService.instance.play(GameSound.pop);
      }
      if (engine.lives < _lastLives) {
        _lastLives = engine.lives;
        if (!engine.gameOver) {
          SoundService.instance.play(GameSound.die);
        }
        if (!muted) HapticFeedback.heavyImpact();
      }
      if (engine.playerWon) {
        won = true;
        SoundService.instance.play(GameSound.win);
        if (!muted) HapticFeedback.mediumImpact();
        if (!_outcomeSaved) {
          _outcomeSaved = true;
          unawaited(
            widget.progressStore.recordWin(
              levelId: widget.level.id,
              percent: p,
              totalLevels: kLevels.length,
            ),
          );
        }
      } else if (engine.gameOver) {
        lost = true;
        SoundService.instance.play(GameSound.lose);
        if (!muted) HapticFeedback.heavyImpact();
        if (!_outcomeSaved) {
          _outcomeSaved = true;
          unawaited(
            widget.progressStore.recordBest(
              levelId: widget.level.id,
              percent: p,
            ),
          );
        }
      }
    }
    if (mounted) setState(() {});
  }

  void _restart() {
    SoundService.instance.play(GameSound.pop);
    setState(() {
      engine = TerritoryEngine(widget.level);
      _lastLives = engine.lives;
      _lastCaptureCount = 0;
      _lastBotKillCount = 0;
      _outcomeSaved = false;
      _accMs = 0;
      paused = false;
      won = false;
      lost = false;
    });
  }

  Future<void> _toggleMute() async {
    final newValue = !muted;
    setState(() => muted = newValue);
    await SoundService.instance.setMuted(newValue);
    await widget.progressStore.setMuted(newValue);
    if (!newValue) SoundService.instance.play(GameSound.pop);
  }

  void _togglePaused() {
    SoundService.instance.play(GameSound.pop);
    setState(() => paused = !paused);
  }

  void _resume() {
    SoundService.instance.play(GameSound.pop);
    setState(() => paused = false);
  }

  void _goHome() {
    SoundService.instance.play(GameSound.pop);
    Navigator.of(context).pop();
  }

  /// Steer toward the finger: the blob heads in the direction from its
  /// own on-screen position to the touch point. This matches browser
  /// play — press and drag, the blob follows your finger — and it does
  /// not depend on per-event drag deltas, which jitter on touchscreens.
  void _steerTo(Offset globalPosition) {
    final box = _boardKey.currentContext?.findRenderObject() as RenderBox?;
    if (box == null || !box.hasSize) return;
    final local = box.globalToLocal(globalPosition);
    final cell = box.size.width / TerritoryEngine.cols;
    final center = Offset(
      (engine.player.x + 0.5) * cell,
      (engine.player.y + 0.5) * cell,
    );
    final v = local - center;
    // Deadzone around the blob itself so a resting finger near it does
    // not flip the heading back and forth.
    if (v.distance < cell * 1.2) return;
    final ax = v.dx.abs();
    final ay = v.dy.abs();
    if (ax > ay * 1.2) {
      engine.setPlayerDirection(v.dx > 0 ? 1 : -1, 0);
    } else if (ay > ax * 1.2) {
      engine.setPlayerDirection(0, v.dy > 0 ? 1 : -1);
    }
  }

  @override
  Widget build(BuildContext context) {
    final percent = engine.playerPercent;
    final goal = widget.level.goalPercent;
    final t = (_accMs / _stepMs).clamp(0.0, 1.0);

    final board = AspectRatio(
      aspectRatio: 1,
      child: Container(
        key: _boardKey,
        decoration: BoxDecoration(
          color: Color(widget.level.neutralArgb),
          borderRadius: BorderRadius.circular(16),
          boxShadow: const [
            BoxShadow(
              color: Colors.black12,
              blurRadius: 10,
              offset: Offset(0, 4),
            ),
          ],
        ),
        child: ClipRRect(
          borderRadius: BorderRadius.circular(16),
          child: CustomPaint(painter: BoardPainter(engine, t)),
        ),
      ),
    );

    final leaderboard = Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text(
          'Ranking',
          style: TextStyle(fontWeight: FontWeight.bold, fontSize: 15),
        ),
        const SizedBox(height: 6),
        ...engine.leaderboard.map((a) {
          final p = engine.percentFor(a.id);
          return Padding(
            padding: const EdgeInsets.symmetric(vertical: 2),
            child: Row(
              children: [
                CircleAvatar(radius: 7, backgroundColor: Color(a.colorArgb)),
                const SizedBox(width: 6),
                Expanded(
                  child: Text(
                    a.isPlayer ? 'You' : a.name,
                    style: TextStyle(
                      fontWeight: a.isPlayer
                          ? FontWeight.bold
                          : FontWeight.normal,
                    ),
                  ),
                ),
                Text('${p.toStringAsFixed(1)}%'),
              ],
            ),
          );
        }),
        const SizedBox(height: 8),
        Row(
          children: [
            const Icon(Icons.favorite, color: Colors.redAccent, size: 18),
            const SizedBox(width: 4),
            Text(
              '${engine.lives}',
              style: const TextStyle(fontWeight: FontWeight.bold),
            ),
            const SizedBox(width: 14),
            const Icon(Icons.star, color: Colors.amber, size: 18),
            const SizedBox(width: 4),
            Text(
              '${engine.score}',
              style: const TextStyle(fontWeight: FontWeight.bold),
            ),
          ],
        ),
      ],
    );

    return Scaffold(
      backgroundColor: Color(widget.level.backgroundArgb),
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        foregroundColor: const Color(0xFF22333B),
        title: Text(
          'Level ${widget.level.id} · ${widget.level.name}',
          style: const TextStyle(fontWeight: FontWeight.bold),
        ),
        actions: [
          IconButton(
            icon: Icon(muted ? Icons.volume_off : Icons.volume_up),
            onPressed: _toggleMute,
          ),
          IconButton(
            icon: Icon(paused ? Icons.play_arrow : Icons.pause),
            onPressed: won || lost ? null : _togglePaused,
          ),
          IconButton(icon: const Icon(Icons.refresh), onPressed: _restart),
        ],
      ),
      body: GestureDetector(
        onPanDown: (d) => _steerTo(d.globalPosition),
        onPanStart: (d) => _steerTo(d.globalPosition),
        onPanUpdate: (d) => _steerTo(d.globalPosition),
        child: Stack(
          children: [
            Column(
              children: [
                Padding(
                  padding: const EdgeInsets.fromLTRB(16, 4, 16, 8),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Text(
                            '${percent.toStringAsFixed(1)}%',
                            style: const TextStyle(
                              fontSize: 20,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                          Text(
                            'Goal ${goal.toStringAsFixed(0)}%',
                            style: const TextStyle(color: Colors.black54),
                          ),
                        ],
                      ),
                      const SizedBox(height: 4),
                      LayoutBuilder(
                        builder: (context, c) {
                          return Stack(
                            children: [
                              Container(
                                height: 14,
                                decoration: BoxDecoration(
                                  color: Colors.black12,
                                  borderRadius: BorderRadius.circular(7),
                                ),
                              ),
                              FractionallySizedBox(
                                widthFactor: (percent / 100).clamp(0.0, 1.0),
                                child: Container(
                                  height: 14,
                                  decoration: BoxDecoration(
                                    color: const Color(kPlayerColor),
                                    borderRadius: BorderRadius.circular(7),
                                  ),
                                ),
                              ),
                              Positioned(
                                left: (c.maxWidth * goal / 100) - 1,
                                child: Container(
                                  width: 2,
                                  height: 14,
                                  color: Colors.black54,
                                ),
                              ),
                            ],
                          );
                        },
                      ),
                    ],
                  ),
                ),
                Expanded(
                  child: LayoutBuilder(
                    builder: (context, c) {
                      final wide = c.maxWidth > c.maxHeight + 120;
                      if (wide) {
                        return Padding(
                          padding: const EdgeInsets.all(12),
                          child: Row(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Expanded(child: Center(child: board)),
                              const SizedBox(width: 14),
                              SizedBox(width: 180, child: leaderboard),
                            ],
                          ),
                        );
                      }
                      return Padding(
                        padding: const EdgeInsets.all(12),
                        child: Column(
                          children: [
                            Expanded(child: Center(child: board)),
                            const SizedBox(height: 10),
                            leaderboard,
                          ],
                        ),
                      );
                    },
                  ),
                ),
              ],
            ),
            if (paused && !won && !lost)
              _overlay(
                title: 'Paused',
                buttons: [
                  ElevatedButton(
                    onPressed: _resume,
                    child: const Text('Resume'),
                  ),
                  TextButton(onPressed: _restart, child: const Text('Restart')),
                  TextButton(onPressed: _goHome, child: const Text('Home')),
                ],
              ),
            if (won)
              _overlay(
                title: 'Level Complete!',
                subtitle:
                    'You claimed ${percent.toStringAsFixed(1)}% of the board.',
                buttons: [
                  if (widget.level.id < kLevels.length)
                    ElevatedButton(
                      onPressed: () {
                        SoundService.instance.play(GameSound.pop);
                        Navigator.of(context).pushReplacement(
                          MaterialPageRoute(
                            builder: (_) => GameScreen(
                              level: kLevels[widget.level.id],
                              progressStore: widget.progressStore,
                            ),
                          ),
                        );
                      },
                      child: const Text('Next Level'),
                    ),
                  TextButton(
                    onPressed: _restart,
                    child: const Text('Play Again'),
                  ),
                  TextButton(onPressed: _goHome, child: const Text('Home')),
                ],
              ),
            if (lost)
              _overlay(
                title: 'Game Over',
                subtitle:
                    'You claimed ${percent.toStringAsFixed(1)}%. Goal was ${goal.toStringAsFixed(0)}%.',
                buttons: [
                  ElevatedButton(
                    onPressed: _restart,
                    child: const Text('Try Again'),
                  ),
                  TextButton(onPressed: _goHome, child: const Text('Home')),
                ],
              ),
          ],
        ),
      ),
    );
  }

  Widget _overlay({
    required String title,
    String? subtitle,
    required List<Widget> buttons,
  }) {
    return Positioned.fill(
      child: Container(
        color: Colors.black.withValues(alpha: 0.45),
        child: Center(
          child: Card(
            margin: const EdgeInsets.all(24),
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(20),
            ),
            child: Padding(
              padding: const EdgeInsets.all(24),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Text(
                    title,
                    style: const TextStyle(
                      fontSize: 26,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  if (subtitle != null) ...[
                    const SizedBox(height: 8),
                    Text(subtitle, textAlign: TextAlign.center),
                  ],
                  const SizedBox(height: 16),
                  ...buttons,
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
