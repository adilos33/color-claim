import 'dart:async';
import 'dart:math';

import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart';
import 'package:flutter/services.dart';

import '../game/challenges.dart';
import '../game/game_mode.dart';
import '../game/points.dart';
import '../game/powerups.dart';
import '../game/ranks.dart';
import '../game/skins.dart';
import '../game/territory_engine.dart';
import '../services/progress_store.dart';
import '../services/sound_service.dart';
import '../widgets/board_painter.dart';
import '../widgets/sprite_bank.dart';

class GameScreen extends StatefulWidget {
  final LevelConfig level;
  final ProgressStore progressStore;

  /// How this run is framed (Classic goal, Quick Match race, Survival).
  final GameMode mode;

  const GameScreen({
    super.key,
    required this.level,
    required this.progressStore,
    this.mode = GameMode.classic,
  });

  @override
  State<GameScreen> createState() => _GameScreenState();
}

class _GameScreenState extends State<GameScreen>
    with SingleTickerProviderStateMixin {
  late TerritoryEngine engine;
  late final Ticker _ticker;
  Duration _last = Duration.zero;
  Duration _now = Duration.zero;
  double _accMs = 0;
  static const double _stepMs = 80;

  /// Per-frame interpolation clock (fraction of the current engine
  /// step). The board/minimap painters repaint off this listenable and
  /// read its value at paint time, so smooth motion and FX run at
  /// display rate without rebuilding the widget tree every frame;
  /// `setState` is reserved for ticks where an engine step actually
  /// changed HUD-visible state.
  final ValueNotifier<double> _interp = ValueNotifier(0);

  /// Cross-frame render caches shared by the board/minimap painters.
  final BoardRenderCache _renderCache = BoardRenderCache();

  bool paused = false;
  bool muted = false;
  bool won = false;
  bool lost = false;
  int _lastLives = 3;
  int _lastCaptureCount = 0;
  int _lastBotKillCount = 0;
  // Last player heading seen, for the turn-feather sparkles.
  int _lastDirX = -99;
  int _lastDirY = -99;
  int _lastPickupEvents = 0;
  int _lastShieldBreakEvents = 0;
  bool _outcomeSaved = false;

  /// Equipped skin for this run (character look + territory color).
  late final SkinDef _skin;

  /// Points this finished match earned (shown on the result overlay).
  int _earnedPoints = 0;

  /// Rank newly reached by this match's earnings, when it promoted the
  /// player (shown as a celebration banner on the result overlay).
  RankDef? _newRank;

  /// Mode framing (Quick Match clock, Survival timer and results).
  bool _ended = false;
  String _endTitle = '';
  String _endSubtitle = '';
  bool _endVictory = false;
  Duration _elapsed = Duration.zero;
  double _peakPercent = 0;

  TerritoryEngine _newEngine() => TerritoryEngine(
    widget.level,
    initialLives: widget.mode == GameMode.survival ? 1 : 3,
    playerColorArgb: _skin.colorArgb,
  );

  static String _fmtTime(Duration d) {
    final total = d.inSeconds;
    final m = total ~/ 60;
    final s = (total % 60).toString().padLeft(2, '0');
    return '$m:$s';
  }

  // Juice state.
  final FxState _fx = FxState();
  final Random _rng = Random();
  double _sparkleAccMs = 0;
  int _combo = 0;
  Duration _lastCaptureAt = Duration.zero;
  String _killBanner = '';
  Duration _killBannerUntil = Duration.zero;

  /// Key on the board widget so steering can measure where the finger
  /// is relative to the player's blob on screen.
  final GlobalKey _boardKey = GlobalKey();

  @override
  void initState() {
    super.initState();
    // Pre-rendered character sprites decode in the background; the
    // board falls back to vector characters until they land.
    unawaited(SpriteBank.instance.ensureLoaded());
    muted = widget.progressStore.progress.muted;
    SoundService.instance.muted = muted;
    SoundService.instance.startMusic();
    _skin = skinById(widget.progressStore.progress.selectedSkinId);
    engine = _newEngine();
    _lastLives = engine.lives;
    _peakPercent = engine.playerPercent;
    _ticker = createTicker(_onTick)..start();
  }

  @override
  void dispose() {
    SoundService.instance.stopMusic();
    _ticker.dispose();
    _interp.dispose();
    super.dispose();
  }

  void _onTick(Duration elapsed) {
    if (_last == Duration.zero) {
      _last = elapsed;
      _now = elapsed;
      return;
    }
    final dt = (elapsed - _last).inMicroseconds / 1000.0;
    _last = elapsed;
    _now = elapsed;
    var stepped = false;
    final wasEnded = _ended;
    if (!paused && !won && !lost) {
      _elapsed += Duration(milliseconds: dt.round());
      _accMs += dt;
      // Cap catch-up after long stalls (tab switch, jank): running an
      // unbounded burst of steps in one tick causes the next jank.
      var guard = 0;
      while (_accMs >= _stepMs && guard < 4) {
        _accMs -= _stepMs;
        engine.step();
        stepped = true;
        guard++;
      }
      if (_accMs >= _stepMs) _accMs = 0;
      final p = engine.playerPercent;
      _peakPercent = max(_peakPercent, p);
      if (engine.playerCaptureCount > _lastCaptureCount) {
        _lastCaptureCount = engine.playerCaptureCount;
        SoundService.instance.play(GameSound.capture);
        if (!muted) HapticFeedback.lightImpact();
        _onPlayerCapture();
      }
      if (engine.playerBotKills > _lastBotKillCount) {
        _lastBotKillCount = engine.playerBotKills;
        SoundService.instance.play(GameSound.pop);
        _onPlayerKill();
      }
      if (engine.pickupEvents > _lastPickupEvents) {
        _lastPickupEvents = engine.pickupEvents;
        _onPickup();
      }
      if (engine.shieldBreakEvents > _lastShieldBreakEvents) {
        _lastShieldBreakEvents = engine.shieldBreakEvents;
        SoundService.instance.play(GameSound.pop);
        if (!muted) HapticFeedback.mediumImpact();
        final sx = engine.lastShieldBreakX + 0.5;
        final sy = engine.lastShieldBreakY + 0.5;
        _burst(sx, sy, const Color(0xFF38BDF8), 20);
        _fx.popups.add(
          FxPopup(
            cx: sx,
            cy: sy - 1.2,
            text: '🛡 Shield saved you!',
            color: const Color(0xFF9BE8FF),
          ),
        );
        _fx.flash = max(_fx.flash, 0.18);
      }
      if (engine.lives < _lastLives) {
        _lastLives = engine.lives;
        // The owl goes dizzy for a second after losing a life.
        _fx.hurtUntilSec = _fx.nowSec + 1.0;
        if (!engine.gameOver) {
          SoundService.instance.play(GameSound.die);
        }
        if (!muted) HapticFeedback.heavyImpact();
        _burst(
          engine.lastPlayerDeathX + 0.5,
          engine.lastPlayerDeathY + 0.5,
          Color(engine.player.colorArgb),
          20,
        );
        _fx.flash = max(_fx.flash, 0.22);
      }
      // A sharp turn while out on a trail sheds a few feather
      // sparkles. Capped so a zig-zag frenzy stays perf-safe.
      final owl = engine.player;
      final turned =
          (owl.dx != _lastDirX || owl.dy != _lastDirY) &&
          (_lastDirX != -99 || _lastDirY != -99);
      _lastDirX = owl.dx;
      _lastDirY = owl.dy;
      if (turned && owl.alive && owl.isOutside && _fx.particles.length < 220) {
        for (var i = 0; i < 3; i++) {
          final a = i * 2.39996 + engine.steps * 0.7;
          _fx.particles.add(
            FxParticle(
              cx: owl.x + 0.5 + cos(a) * 0.35,
              cy: owl.y + 0.5 + sin(a) * 0.35,
              vx: -owl.dx * 1.4 + cos(a) * 1.1,
              vy: -owl.dy * 1.4 + sin(a) * 1.1 - 0.6,
              life: 0.4 + 0.08 * i,
              size: 0.15,
              color: Color.lerp(Color(owl.colorArgb), Colors.white, 0.65)!,
            ),
          );
        }
      }
      if (!_ended) {
        switch (widget.mode) {
          case GameMode.classic:
            if (engine.playerWon) {
              _finishMatch(
                victory: true,
                title: 'Level Complete!',
                subtitle: 'You claimed ${p.toStringAsFixed(1)}% of the board.',
              );
            } else if (engine.gameOver) {
              _finishMatch(
                victory: false,
                title: 'Game Over',
                subtitle:
                    'You claimed ${p.toStringAsFixed(1)}%. Goal was ${widget.level.goalPercent.toStringAsFixed(0)}%.',
              );
            }
          case GameMode.quickMatch:
            if (quickGoalWhileLeading(engine)) {
              _finishQuickMatch('Goal reached while leading!');
            } else if (engine.gameOver) {
              _finishQuickMatch('Knocked out!');
            } else if (_elapsed.inSeconds >= kQuickMatchSeconds) {
              _finishQuickMatch('Time up.');
            }
          case GameMode.survival:
            if (engine.gameOver) _finishSurvival();
        }
      }
      _updateFx(dt);
    } else if (won || lost) {
      // Let end-of-match juice (victory confetti, death burst, flash)
      // finish animating behind the result overlay.
      _updateFx(dt);
    }
    // Publish the interpolation fraction: this repaints the board and
    // minimap at display rate without a widget rebuild.
    _interp.value = (_accMs / _stepMs).clamp(0.0, 1.0);
    // HUD-visible state (percents, ranking, timers, chips, overlays)
    // can only change when a step ran (or the match just ended), so
    // rebuilds are capped at step rate instead of every frame.
    if (mounted && (stepped || _ended != wasEnded)) setState(() {});
  }

  /// Ends the run once: result overlay data, sound, and saved progress.
  /// Classic and Quick Match victories unlock the next level; Survival
  /// records best time/percent only.
  void _finishMatch({
    required bool victory,
    required String title,
    required String subtitle,
  }) {
    if (_ended) return;
    _ended = true;
    _endVictory = victory;
    // The owl keeps a celebrate/sad face behind the result overlay.
    _fx.endVictory = victory;
    _endTitle = title;
    // Points for the finished match: percent claimed, knockouts, and
    // the win bonus. Survival banks its peak percent and never a bonus.
    final result = matchPoints(
      percent: widget.mode == GameMode.survival
          ? _peakPercent
          : engine.playerPercent,
      knockouts: engine.playerBotKills,
      victory: victory,
    );
    _earnedPoints = result.total;
    // Bank the match: match points plus today's daily-challenge
    // update. The bank credits the daily bonus the moment the
    // challenge completes, so the lifetime total read below already
    // includes everything this match earned.
    final lifetimeBefore = widget.progressStore.progress.lifetimePoints;
    final dailyBonus = widget.progressStore.bankMatch(
      matchPoints: _earnedPoints,
      stats: MatchStats(
        mode: widget.mode,
        percent: widget.mode == GameMode.survival
            ? _peakPercent
            : engine.playerPercent,
        knockouts: engine.playerBotKills,
        victory: victory,
        survivalSeconds: _elapsed.inSeconds,
      ),
    );
    final progress = widget.progressStore.progress;
    if (rankIndexForLifetime(progress.lifetimePoints) >
        rankIndexForLifetime(lifetimeBefore)) {
      _newRank = rankForLifetime(progress.lifetimePoints);
    }
    _endSubtitle = _earnedPoints > 0
        ? '$subtitle\n⭐ +$_earnedPoints points earned'
        : subtitle;
    if (dailyBonus > 0) {
      _endSubtitle += '\n🎯 Daily challenge complete! ⭐ +$dailyBonus';
    }
    won = victory;
    lost = !victory;
    if (victory) {
      SoundService.instance.play(GameSound.win);
      if (!muted) HapticFeedback.mediumImpact();
      _confetti();
    } else {
      SoundService.instance.play(GameSound.lose);
      if (!muted) HapticFeedback.heavyImpact();
    }
    if (_outcomeSaved) return;
    _outcomeSaved = true;
    if (widget.mode == GameMode.survival) {
      unawaited(
        widget.progressStore.recordSurvival(
          levelId: widget.level.id,
          seconds: _elapsed.inSeconds,
          percent: _peakPercent,
        ),
      );
    } else if (victory) {
      unawaited(
        widget.progressStore.recordWin(
          levelId: widget.level.id,
          percent: engine.playerPercent,
          totalLevels: kLevels.length,
        ),
      );
    } else {
      unawaited(
        widget.progressStore.recordBest(
          levelId: widget.level.id,
          percent: engine.playerPercent,
        ),
      );
    }
  }

  void _finishQuickMatch(String reason) {
    final s = quickStanding(engine);
    final pct = s.playerPercent.toStringAsFixed(1);
    if (s.isLeading) {
      _finishMatch(
        victory: true,
        title: 'Victory!',
        subtitle: '$reason You finish #1 with $pct%.',
      );
    } else {
      _finishMatch(
        victory: false,
        title: reason.startsWith('Knocked') ? 'Knocked Out' : 'Time Up',
        subtitle:
            'You finish #${s.rank} of ${s.totalActors} with $pct%. '
            '${s.leaderName} wins with ${s.leaderPercent.toStringAsFixed(1)}%.',
      );
    }
  }

  void _finishSurvival() {
    _finishMatch(
      victory: false,
      title: 'Survived ${_fmtTime(_elapsed)}',
      subtitle:
          'Peak ${_peakPercent.toStringAsFixed(1)}% · Score ${engine.score} '
          '· ${engine.playerBotKills} knockouts',
    );
  }

  void _onPlayerCapture() {
    final gainedCells = engine.lastPlayerCaptureGainedCells;
    final gainedPct = gainedCells * 100.0 / engine.playableCells;
    final cx = engine.lastPlayerCaptureX + 0.5;
    final cy = engine.lastPlayerCaptureY + 0.5;

    // Combo: captures chained within 4 seconds.
    if (_now - _lastCaptureAt <= const Duration(seconds: 4)) {
      _combo++;
    } else {
      _combo = 1;
    }
    _lastCaptureAt = _now;

    final big = gainedPct >= 2.5;
    _burst(cx, cy, Color(engine.player.colorArgb), big ? 26 : 14);
    _fx.rings.add(
      FxRing(cx: cx, cy: cy, color: Color(engine.player.colorArgb)),
    );
    _fx.popups.add(
      FxPopup(
        cx: cx,
        cy: cy - 1.2,
        text: '+${gainedPct.toStringAsFixed(1)}%',
        color: big ? const Color(0xFFFFD93D) : Colors.white,
      ),
    );
    // The owl grins for a beat after every capture; a big one also
    // makes the whole board breathe in by a hair.
    _fx.happyUntilSec = _fx.nowSec + 0.8;
    if (big) {
      _fx.flash = max(_fx.flash, 0.3);
      _fx.breath = 0.9;
    }
  }

  void _onPlayerKill() {
    _killBanner = 'You cut ${engine.lastPlayerKillName}!';
    _killBannerUntil = _now + const Duration(milliseconds: 1800);
    _burst(
      engine.lastPlayerKillX + 0.5,
      engine.lastPlayerKillY + 0.5,
      const Color(0xFFFFD93D),
      16,
    );
    if (!muted) HapticFeedback.mediumImpact();
  }

  /// Pickup feedback: a burst at the pickup cell for any collector, and
  /// a popup + sound when the player is the one who grabbed it.
  void _onPickup() {
    final kind = engine.lastPickupKind;
    final cx = engine.lastPickupX + 0.5;
    final cy = engine.lastPickupY + 0.5;
    _burst(cx, cy, Color(kind.colorArgb), 16);
    if (!engine.lastPickupByPlayer) return;
    SoundService.instance.play(GameSound.pop);
    if (!muted) HapticFeedback.lightImpact();
    _fx.popups.add(
      FxPopup(
        cx: cx,
        cy: cy - 1.2,
        text: kind.pickupMessage,
        color: Color(kind.colorArgb),
      ),
    );
  }

  void _burst(double cx, double cy, Color color, int count) {
    for (var i = 0; i < count; i++) {
      final angle = _rng.nextDouble() * 2 * pi;
      final speed = 4 + _rng.nextDouble() * 9;
      _fx.particles.add(
        FxParticle(
          cx: cx,
          cy: cy,
          vx: cos(angle) * speed,
          vy: sin(angle) * speed,
          life: 0.45 + _rng.nextDouble() * 0.4,
          size: 0.35 + _rng.nextDouble() * 0.45,
          color: Color.lerp(color, Colors.white, _rng.nextDouble() * 0.4)!,
        ),
      );
    }
  }

  void _confetti() {
    const colors = [
      Color(0xFFFF4757),
      Color(0xFFFFB020),
      Color(0xFF2EE6A8),
      Color(0xFF3E9BFF),
      Color(0xFFFF5D8F),
      Color(0xFFB06BFF),
    ];
    for (var i = 0; i < 72; i++) {
      _fx.particles.add(
        FxParticle(
          cx: _rng.nextDouble() * TerritoryEngine.cols,
          cy: -2 - _rng.nextDouble() * 10,
          vx: (_rng.nextDouble() - 0.5) * 3,
          vy: 5 + _rng.nextDouble() * 6,
          life: 1.6 + _rng.nextDouble() * 1.2,
          size: 0.4 + _rng.nextDouble() * 0.5,
          color: colors[_rng.nextInt(colors.length)],
          gravity: true,
          confetti: true,
          rot: _rng.nextDouble() * pi,
        ),
      );
    }
  }

  void _updateFx(double dtMs) {
    final dt = dtMs / 1000.0;

    // The FX clock: every expression and motion beat in the painter
    // derives from this, advanced with the same dt as the particles.
    _fx.nowSec += dt;
    if (_fx.breath > 0) _fx.breath = max(0, _fx.breath - dt * 1.8);

    // Sparkles trailing every mover that is outside its zone.
    _sparkleAccMs += dtMs;
    if (_sparkleAccMs >= 60 && _fx.particles.length < 260) {
      _sparkleAccMs = 0;
      for (final actor in engine.actors) {
        if (!actor.alive || !actor.isOutside) continue;
        _fx.particles.add(
          FxParticle(
            cx: actor.x + 0.5 + (_rng.nextDouble() - 0.5) * 0.7,
            cy: actor.y + 0.5 + (_rng.nextDouble() - 0.5) * 0.7,
            vx: (_rng.nextDouble() - 0.5) * 1.5,
            vy: (_rng.nextDouble() - 0.5) * 1.5 - 0.6,
            life: 0.4 + _rng.nextDouble() * 0.25,
            size: 0.22 + _rng.nextDouble() * 0.3,
            color: Color.lerp(Color(actor.colorArgb), Colors.white, 0.55)!,
          ),
        );
      }
    }

    for (final p in _fx.particles) {
      p.age += dt;
      if (p.gravity) p.vy += 7.5 * dt;
      if (p.confetti) p.rot += dt * 5;
      p.cx += p.vx * dt;
      p.cy += p.vy * dt;
    }
    _fx.particles.removeWhere((p) => p.dead);
    for (final r in _fx.rings) {
      r.age += dt;
    }
    _fx.rings.removeWhere((r) => r.dead);
    for (final p in _fx.popups) {
      p.age += dt;
    }
    _fx.popups.removeWhere((p) => p.dead);

    _fx.flash = max(0, _fx.flash - dt * 0.85);

    // Danger: nearest living bot to any exposed player trail cell.
    var danger = 0.0;
    final player = engine.player;
    if (player.alive && player.isOutside) {
      var best = 1 << 30;
      for (final bot in engine.actors) {
        if (bot.isPlayer || !bot.alive) continue;
        for (final cell in player.trailSet) {
          final d =
              (bot.x - cell % TerritoryEngine.cols).abs() +
              (bot.y - cell ~/ TerritoryEngine.cols).abs();
          if (d < best) best = d;
        }
      }
      if (best <= 6) {
        danger = 0.55 + 0.4 * sin(_now.inMilliseconds / 95.0);
      }
    }
    _fx.danger = danger.clamp(0.0, 1.0);

    // Combo cools off with its 4-second window.
    if (_combo > 0 && _now - _lastCaptureAt > const Duration(seconds: 4)) {
      _combo = 0;
    }
  }

  void _restart() {
    SoundService.instance.play(GameSound.pop);
    setState(() {
      engine = _newEngine();
      _lastLives = engine.lives;
      _lastCaptureCount = 0;
      _lastBotKillCount = 0;
      _lastPickupEvents = 0;
      _lastShieldBreakEvents = 0;
      _earnedPoints = 0;
      _newRank = null;
      _outcomeSaved = false;
      _accMs = 0;
      paused = false;
      won = false;
      lost = false;
      _ended = false;
      _endVictory = false;
      _endTitle = '';
      _endSubtitle = '';
      _elapsed = Duration.zero;
      _peakPercent = engine.playerPercent;
      _fx.clear();
      _combo = 0;
      _killBanner = '';
    });
  }

  Future<void> _toggleMute() async {
    final newValue = !muted;
    setState(() => muted = newValue);
    await SoundService.instance.setMuted(newValue);
    await widget.progressStore.setMuted(newValue);
    if (!newValue) SoundService.instance.play(GameSound.pop);
  }

  void _togglePaused() {
    SoundService.instance.play(GameSound.pop);
    setState(() => paused = !paused);
    if (paused) {
      SoundService.instance.pauseMusic();
    } else {
      SoundService.instance.resumeMusic();
    }
  }

  void _resume() {
    SoundService.instance.play(GameSound.pop);
    setState(() => paused = false);
    SoundService.instance.resumeMusic();
  }

  void _goHome() {
    SoundService.instance.play(GameSound.pop);
    Navigator.of(context).pop();
  }

  /// Steer toward the finger: the blob heads in the direction from its
  /// own on-screen position to the touch point. This matches browser
  /// play — press and drag, the blob follows your finger — and it does
  /// not depend on per-event drag deltas, which jitter on touchscreens.
  void _steerTo(Offset globalPosition) {
    final box = _boardKey.currentContext?.findRenderObject() as RenderBox?;
    if (box == null || !box.hasSize) return;
    final local = box.globalToLocal(globalPosition);
    final cell = box.size.width / TerritoryEngine.cols;
    final center = Offset(
      (engine.player.x + 0.5) * cell,
      (engine.player.y + 0.5) * cell,
    );
    final v = local - center;
    // Deadzone around the blob itself so a resting finger near it does
    // not flip the heading back and forth.
    if (v.distance < cell * 1.2) return;
    final ax = v.dx.abs();
    final ay = v.dy.abs();
    if (ax > ay * 1.2) {
      engine.setPlayerDirection(v.dx > 0 ? 1 : -1, 0);
    } else if (ay > ax * 1.2) {
      engine.setPlayerDirection(0, v.dy > 0 ? 1 : -1);
    }
  }

  @override
  Widget build(BuildContext context) {
    final percent = engine.playerPercent;
    final goal = widget.level.goalPercent;
    final bg = Color(widget.level.backgroundArgb);
    final showBanner = _killBanner.isNotEmpty && _now < _killBannerUntil;

    final board = AspectRatio(
      aspectRatio: 1,
      child: RepaintBoundary(
        child: Container(
          key: _boardKey,
          decoration: BoxDecoration(
            color: Color(widget.level.neutralArgb),
            borderRadius: BorderRadius.circular(16),
            boxShadow: const [
              BoxShadow(
                color: Colors.black38,
                blurRadius: 14,
                offset: Offset(0, 6),
              ),
            ],
          ),
          child: ClipRRect(
            borderRadius: BorderRadius.circular(16),
            child: Stack(
              children: [
                Positioned.fill(
                  child: CustomPaint(
                    painter: BoardPainter(
                      engine,
                      _interp,
                      _fx,
                      cache: _renderCache,
                      playerSkin: _skin,
                    ),
                  ),
                ),
                Positioned(
                  right: 8,
                  bottom: 8,
                  child: RepaintBoundary(
                    child: Container(
                      width: 84,
                      height: 84,
                      decoration: BoxDecoration(
                        color: Colors.black.withValues(alpha: 0.35),
                        borderRadius: BorderRadius.circular(10),
                        border: Border.all(
                          color: Colors.white.withValues(alpha: 0.35),
                          width: 1.2,
                        ),
                      ),
                      child: ClipRRect(
                        borderRadius: BorderRadius.circular(9),
                        child: CustomPaint(
                          painter: MinimapPainter(
                            engine,
                            interp: _interp,
                            cache: _renderCache,
                          ),
                        ),
                      ),
                    ),
                  ),
                ),
                if (showBanner)
                  Positioned(
                    top: 10,
                    left: 0,
                    right: 0,
                    child: Center(
                      child: Container(
                        padding: const EdgeInsets.symmetric(
                          horizontal: 16,
                          vertical: 7,
                        ),
                        decoration: BoxDecoration(
                          gradient: const LinearGradient(
                            colors: [Color(0xFFFF8A00), Color(0xFFFF2D55)],
                          ),
                          borderRadius: BorderRadius.circular(999),
                          boxShadow: const [
                            BoxShadow(
                              color: Colors.black38,
                              blurRadius: 8,
                              offset: Offset(0, 3),
                            ),
                          ],
                        ),
                        child: Text(
                          _killBanner,
                          style: const TextStyle(
                            color: Colors.white,
                            fontWeight: FontWeight.w900,
                            fontSize: 15,
                          ),
                        ),
                      ),
                    ),
                  ),
              ],
            ),
          ),
        ),
      ),
    );

    final leaderboard = Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text(
          'Ranking',
          style: TextStyle(
            fontWeight: FontWeight.w900,
            fontSize: 15,
            color: Colors.white,
          ),
        ),
        const SizedBox(height: 6),
        ...engine.leaderboard.asMap().entries.map((entry) {
          final rank = entry.key + 1;
          final a = entry.value;
          final p = engine.percentFor(a.id);
          return Container(
            margin: const EdgeInsets.symmetric(vertical: 2.5),
            padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 5),
            decoration: BoxDecoration(
              // Glossed pill: brighter top edge, soft floor shadow.
              gradient: LinearGradient(
                begin: Alignment.topCenter,
                end: Alignment.bottomCenter,
                colors: a.isPlayer
                    ? [
                        Color(
                          engine.player.colorArgb,
                        ).withValues(alpha: 0.40),
                        Color(
                          engine.player.colorArgb,
                        ).withValues(alpha: 0.20),
                      ]
                    : [
                        Colors.white.withValues(alpha: 0.16),
                        Colors.white.withValues(alpha: 0.07),
                      ],
              ),
              borderRadius: BorderRadius.circular(999),
              border: a.isPlayer
                  ? Border.all(
                      color: Color(engine.player.colorArgb),
                      width: 1.4,
                    )
                  : null,
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withValues(alpha: 0.18),
                  blurRadius: 4,
                  offset: const Offset(0, 1),
                ),
              ],
            ),
            child: Row(
              children: [
                SizedBox(
                  width: 20,
                  child: Text(
                    '$rank',
                    style: const TextStyle(
                      color: Colors.white70,
                      fontWeight: FontWeight.w900,
                      fontSize: 12,
                    ),
                  ),
                ),
                if (rank == 1)
                  const Text('👑 ', style: TextStyle(fontSize: 12)),
                CircleAvatar(radius: 6, backgroundColor: Color(a.colorArgb)),
                const SizedBox(width: 6),
                Expanded(
                  child: Text(
                    a.isPlayer ? 'You' : a.name,
                    style: TextStyle(
                      color: Colors.white,
                      fontWeight: a.isPlayer
                          ? FontWeight.w900
                          : FontWeight.w600,
                    ),
                  ),
                ),
                Text(
                  '${p.toStringAsFixed(1)}%',
                  style: const TextStyle(
                    color: Colors.white,
                    fontWeight: FontWeight.w800,
                  ),
                ),
              ],
            ),
          );
        }),
        const SizedBox(height: 8),
        Wrap(
          spacing: 8,
          runSpacing: 6,
          children: [
            _chip(
              Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  const Text('☠', style: TextStyle(fontSize: 13)),
                  const SizedBox(width: 4),
                  Text(
                    '${engine.playerBotKills}',
                    style: const TextStyle(
                      color: Colors.white,
                      fontWeight: FontWeight.w900,
                    ),
                  ),
                ],
              ),
            ),
            _chip(
              Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  for (var i = 0; i < engine.maxLives; i++)
                    Icon(
                      Icons.favorite,
                      size: 15,
                      color: i < engine.lives
                          ? const Color(0xFFFF5D7A)
                          : Colors.white30,
                    ),
                ],
              ),
            ),
            _chip(
              Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  const Icon(Icons.star, color: Color(0xFFFFD93D), size: 15),
                  const SizedBox(width: 4),
                  Text(
                    '${engine.score}',
                    style: const TextStyle(
                      color: Colors.white,
                      fontWeight: FontWeight.w900,
                    ),
                  ),
                ],
              ),
            ),
            if (_combo >= 2)
              TweenAnimationBuilder<double>(
                key: ValueKey(_combo),
                tween: Tween(begin: 1.35, end: 1.0),
                duration: const Duration(milliseconds: 220),
                curve: Curves.easeOut,
                builder: (context, s, child) =>
                    Transform.scale(scale: s, child: child),
                child: Container(
                  padding: const EdgeInsets.symmetric(
                    horizontal: 10,
                    vertical: 5,
                  ),
                  decoration: BoxDecoration(
                    gradient: const LinearGradient(
                      colors: [Color(0xFFFFB020), Color(0xFFFF2D55)],
                    ),
                    borderRadius: BorderRadius.circular(999),
                    boxShadow: const [
                      BoxShadow(
                        color: Colors.black26,
                        blurRadius: 6,
                        offset: Offset(0, 2),
                      ),
                    ],
                  ),
                  child: Text(
                    '🔥 COMBO x$_combo',
                    style: const TextStyle(
                      color: Colors.white,
                      fontWeight: FontWeight.w900,
                      fontSize: 13,
                    ),
                  ),
                ),
              ),
          ],
        ),
      ],
    );

    return Scaffold(
      backgroundColor: bg,
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        foregroundColor: Colors.white,
        title: Text(
          widget.mode == GameMode.classic
              ? 'Level ${widget.level.id} · ${widget.level.name}'
              : 'Level ${widget.level.id} · ${widget.level.name} · ${widget.mode.label}',
          style: const TextStyle(fontWeight: FontWeight.w900),
        ),
        actions: [
          IconButton(
            icon: Icon(muted ? Icons.volume_off : Icons.volume_up),
            onPressed: _toggleMute,
          ),
          IconButton(
            icon: Icon(paused ? Icons.play_arrow : Icons.pause),
            onPressed: won || lost ? null : _togglePaused,
          ),
          IconButton(icon: const Icon(Icons.refresh), onPressed: _restart),
        ],
      ),
      body: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [
              Color.lerp(bg, Colors.white, 0.07)!,
              bg,
              Color.lerp(bg, Colors.black, 0.35)!,
            ],
          ),
        ),
        child: GestureDetector(
          onPanDown: (d) => _steerTo(d.globalPosition),
          onPanStart: (d) => _steerTo(d.globalPosition),
          onPanUpdate: (d) => _steerTo(d.globalPosition),
          child: Stack(
            children: [
              Column(
                children: [
                  Padding(
                    padding: const EdgeInsets.fromLTRB(16, 4, 16, 8),
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Text(
                          '${percent.toStringAsFixed(1)}%',
                          style: const TextStyle(
                            fontSize: 26,
                            fontWeight: FontWeight.w900,
                            color: Colors.white,
                            shadows: [
                              Shadow(
                                color: Colors.black38,
                                blurRadius: 4,
                                offset: Offset(0, 2),
                              ),
                            ],
                          ),
                        ),
                        const SizedBox(width: 12),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.end,
                            children: [
                              Text(
                                'GOAL ${goal.toStringAsFixed(0)}%',
                                style: const TextStyle(
                                  color: Colors.white70,
                                  fontWeight: FontWeight.w800,
                                  fontSize: 11,
                                  letterSpacing: 0.6,
                                ),
                              ),
                              const SizedBox(height: 3),
                              LayoutBuilder(
                                builder: (context, c) {
                                  return Stack(
                                    clipBehavior: Clip.none,
                                    children: [
                                      Container(
                                        height: 26,
                                        decoration: BoxDecoration(
                                          color: Colors.black.withValues(
                                            alpha: 0.4,
                                          ),
                                          borderRadius: BorderRadius.circular(
                                            13,
                                          ),
                                          border: Border.all(
                                            color: Colors.white.withValues(
                                              alpha: 0.18,
                                            ),
                                          ),
                                        ),
                                      ),
                                      FractionallySizedBox(
                                        widthFactor: (percent / 100).clamp(
                                          0.0,
                                          1.0,
                                        ),
                                        child: Container(
                                          height: 26,
                                          decoration: BoxDecoration(
                                            // Vertical gloss: pale top,
                                            // saturated heart, deep foot.
                                            gradient: const LinearGradient(
                                              begin: Alignment.topCenter,
                                              end: Alignment.bottomCenter,
                                              colors: [
                                                Color(0xFFFF9A85),
                                                Color(0xFFFF6A5F),
                                                Color(0xFFFFB020),
                                              ],
                                              stops: [0.0, 0.45, 1.0],
                                            ),
                                            borderRadius: BorderRadius.circular(
                                              13,
                                            ),
                                          ),
                                        ),
                                      ),
                                      Positioned(
                                        left: (c.maxWidth * goal / 100) - 11,
                                        top: -5,
                                        child: Container(
                                          width: 22,
                                          height: 22,
                                          decoration: BoxDecoration(
                                            color: const Color(0xFFFFD93D),
                                            shape: BoxShape.circle,
                                            border: Border.all(
                                              color: Colors.white,
                                              width: 1.6,
                                            ),
                                            boxShadow: const [
                                              BoxShadow(
                                                color: Colors.black38,
                                                blurRadius: 4,
                                              ),
                                            ],
                                          ),
                                          child: const Icon(
                                            Icons.star,
                                            size: 13,
                                            color: Color(0xFF8A5A00),
                                          ),
                                        ),
                                      ),
                                    ],
                                  );
                                },
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                  _statusRow(),
                  Expanded(
                    child: LayoutBuilder(
                      builder: (context, c) {
                        final wide = c.maxWidth > c.maxHeight + 120;
                        if (wide) {
                          return Padding(
                            padding: const EdgeInsets.all(12),
                            child: Row(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Expanded(child: Center(child: board)),
                                const SizedBox(width: 14),
                                SizedBox(width: 200, child: leaderboard),
                              ],
                            ),
                          );
                        }
                        return Padding(
                          padding: const EdgeInsets.all(12),
                          child: Column(
                            children: [
                              Expanded(child: Center(child: board)),
                              const SizedBox(height: 10),
                              leaderboard,
                            ],
                          ),
                        );
                      },
                    ),
                  ),
                ],
              ),
              if (paused && !_ended)
                _overlay(
                  title: 'Paused',
                  buttons: [
                    ElevatedButton(
                      onPressed: _resume,
                      child: const Text('Resume'),
                    ),
                    TextButton(
                      onPressed: _restart,
                      child: const Text('Restart'),
                    ),
                    TextButton(onPressed: _goHome, child: const Text('Home')),
                  ],
                ),
              if (_ended)
                _overlay(
                  title: _endTitle,
                  subtitle: _endSubtitle,
                  banner: _newRank == null
                      ? null
                      : Container(
                          padding: const EdgeInsets.symmetric(
                            horizontal: 16,
                            vertical: 9,
                          ),
                          decoration: BoxDecoration(
                            gradient: const LinearGradient(
                              colors: [Color(0xFFFFD93D), Color(0xFFFF8A00)],
                            ),
                            borderRadius: BorderRadius.circular(999),
                            boxShadow: [
                              BoxShadow(
                                color: const Color(0xFFFF8A00)
                                    .withValues(alpha: 0.45),
                                blurRadius: 12,
                                offset: const Offset(0, 4),
                              ),
                            ],
                          ),
                          child: Text(
                            '🏆 New rank: ${_newRank!.icon} ${_newRank!.name}!',
                            style: const TextStyle(
                              color: Colors.white,
                              fontWeight: FontWeight.w900,
                              fontSize: 16,
                              shadows: [
                                Shadow(
                                  color: Colors.black26,
                                  blurRadius: 4,
                                  offset: Offset(0, 1),
                                ),
                              ],
                            ),
                          ),
                        ),
                  buttons: [
                    if (_endVictory && widget.level.id < kLevels.length)
                      ElevatedButton(
                        onPressed: () {
                          SoundService.instance.play(GameSound.pop);
                          Navigator.of(context).pushReplacement(
                            MaterialPageRoute(
                              builder: (_) => GameScreen(
                                level: kLevels[widget.level.id],
                                progressStore: widget.progressStore,
                                mode: widget.mode,
                              ),
                            ),
                          );
                        },
                        child: const Text('Next Level'),
                      ),
                    ElevatedButton(
                      onPressed: _restart,
                      child: Text(_endVictory ? 'Play Again' : 'Try Again'),
                    ),
                    TextButton(onPressed: _goHome, child: const Text('Home')),
                  ],
                ),
            ],
          ),
        ),
      ),
    );
  }

  /// Mode clock/standing chips plus live power-up effect chips. Hidden
  /// entirely when there is nothing to show (Classic, no effects).
  Widget _statusRow() {
    final children = <Widget>[
      if (widget.mode != GameMode.classic) _modeHudChip(),
      ..._effectChips(),
    ];
    if (children.isEmpty) return const SizedBox(height: 4);
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 0, 16, 4),
      child: Wrap(spacing: 8, runSpacing: 6, children: children),
    );
  }

  String _secsLeft(int steps) => '${(steps * _stepMs / 1000).ceil()}s';

  /// Chips for the player's timed effects (and freeze state), each with
  /// its remaining time. They mirror engine state, so they tick down
  /// with the game and vanish on expiry.
  List<Widget> _effectChips() {
    final player = engine.player;
    Text label(String text, Color color) => Text(
      text,
      style: TextStyle(color: color, fontWeight: FontWeight.w900, fontSize: 13),
    );
    return [
      if (player.speedBoostSteps > 0)
        _chip(
          label(
            '${PowerUpKind.speed.emoji} Speed ${_secsLeft(player.speedBoostSteps)}',
            const Color(0xFFFFB020),
          ),
        ),
      if (player.hasShield)
        _chip(
          label(
            '${PowerUpKind.shield.emoji} Shield ${_secsLeft(player.shieldSteps)}',
            const Color(0xFF7DD3FC),
          ),
        ),
      if (engine.botsFrozenSteps > 0)
        _chip(
          label(
            '${PowerUpKind.freeze.emoji} Bots slowed ${_secsLeft(engine.botsFrozenSteps)}',
            const Color(0xFFA5F3FC),
          ),
        ),
      if (engine.playerFrozenSteps > 0)
        _chip(
          label(
            '${PowerUpKind.freeze.emoji} You are slowed ${_secsLeft(engine.playerFrozenSteps)}',
            const Color(0xFFFDA4AF),
          ),
        ),
    ];
  }

  /// Clock / standing strip shown in Quick Match and Survival.
  Widget _modeHudChip() {
    const textStyle = TextStyle(
      color: Colors.white,
      fontWeight: FontWeight.w900,
      fontSize: 13,
    );
    if (widget.mode == GameMode.quickMatch) {
      final remaining = Duration(seconds: kQuickMatchSeconds) - _elapsed;
      final clamped = remaining.isNegative ? Duration.zero : remaining;
      final urgent = clamped.inSeconds < 30;
      final s = quickStanding(engine);
      return Wrap(
        spacing: 8,
        children: [
          _chip(
            Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                Icon(
                  Icons.timer,
                  size: 15,
                  color: urgent
                      ? const Color(0xFFFF5D7A)
                      : const Color(0xFFFFD93D),
                ),
                const SizedBox(width: 4),
                Text(
                  _fmtTime(clamped),
                  style: TextStyle(
                    color: urgent ? const Color(0xFFFF5D7A) : Colors.white,
                    fontWeight: FontWeight.w900,
                    fontSize: 13,
                  ),
                ),
              ],
            ),
          ),
          _chip(
            Text(
              s.isLeading ? '🏆 Leading' : '#${s.rank} of ${s.totalActors}',
              style: textStyle,
            ),
          ),
          _chip(
            Text(
              'Goal ${widget.level.goalPercent.toStringAsFixed(0)}%',
              style: textStyle,
            ),
          ),
        ],
      );
    }
    // Survival: elapsed time + peak claim.
    return Wrap(
      spacing: 8,
      children: [
        _chip(
          Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              const Icon(Icons.timer, size: 15, color: Color(0xFFFFD93D)),
              const SizedBox(width: 4),
              Text(_fmtTime(_elapsed), style: textStyle),
            ],
          ),
        ),
        _chip(
          Text('Peak ${_peakPercent.toStringAsFixed(1)}%', style: textStyle),
        ),
      ],
    );
  }

  Widget _chip(Widget child) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
      decoration: BoxDecoration(
        // Glassy pill: light catches the top-left, shadow grounds it.
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [
            Colors.white.withValues(alpha: 0.22),
            Colors.black.withValues(alpha: 0.38),
          ],
        ),
        borderRadius: BorderRadius.circular(999),
        border: Border.all(color: Colors.white.withValues(alpha: 0.28)),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: 0.25),
            blurRadius: 6,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: child,
    );
  }

  Widget _overlay({
    required String title,
    String? subtitle,
    Widget? banner,
    required List<Widget> buttons,
  }) {
    return Positioned.fill(
      child: Container(
        color: Colors.black.withValues(alpha: 0.55),
        child: Center(
          child: Card(
            color: const Color(0xFF10222E),
            margin: const EdgeInsets.all(24),
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(24),
            ),
            child: Padding(
              padding: const EdgeInsets.all(24),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Text(
                    title,
                    style: const TextStyle(
                      fontSize: 28,
                      fontWeight: FontWeight.w900,
                      color: Colors.white,
                    ),
                  ),
                  if (subtitle != null) ...[
                    const SizedBox(height: 8),
                    Text(
                      subtitle,
                      textAlign: TextAlign.center,
                      style: const TextStyle(color: Colors.white70),
                    ),
                  ],
                  if (banner != null) ...[const SizedBox(height: 14), banner],
                  const SizedBox(height: 16),
                  ...buttons.map(
                    (b) => Padding(
                      padding: const EdgeInsets.symmetric(vertical: 3),
                      child: b,
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
