import 'dart:async';
import 'dart:math';

import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart';
import 'package:flutter/services.dart';

import '../game/territory_engine.dart';
import '../services/progress_store.dart';
import '../services/sound_service.dart';
import '../widgets/board_painter.dart';

class GameScreen extends StatefulWidget {
  final LevelConfig level;
  final ProgressStore progressStore;

  const GameScreen({
    super.key,
    required this.level,
    required this.progressStore,
  });

  @override
  State<GameScreen> createState() => _GameScreenState();
}

class _GameScreenState extends State<GameScreen>
    with SingleTickerProviderStateMixin {
  late TerritoryEngine engine;
  late final Ticker _ticker;
  Duration _last = Duration.zero;
  Duration _now = Duration.zero;
  double _accMs = 0;
  static const double _stepMs = 92;

  bool paused = false;
  bool muted = false;
  bool won = false;
  bool lost = false;
  int _lastLives = 3;
  int _lastCaptureCount = 0;
  int _lastBotKillCount = 0;
  bool _outcomeSaved = false;

  // Juice state.
  final FxState _fx = FxState();
  final Random _rng = Random();
  double _sparkleAccMs = 0;
  int _combo = 0;
  Duration _lastCaptureAt = Duration.zero;
  String _killBanner = '';
  Duration _killBannerUntil = Duration.zero;

  /// Key on the board widget so steering can measure where the finger
  /// is relative to the player's blob on screen.
  final GlobalKey _boardKey = GlobalKey();

  @override
  void initState() {
    super.initState();
    muted = widget.progressStore.progress.muted;
    SoundService.instance.muted = muted;
    engine = TerritoryEngine(widget.level);
    _ticker = createTicker(_onTick)..start();
  }

  @override
  void dispose() {
    _ticker.dispose();
    super.dispose();
  }

  void _onTick(Duration elapsed) {
    if (_last == Duration.zero) {
      _last = elapsed;
      _now = elapsed;
      return;
    }
    final dt = (elapsed - _last).inMicroseconds / 1000.0;
    _last = elapsed;
    _now = elapsed;
    if (!paused && !won && !lost) {
      _accMs += dt;
      while (_accMs >= _stepMs) {
        _accMs -= _stepMs;
        engine.step();
      }
      final p = engine.playerPercent;
      if (engine.playerCaptureCount > _lastCaptureCount) {
        _lastCaptureCount = engine.playerCaptureCount;
        SoundService.instance.play(GameSound.capture);
        if (!muted) HapticFeedback.lightImpact();
        _onPlayerCapture();
      }
      if (engine.playerBotKills > _lastBotKillCount) {
        _lastBotKillCount = engine.playerBotKills;
        SoundService.instance.play(GameSound.pop);
        _onPlayerKill();
      }
      if (engine.lives < _lastLives) {
        _lastLives = engine.lives;
        if (!engine.gameOver) {
          SoundService.instance.play(GameSound.die);
        }
        if (!muted) HapticFeedback.heavyImpact();
        _burst(
          engine.lastPlayerDeathX + 0.5,
          engine.lastPlayerDeathY + 0.5,
          const Color(kPlayerColor),
          22,
        );
        _fx.flash = max(_fx.flash, 0.22);
      }
      if (engine.playerWon) {
        won = true;
        SoundService.instance.play(GameSound.win);
        if (!muted) HapticFeedback.mediumImpact();
        _confetti();
        if (!_outcomeSaved) {
          _outcomeSaved = true;
          unawaited(
            widget.progressStore.recordWin(
              levelId: widget.level.id,
              percent: p,
              totalLevels: kLevels.length,
            ),
          );
        }
      } else if (engine.gameOver) {
        lost = true;
        SoundService.instance.play(GameSound.lose);
        if (!muted) HapticFeedback.heavyImpact();
        if (!_outcomeSaved) {
          _outcomeSaved = true;
          unawaited(
            widget.progressStore.recordBest(
              levelId: widget.level.id,
              percent: p,
            ),
          );
        }
      }
      _updateFx(dt);
    }
    if (mounted) setState(() {});
  }

  void _onPlayerCapture() {
    final gainedCells = engine.lastPlayerCaptureGainedCells;
    final gainedPct = gainedCells * 100.0 / TerritoryEngine.totalCells;
    final cx = engine.lastPlayerCaptureX + 0.5;
    final cy = engine.lastPlayerCaptureY + 0.5;

    // Combo: captures chained within 4 seconds.
    if (_now - _lastCaptureAt <= const Duration(seconds: 4)) {
      _combo++;
    } else {
      _combo = 1;
    }
    _lastCaptureAt = _now;

    final big = gainedPct >= 2.5;
    _burst(cx, cy, const Color(kPlayerColor), big ? 30 : 16);
    _fx.rings.add(
      FxRing(cx: cx, cy: cy, color: const Color(kPlayerColor)),
    );
    _fx.popups.add(
      FxPopup(
        cx: cx,
        cy: cy - 1.2,
        text: '+${gainedPct.toStringAsFixed(1)}%',
        color: big ? const Color(0xFFFFD93D) : Colors.white,
      ),
    );
    if (big) _fx.flash = max(_fx.flash, 0.3);
  }

  void _onPlayerKill() {
    _killBanner = 'You cut ${engine.lastPlayerKillName}!';
    _killBannerUntil = _now + const Duration(milliseconds: 1800);
    _burst(
      engine.lastPlayerKillX + 0.5,
      engine.lastPlayerKillY + 0.5,
      const Color(0xFFFFD93D),
      18,
    );
    if (!muted) HapticFeedback.mediumImpact();
  }

  void _burst(double cx, double cy, Color color, int count) {
    for (var i = 0; i < count; i++) {
      final angle = _rng.nextDouble() * 2 * pi;
      final speed = 4 + _rng.nextDouble() * 9;
      _fx.particles.add(
        FxParticle(
          cx: cx,
          cy: cy,
          vx: cos(angle) * speed,
          vy: sin(angle) * speed,
          life: 0.45 + _rng.nextDouble() * 0.4,
          size: 0.35 + _rng.nextDouble() * 0.45,
          color: Color.lerp(color, Colors.white, _rng.nextDouble() * 0.4)!,
        ),
      );
    }
  }

  void _confetti() {
    const colors = [
      Color(0xFFFF4757),
      Color(0xFFFFB020),
      Color(0xFF2EE6A8),
      Color(0xFF3E9BFF),
      Color(0xFFFF5D8F),
      Color(0xFFB06BFF),
    ];
    for (var i = 0; i < 90; i++) {
      _fx.particles.add(
        FxParticle(
          cx: _rng.nextDouble() * TerritoryEngine.cols,
          cy: -2 - _rng.nextDouble() * 10,
          vx: (_rng.nextDouble() - 0.5) * 3,
          vy: 5 + _rng.nextDouble() * 6,
          life: 1.6 + _rng.nextDouble() * 1.2,
          size: 0.4 + _rng.nextDouble() * 0.5,
          color: colors[_rng.nextInt(colors.length)],
          gravity: true,
          confetti: true,
          rot: _rng.nextDouble() * pi,
        ),
      );
    }
  }

  void _updateFx(double dtMs) {
    final dt = dtMs / 1000.0;

    // Sparkles trailing every mover that is outside its zone.
    _sparkleAccMs += dtMs;
    if (_sparkleAccMs >= 60 && _fx.particles.length < 420) {
      _sparkleAccMs = 0;
      for (final actor in engine.actors) {
        if (!actor.alive || !actor.isOutside) continue;
        _fx.particles.add(
          FxParticle(
            cx: actor.x + 0.5 + (_rng.nextDouble() - 0.5) * 0.7,
            cy: actor.y + 0.5 + (_rng.nextDouble() - 0.5) * 0.7,
            vx: (_rng.nextDouble() - 0.5) * 1.5,
            vy: (_rng.nextDouble() - 0.5) * 1.5 - 0.6,
            life: 0.4 + _rng.nextDouble() * 0.25,
            size: 0.22 + _rng.nextDouble() * 0.3,
            color: Color.lerp(
              Color(actor.colorArgb),
              Colors.white,
              0.55,
            )!,
          ),
        );
      }
    }

    for (final p in _fx.particles) {
      p.age += dt;
      if (p.gravity) p.vy += 7.5 * dt;
      if (p.confetti) p.rot += dt * 5;
      p.cx += p.vx * dt;
      p.cy += p.vy * dt;
    }
    _fx.particles.removeWhere((p) => p.dead);
    for (final r in _fx.rings) {
      r.age += dt;
    }
    _fx.rings.removeWhere((r) => r.dead);
    for (final p in _fx.popups) {
      p.age += dt;
    }
    _fx.popups.removeWhere((p) => p.dead);

    _fx.flash = max(0, _fx.flash - dt * 0.85);

    // Danger: nearest living bot to any exposed player trail cell.
    var danger = 0.0;
    final player = engine.player;
    if (player.alive && player.isOutside) {
      var best = 1 << 30;
      for (final bot in engine.actors) {
        if (bot.isPlayer || !bot.alive) continue;
        for (final cell in player.trailSet) {
          final d = (bot.x - cell % TerritoryEngine.cols).abs() +
              (bot.y - cell ~/ TerritoryEngine.cols).abs();
          if (d < best) best = d;
        }
      }
      if (best <= 6) {
        danger =
            0.55 + 0.4 * sin(_now.inMilliseconds / 95.0);
      }
    }
    _fx.danger = danger.clamp(0.0, 1.0);

    // Combo cools off with its 4-second window.
    if (_combo > 0 && _now - _lastCaptureAt > const Duration(seconds: 4)) {
      _combo = 0;
    }
  }

  void _restart() {
    SoundService.instance.play(GameSound.pop);
    setState(() {
      engine = TerritoryEngine(widget.level);
      _lastLives = engine.lives;
      _lastCaptureCount = 0;
      _lastBotKillCount = 0;
      _outcomeSaved = false;
      _accMs = 0;
      paused = false;
      won = false;
      lost = false;
      _fx.clear();
      _combo = 0;
      _killBanner = '';
    });
  }

  Future<void> _toggleMute() async {
    final newValue = !muted;
    setState(() => muted = newValue);
    await SoundService.instance.setMuted(newValue);
    await widget.progressStore.setMuted(newValue);
    if (!newValue) SoundService.instance.play(GameSound.pop);
  }

  void _togglePaused() {
    SoundService.instance.play(GameSound.pop);
    setState(() => paused = !paused);
  }

  void _resume() {
    SoundService.instance.play(GameSound.pop);
    setState(() => paused = false);
  }

  void _goHome() {
    SoundService.instance.play(GameSound.pop);
    Navigator.of(context).pop();
  }

  /// Steer toward the finger: the blob heads in the direction from its
  /// own on-screen position to the touch point. This matches browser
  /// play — press and drag, the blob follows your finger — and it does
  /// not depend on per-event drag deltas, which jitter on touchscreens.
  void _steerTo(Offset globalPosition) {
    final box = _boardKey.currentContext?.findRenderObject() as RenderBox?;
    if (box == null || !box.hasSize) return;
    final local = box.globalToLocal(globalPosition);
    final cell = box.size.width / TerritoryEngine.cols;
    final center = Offset(
      (engine.player.x + 0.5) * cell,
      (engine.player.y + 0.5) * cell,
    );
    final v = local - center;
    // Deadzone around the blob itself so a resting finger near it does
    // not flip the heading back and forth.
    if (v.distance < cell * 1.2) return;
    final ax = v.dx.abs();
    final ay = v.dy.abs();
    if (ax > ay * 1.2) {
      engine.setPlayerDirection(v.dx > 0 ? 1 : -1, 0);
    } else if (ay > ax * 1.2) {
      engine.setPlayerDirection(0, v.dy > 0 ? 1 : -1);
    }
  }

  @override
  Widget build(BuildContext context) {
    final percent = engine.playerPercent;
    final goal = widget.level.goalPercent;
    final t = (_accMs / _stepMs).clamp(0.0, 1.0);
    final bg = Color(widget.level.backgroundArgb);
    final showBanner = _killBanner.isNotEmpty && _now < _killBannerUntil;

    final board = AspectRatio(
      aspectRatio: 1,
      child: Container(
        key: _boardKey,
        decoration: BoxDecoration(
          color: Color(widget.level.neutralArgb),
          borderRadius: BorderRadius.circular(16),
          boxShadow: const [
            BoxShadow(
              color: Colors.black38,
              blurRadius: 14,
              offset: Offset(0, 6),
            ),
          ],
        ),
        child: ClipRRect(
          borderRadius: BorderRadius.circular(16),
          child: Stack(
            children: [
              Positioned.fill(
                child: CustomPaint(painter: BoardPainter(engine, t, _fx)),
              ),
              Positioned(
                right: 8,
                bottom: 8,
                child: Container(
                  width: 84,
                  height: 84,
                  decoration: BoxDecoration(
                    color: Colors.black.withValues(alpha: 0.35),
                    borderRadius: BorderRadius.circular(10),
                    border: Border.all(
                      color: Colors.white.withValues(alpha: 0.35),
                      width: 1.2,
                    ),
                  ),
                  child: ClipRRect(
                    borderRadius: BorderRadius.circular(9),
                    child: CustomPaint(painter: MinimapPainter(engine)),
                  ),
                ),
              ),
              if (showBanner)
                Positioned(
                  top: 10,
                  left: 0,
                  right: 0,
                  child: Center(
                    child: Container(
                      padding: const EdgeInsets.symmetric(
                        horizontal: 16,
                        vertical: 7,
                      ),
                      decoration: BoxDecoration(
                        gradient: const LinearGradient(
                          colors: [Color(0xFFFF8A00), Color(0xFFFF2D55)],
                        ),
                        borderRadius: BorderRadius.circular(999),
                        boxShadow: const [
                          BoxShadow(
                            color: Colors.black38,
                            blurRadius: 8,
                            offset: Offset(0, 3),
                          ),
                        ],
                      ),
                      child: Text(
                        _killBanner,
                        style: const TextStyle(
                          color: Colors.white,
                          fontWeight: FontWeight.w900,
                          fontSize: 15,
                        ),
                      ),
                    ),
                  ),
                ),
            ],
          ),
        ),
      ),
    );

    final leaderboard = Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text(
          'Ranking',
          style: TextStyle(
            fontWeight: FontWeight.w900,
            fontSize: 15,
            color: Colors.white,
          ),
        ),
        const SizedBox(height: 6),
        ...engine.leaderboard.asMap().entries.map((entry) {
          final rank = entry.key + 1;
          final a = entry.value;
          final p = engine.percentFor(a.id);
          return Container(
            margin: const EdgeInsets.symmetric(vertical: 2.5),
            padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 5),
            decoration: BoxDecoration(
              color: a.isPlayer
                  ? const Color(kPlayerColor).withValues(alpha: 0.28)
                  : Colors.white.withValues(alpha: 0.10),
              borderRadius: BorderRadius.circular(999),
              border: a.isPlayer
                  ? Border.all(
                      color: const Color(kPlayerColor),
                      width: 1.4,
                    )
                  : null,
            ),
            child: Row(
              children: [
                SizedBox(
                  width: 20,
                  child: Text(
                    '$rank',
                    style: const TextStyle(
                      color: Colors.white70,
                      fontWeight: FontWeight.w900,
                      fontSize: 12,
                    ),
                  ),
                ),
                if (rank == 1) const Text('👑 ', style: TextStyle(fontSize: 12)),
                CircleAvatar(radius: 6, backgroundColor: Color(a.colorArgb)),
                const SizedBox(width: 6),
                Expanded(
                  child: Text(
                    a.isPlayer ? 'You' : a.name,
                    style: TextStyle(
                      color: Colors.white,
                      fontWeight: a.isPlayer
                          ? FontWeight.w900
                          : FontWeight.w600,
                    ),
                  ),
                ),
                Text(
                  '${p.toStringAsFixed(1)}%',
                  style: const TextStyle(
                    color: Colors.white,
                    fontWeight: FontWeight.w800,
                  ),
                ),
              ],
            ),
          );
        }),
        const SizedBox(height: 8),
        Wrap(
          spacing: 8,
          runSpacing: 6,
          children: [
            _chip(
              Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  const Text('☠', style: TextStyle(fontSize: 13)),
                  const SizedBox(width: 4),
                  Text(
                    '${engine.playerBotKills}',
                    style: const TextStyle(
                      color: Colors.white,
                      fontWeight: FontWeight.w900,
                    ),
                  ),
                ],
              ),
            ),
            _chip(
              Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  for (var i = 0; i < 3; i++)
                    Icon(
                      Icons.favorite,
                      size: 15,
                      color: i < engine.lives
                          ? const Color(0xFFFF5D7A)
                          : Colors.white30,
                    ),
                ],
              ),
            ),
            _chip(
              Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  const Icon(Icons.star, color: Color(0xFFFFD93D), size: 15),
                  const SizedBox(width: 4),
                  Text(
                    '${engine.score}',
                    style: const TextStyle(
                      color: Colors.white,
                      fontWeight: FontWeight.w900,
                    ),
                  ),
                ],
              ),
            ),
            if (_combo >= 2)
              TweenAnimationBuilder<double>(
                key: ValueKey(_combo),
                tween: Tween(begin: 1.35, end: 1.0),
                duration: const Duration(milliseconds: 220),
                curve: Curves.easeOut,
                builder: (context, s, child) =>
                    Transform.scale(scale: s, child: child),
                child: Container(
                  padding: const EdgeInsets.symmetric(
                    horizontal: 10,
                    vertical: 5,
                  ),
                  decoration: BoxDecoration(
                    gradient: const LinearGradient(
                      colors: [Color(0xFFFFB020), Color(0xFFFF2D55)],
                    ),
                    borderRadius: BorderRadius.circular(999),
                    boxShadow: const [
                      BoxShadow(
                        color: Colors.black26,
                        blurRadius: 6,
                        offset: Offset(0, 2),
                      ),
                    ],
                  ),
                  child: Text(
                    '🔥 COMBO x$_combo',
                    style: const TextStyle(
                      color: Colors.white,
                      fontWeight: FontWeight.w900,
                      fontSize: 13,
                    ),
                  ),
                ),
              ),
          ],
        ),
      ],
    );

    return Scaffold(
      backgroundColor: bg,
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        foregroundColor: Colors.white,
        title: Text(
          'Level ${widget.level.id} · ${widget.level.name}',
          style: const TextStyle(fontWeight: FontWeight.w900),
        ),
        actions: [
          IconButton(
            icon: Icon(muted ? Icons.volume_off : Icons.volume_up),
            onPressed: _toggleMute,
          ),
          IconButton(
            icon: Icon(paused ? Icons.play_arrow : Icons.pause),
            onPressed: won || lost ? null : _togglePaused,
          ),
          IconButton(icon: const Icon(Icons.refresh), onPressed: _restart),
        ],
      ),
      body: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [
              Color.lerp(bg, Colors.white, 0.07)!,
              bg,
              Color.lerp(bg, Colors.black, 0.35)!,
            ],
          ),
        ),
        child: GestureDetector(
          onPanDown: (d) => _steerTo(d.globalPosition),
          onPanStart: (d) => _steerTo(d.globalPosition),
          onPanUpdate: (d) => _steerTo(d.globalPosition),
          child: Stack(
            children: [
              Column(
                children: [
                  Padding(
                    padding: const EdgeInsets.fromLTRB(16, 4, 16, 8),
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Text(
                          '${percent.toStringAsFixed(1)}%',
                          style: const TextStyle(
                            fontSize: 26,
                            fontWeight: FontWeight.w900,
                            color: Colors.white,
                            shadows: [
                              Shadow(
                                color: Colors.black38,
                                blurRadius: 4,
                                offset: Offset(0, 2),
                              ),
                            ],
                          ),
                        ),
                        const SizedBox(width: 12),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.end,
                            children: [
                              Text(
                                'GOAL ${goal.toStringAsFixed(0)}%',
                                style: const TextStyle(
                                  color: Colors.white70,
                                  fontWeight: FontWeight.w800,
                                  fontSize: 11,
                                  letterSpacing: 0.6,
                                ),
                              ),
                              const SizedBox(height: 3),
                              LayoutBuilder(
                                builder: (context, c) {
                                  return Stack(
                                    clipBehavior: Clip.none,
                                    children: [
                                      Container(
                                        height: 26,
                                        decoration: BoxDecoration(
                                          color: Colors.black.withValues(
                                            alpha: 0.4,
                                          ),
                                          borderRadius: BorderRadius.circular(
                                            13,
                                          ),
                                          border: Border.all(
                                            color: Colors.white.withValues(
                                              alpha: 0.18,
                                            ),
                                          ),
                                        ),
                                      ),
                                      FractionallySizedBox(
                                        widthFactor: (percent / 100).clamp(
                                          0.0,
                                          1.0,
                                        ),
                                        child: Container(
                                          height: 26,
                                          decoration: BoxDecoration(
                                            gradient: const LinearGradient(
                                              colors: [
                                                Color(0xFFFF6A5F),
                                                Color(0xFFFFB020),
                                              ],
                                            ),
                                            borderRadius: BorderRadius.circular(
                                              13,
                                            ),
                                          ),
                                        ),
                                      ),
                                      Positioned(
                                        left: (c.maxWidth * goal / 100) - 11,
                                        top: -5,
                                        child: Container(
                                          width: 22,
                                          height: 22,
                                          decoration: BoxDecoration(
                                            color: const Color(0xFFFFD93D),
                                            shape: BoxShape.circle,
                                            border: Border.all(
                                              color: Colors.white,
                                              width: 1.6,
                                            ),
                                            boxShadow: const [
                                              BoxShadow(
                                                color: Colors.black38,
                                                blurRadius: 4,
                                              ),
                                            ],
                                          ),
                                          child: const Icon(
                                            Icons.star,
                                            size: 13,
                                            color: Color(0xFF8A5A00),
                                          ),
                                        ),
                                      ),
                                    ],
                                  );
                                },
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                  Expanded(
                    child: LayoutBuilder(
                      builder: (context, c) {
                        final wide = c.maxWidth > c.maxHeight + 120;
                        if (wide) {
                          return Padding(
                            padding: const EdgeInsets.all(12),
                            child: Row(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Expanded(child: Center(child: board)),
                                const SizedBox(width: 14),
                                SizedBox(width: 200, child: leaderboard),
                              ],
                            ),
                          );
                        }
                        return Padding(
                          padding: const EdgeInsets.all(12),
                          child: Column(
                            children: [
                              Expanded(child: Center(child: board)),
                              const SizedBox(height: 10),
                              leaderboard,
                            ],
                          ),
                        );
                      },
                    ),
                  ),
                ],
              ),
              if (paused && !won && !lost)
                _overlay(
                  title: 'Paused',
                  buttons: [
                    ElevatedButton(
                      onPressed: _resume,
                      child: const Text('Resume'),
                    ),
                    TextButton(
                      onPressed: _restart,
                      child: const Text('Restart'),
                    ),
                    TextButton(onPressed: _goHome, child: const Text('Home')),
                  ],
                ),
              if (won)
                _overlay(
                  title: 'Level Complete!',
                  subtitle:
                      'You claimed ${percent.toStringAsFixed(1)}% of the board.',
                  buttons: [
                    if (widget.level.id < kLevels.length)
                      ElevatedButton(
                        onPressed: () {
                          SoundService.instance.play(GameSound.pop);
                          Navigator.of(context).pushReplacement(
                            MaterialPageRoute(
                              builder: (_) => GameScreen(
                                level: kLevels[widget.level.id],
                                progressStore: widget.progressStore,
                              ),
                            ),
                          );
                        },
                        child: const Text('Next Level'),
                      ),
                    TextButton(
                      onPressed: _restart,
                      child: const Text('Play Again'),
                    ),
                    TextButton(onPressed: _goHome, child: const Text('Home')),
                  ],
                ),
              if (lost)
                _overlay(
                  title: 'Game Over',
                  subtitle:
                      'You claimed ${percent.toStringAsFixed(1)}%. Goal was ${goal.toStringAsFixed(0)}%.',
                  buttons: [
                    ElevatedButton(
                      onPressed: _restart,
                      child: const Text('Try Again'),
                    ),
                    TextButton(onPressed: _goHome, child: const Text('Home')),
                  ],
                ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _chip(Widget child) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
      decoration: BoxDecoration(
        color: Colors.black.withValues(alpha: 0.35),
        borderRadius: BorderRadius.circular(999),
        border: Border.all(color: Colors.white.withValues(alpha: 0.15)),
      ),
      child: child,
    );
  }

  Widget _overlay({
    required String title,
    String? subtitle,
    required List<Widget> buttons,
  }) {
    return Positioned.fill(
      child: Container(
        color: Colors.black.withValues(alpha: 0.55),
        child: Center(
          child: Card(
            color: const Color(0xFF10222E),
            margin: const EdgeInsets.all(24),
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(24),
            ),
            child: Padding(
              padding: const EdgeInsets.all(24),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Text(
                    title,
                    style: const TextStyle(
                      fontSize: 28,
                      fontWeight: FontWeight.w900,
                      color: Colors.white,
                    ),
                  ),
                  if (subtitle != null) ...[
                    const SizedBox(height: 8),
                    Text(
                      subtitle,
                      textAlign: TextAlign.center,
                      style: const TextStyle(color: Colors.white70),
                    ),
                  ],
                  const SizedBox(height: 16),
                  ...buttons.map(
                        (b) => Padding(
                          padding: const EdgeInsets.symmetric(vertical: 3),
                          child: b,
                        ),
                      ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
