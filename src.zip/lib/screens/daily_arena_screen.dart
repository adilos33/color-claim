/// Daily Arena lobby + 30-day history calendar.
///
/// New screens with no sibling equivalent: one deterministic board
/// per day, one banked score per day, and a mini calendar of the
/// last 30 days with win/skip marks. Fully offline.
library;

import 'package:flutter/material.dart';

import '../game/arena.dart';
import '../game/challenges.dart';
import '../game/daily_arena.dart';
import '../game/nemesis.dart';
import '../services/progress_store.dart';
import '../services/sound_service.dart';
import '../theme.dart';
import '../widgets/beveled_panel.dart';
import 'game_screen.dart';
import 'nemesis_screen.dart';

/// Opens today's Daily Arena match from any screen.
Future<void> openDailyArena(
  BuildContext context,
  ProgressStore progressStore,
) async {
  final today = DateTime.now();
  SoundService.instance.play(GameSound.pop);
  await Navigator.of(context).push(
    MaterialPageRoute(
      builder: (_) => GameScreen(
        level: dailyArenaLevel(today),
        progressStore: progressStore,
        isDailyArena: true,
        arenaDate: today,
      ),
    ),
  );
}

/// Today's Daily Arena: the board, the rival, the banked status, and
/// the (unchanged) daily-challenge checklist it upgrades.
class DailyArenaLobbyScreen extends StatefulWidget {
  final ProgressStore progressStore;

  const DailyArenaLobbyScreen({super.key, required this.progressStore});

  @override
  State<DailyArenaLobbyScreen> createState() => _DailyArenaLobbyScreenState();
}

class _DailyArenaLobbyScreenState extends State<DailyArenaLobbyScreen> {
  @override
  Widget build(BuildContext context) {
    final progress = widget.progressStore.progress;
    final today = DateTime.now();
    final shape = dailyArenaShape(today);
    final record = progress.arenaRecordFor(today);
    final difficulty = nemesisDifficultyFor(progress.dailyArenaHistory, today);
    final challenge = challengeForDate(today);
    final challengeDone = progress.dailyCompleted;
    return Scaffold(
      appBar: AppBar(
        title: Text('Daily Arena', style: displayHeading(size: 20)),
        backgroundColor: Colors.transparent,
        elevation: 0,
        foregroundColor: Colors.white,
      ),
      extendBodyBehindAppBar: true,
      body: Container(
        decoration: const BoxDecoration(gradient: kNightGradient),
        child: SafeArea(
          child: ListView(
            padding: const EdgeInsets.all(20),
            children: [
              Text(
                'ONE BOARD. EVERYONE. TODAY.',
                style: displayHeading(size: 15, color: kEmberLight),
              ),
              const SizedBox(height: 8),
              Text(
                'The same arena for every player today — no network, '
                'just the calendar. Your first scored run banks; '
                'replays are practice and never overwrite it.',
                style: const TextStyle(
                  color: Colors.white70,
                  fontWeight: FontWeight.w600,
                  fontSize: 14,
                  height: 1.4,
                ),
              ),
              const SizedBox(height: 16),
              BeveledPanel(
                gradient: kEmberGradient,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      '🏟 ${shape.label}',
                      style: displayHeading(size: 24),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      shape.description,
                      style: const TextStyle(
                        color: Colors.white,
                        fontWeight: FontWeight.w600,
                        fontSize: 14,
                      ),
                    ),
                    const SizedBox(height: 10),
                    Text(
                      '5 bots · Goal ${kDailyArenaGoalPercent.toStringAsFixed(0)}% · '
                      'Seed ${dailyArenaSeed(today)}',
                      style: displayNumber(size: 14),
                    ),
                    const SizedBox(height: 10),
                    if (record == null)
                      const Text(
                        'Not played yet today — your first run banks.',
                        style: TextStyle(
                          color: Colors.white,
                          fontWeight: FontWeight.w700,
                          fontSize: 14,
                        ),
                      )
                    else
                      Text(
                        record.won
                            ? '🏆 Banked: ${record.score.toStringAsFixed(1)}% · #${record.rank} · ${record.attempts} attempt${record.attempts == 1 ? '' : 's'}'
                            : 'Banked: ${record.score.toStringAsFixed(1)}% · #${record.rank} · ${record.attempts} attempt${record.attempts == 1 ? '' : 's'} — replay to practice, it stays banked.',
                        style: const TextStyle(
                          color: Colors.white,
                          fontWeight: FontWeight.w700,
                          fontSize: 14,
                        ),
                      ),
                  ],
                ),
              ),
              const SizedBox(height: 16),
              BeveledPanel(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Expanded(
                          child: Text(
                            '🔥 Nemesis: $nemesisName',
                            style: displayHeading(size: 18),
                          ),
                        ),
                        Text(
                          difficulty.label,
                          style: displayNumber(size: 13, color: kEmberLight),
                        ),
                      ],
                    ),
                    const SizedBox(height: 6),
                    Text(
                      difficulty.description,
                      style: const TextStyle(
                        color: Colors.white70,
                        fontWeight: FontWeight.w600,
                        fontSize: 13.5,
                        height: 1.35,
                      ),
                    ),
                    const SizedBox(height: 10),
                    Align(
                      alignment: Alignment.centerLeft,
                      child: BeveledButton(
                        label: 'Nemesis Card',
                        icon: Icons.person,
                        onPressed: () {
                          SoundService.instance.play(GameSound.pop);
                          Navigator.of(context).push(
                            MaterialPageRoute(
                              builder: (_) => NemesisCardScreen(
                                progressStore: widget.progressStore,
                              ),
                            ),
                          );
                        },
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 16),
              BeveledPanel(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      '🎯 Today\'s Challenge',
                      style: displayHeading(size: 17),
                    ),
                    const SizedBox(height: 6),
                    Text(
                      challengeDone
                          ? '✅ ${challenge.title} — bonus banked!'
                          : '⭐ ${challenge.title} — +$kDailyChallengeBonusPoints on completion',
                      style: const TextStyle(
                        color: Colors.white,
                        fontWeight: FontWeight.w700,
                        fontSize: 14,
                      ),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      '🔥 ${progress.streakDays} day streak',
                      style: displayNumber(size: 13, color: kStarGold),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 24),
              Center(
                child: BeveledButton(
                  label: record == null
                      ? 'PLAY TODAY\'S ARENA'
                      : 'REPLAY (PRACTICE)',
                  icon: Icons.play_arrow,
                  featured: true,
                  onPressed: () async {
                    await openDailyArena(context, widget.progressStore);
                    if (mounted) setState(() {});
                  },
                ),
              ),
              const SizedBox(height: 14),
              Center(
                child: BeveledButton(
                  label: '30-DAY HISTORY',
                  icon: Icons.calendar_month,
                  onPressed: () {
                    SoundService.instance.play(GameSound.pop);
                    Navigator.of(context).push(
                      MaterialPageRoute(
                        builder: (_) => DailyArenaHistoryScreen(
                          progressStore: widget.progressStore,
                        ),
                      ),
                    );
                  },
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

/// Last 30 days as a mini calendar with win / loss / skip marks.
class DailyArenaHistoryScreen extends StatelessWidget {
  final ProgressStore progressStore;

  const DailyArenaHistoryScreen({super.key, required this.progressStore});

  @override
  Widget build(BuildContext context) {
    final progress = progressStore.progress;
    final today = DateTime.now();
    final todayKey = dateKeyFor(today);
    final days = <DateTime>[
      for (var back = 29; back >= 0; back--)
        DateTime(today.year, today.month, today.day - back),
    ];
    var wins = 0;
    var losses = 0;
    var played = 0;
    for (final day in days) {
      final record = progress.dailyArenaHistory[dateKeyFor(day)];
      if (record == null) continue;
      played++;
      if (record.won) {
        wins++;
      } else {
        losses++;
      }
    }
    return Scaffold(
      appBar: AppBar(
        title: Text('Arena History', style: displayHeading(size: 20)),
        backgroundColor: Colors.transparent,
        elevation: 0,
        foregroundColor: Colors.white,
      ),
      extendBodyBehindAppBar: true,
      body: Container(
        decoration: const BoxDecoration(gradient: kNightGradient),
        child: SafeArea(
          child: ListView(
            padding: const EdgeInsets.all(20),
            children: [
              BeveledPanel(
                child: Text(
                  'Last 30 days: $wins wins · $losses losses · '
                  '${30 - played} skipped',
                  style: displayNumber(size: 15),
                  textAlign: TextAlign.center,
                ),
              ),
              const SizedBox(height: 16),
              GridView.builder(
                shrinkWrap: true,
                physics: const NeverScrollableScrollPhysics(),
                gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                  crossAxisCount: 7,
                  mainAxisSpacing: 8,
                  crossAxisSpacing: 8,
                  childAspectRatio: 0.92,
                ),
                itemCount: days.length,
                itemBuilder: (context, i) {
                  final day = days[i];
                  final key = dateKeyFor(day);
                  final record = progress.dailyArenaHistory[key];
                  final isToday = key == todayKey;
                  final mark = record == null
                      ? (isToday ? '○' : '–')
                      : record.won
                      ? '🏆'
                      : '✕';
                  final bg = record == null
                      ? Colors.white.withValues(alpha: 0.08)
                      : record.won
                      ? kEmber.withValues(alpha: 0.35)
                      : Colors.white.withValues(alpha: 0.16);
                  return Container(
                    decoration: BoxDecoration(
                      color: bg,
                      border: Border.all(
                        color: isToday
                            ? kEmberLight
                            : Colors.white.withValues(alpha: 0.25),
                        width: isToday ? 2 : 1,
                      ),
                      borderRadius: BorderRadius.circular(8),
                    ),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Text(
                          '${day.day}',
                          style: displayNumber(size: 14),
                        ),
                        Text(
                          mark,
                          style: const TextStyle(fontSize: 13),
                        ),
                      ],
                    ),
                  );
                },
              ),
              const SizedBox(height: 16),
              const Text(
                '🏆 = banked win · ✕ = banked loss · – = skipped · ○ = today, not played yet',
                textAlign: TextAlign.center,
                style: TextStyle(
                  color: Colors.white70,
                  fontWeight: FontWeight.w600,
                  fontSize: 12.5,
                ),
              ),
              const SizedBox(height: 12),
              ...days.reversed
                  .where((d) => progress.dailyArenaHistory[dateKeyFor(d)] != null)
                  .take(10)
                  .map((d) {
                    final r =
                        progress.dailyArenaHistory[dateKeyFor(d)]!;
                    return Padding(
                      padding: const EdgeInsets.only(bottom: 8),
                      child: BeveledPanel(
                        padding: const EdgeInsets.symmetric(
                          horizontal: 14,
                          vertical: 10,
                        ),
                        child: Row(
                          children: [
                            Expanded(
                              child: Text(
                                '${d.year}-${d.month.toString().padLeft(2, '0')}-${d.day.toString().padLeft(2, '0')}',
                                style: displayNumber(size: 13),
                              ),
                            ),
                            Text(
                              r.won ? '🏆 Win' : '✕ Loss',
                              style: const TextStyle(
                                color: Colors.white,
                                fontWeight: FontWeight.w800,
                                fontSize: 13,
                              ),
                            ),
                            const SizedBox(width: 10),
                            Text(
                              '${r.score.toStringAsFixed(1)}% · #${r.rank}',
                              style: displayNumber(
                                size: 13,
                                color: kStarGold,
                              ),
                            ),
                          ],
                        ),
                      ),
                    );
                  }),
            ],
          ),
        ),
      ),
    );
  }
}
