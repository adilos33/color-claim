/// The Nemesis card: the persistent Daily Arena rival, its current
/// form, and the head-to-head record. The rival never rotates — the
/// same name and ember skin every day; only its aggression moves.
library;

import 'package:flutter/material.dart';

import '../game/nemesis.dart';
import '../services/progress_store.dart';
import '../theme.dart';
import '../widgets/beveled_panel.dart';
import 'daily_arena_screen.dart';

class NemesisCardScreen extends StatelessWidget {
  final ProgressStore progressStore;

  const NemesisCardScreen({super.key, required this.progressStore});

  @override
  Widget build(BuildContext context) {
    final progress = progressStore.progress;
    final today = DateTime.now();
    final history = progress.dailyArenaHistory;
    final difficulty = nemesisDifficultyFor(history, today);
    final winRate = sevenDayWinRate(history, today);
    final headToHead = nemesisHeadToHead(history);
    final winStreak = winStreakBefore(history, today);
    final lossStreak = lossStreakBefore(history, today);
    return Scaffold(
      appBar: AppBar(
        title: Text('Nemesis Card', style: displayHeading(size: 20)),
        backgroundColor: Colors.transparent,
        elevation: 0,
        foregroundColor: Colors.white,
      ),
      extendBodyBehindAppBar: true,
      body: Container(
        decoration: const BoxDecoration(gradient: kNightGradient),
        child: SafeArea(
          child: ListView(
            padding: const EdgeInsets.all(20),
            children: [
              BeveledPanel(
                gradient: kEmberGradient,
                child: Column(
                  children: [
                    Container(
                      width: 92,
                      height: 92,
                      decoration: BoxDecoration(
                        color: Color(nemesisColorArgb),
                        border: Border.all(
                          color: Colors.white.withValues(alpha: 0.7),
                          width: 2,
                        ),
                        borderRadius: BorderRadius.circular(12),
                      ),
                      child: const Center(
                        child: Text('🔥', style: TextStyle(fontSize: 44)),
                      ),
                    ),
                    const SizedBox(height: 12),
                    Text(
                      nemesisName.toUpperCase(),
                      style: displayHeading(size: 34),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      'Your Daily Arena rival — same bot, every day.',
                      textAlign: TextAlign.center,
                      style: const TextStyle(
                        color: Colors.white,
                        fontWeight: FontWeight.w700,
                        fontSize: 14,
                      ),
                    ),
                    const SizedBox(height: 10),
                    Text(
                      'TODAY: ${difficulty.label.toUpperCase()}',
                      style: displayNumber(size: 16, color: kStarGold),
                    ),
                    const SizedBox(height: 6),
                    Text(
                      difficulty.description,
                      textAlign: TextAlign.center,
                      style: const TextStyle(
                        color: Colors.white,
                        fontWeight: FontWeight.w600,
                        fontSize: 13.5,
                        height: 1.35,
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 16),
              BeveledPanel(
                child: Column(
                  children: [
                    _statRow(
                      'Head-to-head',
                      '${headToHead.wins}W – ${headToHead.losses}L',
                    ),
                    const SizedBox(height: 10),
                    _statRow(
                      'Win rate (last 7 days)',
                      history.isEmpty
                          ? 'No arena days yet'
                          : '${(winRate * 100).toStringAsFixed(0)}%',
                    ),
                    const SizedBox(height: 10),
                    _statRow(
                      'Current streak',
                      winStreak >= 1
                          ? '🔥 $winStreak wins in a row'
                          : lossStreak >= 1
                          ? '$lossStreak losses in a row'
                          : 'No streak yet',
                    ),
                    const SizedBox(height: 10),
                    _statRow(
                      'How it adapts',
                      '3+ wins → faster & bolder · 3+ losses → backs off',
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 16),
              const Text(
                'Ember hunts your exposed trail from further away than '
                'ordinary bots, and it never changes its name or color — '
                'so every rematch is personal. It plays only in the '
                'Daily Arena; Classic levels keep their own bots.',
                style: TextStyle(
                  color: Colors.white70,
                  fontWeight: FontWeight.w600,
                  fontSize: 13.5,
                  height: 1.4,
                ),
              ),
              const SizedBox(height: 24),
              Center(
                child: BeveledButton(
                  label: 'FACE EMBER TODAY',
                  icon: Icons.play_arrow,
                  featured: true,
                  onPressed: () async {
                    await openDailyArena(context, progressStore);
                  },
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _statRow(String label, String value) {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Expanded(
          child: Text(
            label,
            style: const TextStyle(
              color: Colors.white70,
              fontWeight: FontWeight.w700,
              fontSize: 13.5,
            ),
          ),
        ),
        const SizedBox(width: 12),
        Expanded(
          child: Text(
            value,
            textAlign: TextAlign.right,
            style: displayNumber(size: 13.5),
          ),
        ),
      ],
    );
  }
}
