package com.soumbati.color_claim

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
